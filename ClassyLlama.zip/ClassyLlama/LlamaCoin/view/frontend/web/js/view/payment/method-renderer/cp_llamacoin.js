define([
        'jquery',
        'Magento_Payment/js/view/payment/cc-form',
        'mage/url',
        'ClassyLlama_LlamaCoin/js/action/set-payment-method-action'
    ],
    function ($, Component, url, setPaymentMethodAction) {
        'use strict';

        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: false,
                template: 'ClassyLlama_LlamaCoin/payment/llamacoin'
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'classyllama_llamacoin';
            },

            isActive: function() {
                return true;
            },

            afterPlaceOrder: function () {
                setPaymentMethodAction(this.messageContainer);
                return false;
            }

        });
    }
);
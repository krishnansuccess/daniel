define([
        'jquery',
        'Magento_Payment/js/view/payment/cc-form',
        'mage/url',
        'Magento_Checkout/js/action/redirect-on-success',
        'Magento_Checkout/js/model/quote'
    ],
    function ($, Component, url, redirectOnSuccessAction, quote) {
        'use strict';

        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: true,
                template: 'ClassyLlama_LlamaCoin/payment/llamacoin'
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'classyllama_llamacoin';
            },

            isActive: function() {
                return true;
            },

            getData: function () {
                var data = {
                        'method': this.getCode(),
                        'cc_cid': this.creditCardVerificationNumber(),
                        'cc_type': this.creditCardType(),
                        'cc_exp_year': this.creditCardExpYear(),
                        'cc_exp_month': this.creditCardExpMonth(),
                        'cc_number': this.creditCardNumber()
                };

                return data;
            },

            placeOrder: function () {

                var cc_cid = this.creditCardVerificationNumber();
                var cc_type = this.creditCardType();
                var cc_exp_year = this.creditCardExpYear();
                var cc_exp_month = this.creditCardExpMonth();
                var cc_number = this.creditCardNumber();
                var totals = quote.totals();
                var cc_amount = totals.grand_total;
                console.log('cc_amount: '+cc_amount);
            
                // console.log('ccnumber'+cc_number);
                // console.log('cc_exp_month'+cc_exp_month);
                // console.log('cc_exp_year'+cc_exp_year);
                // console.log('cc_type'+cc_type);


                $.ajax({
                    url: url.build('mytempus/index/index/'),
                    type: 'GET',
                    data: {mycc_number: cc_number, mycc_amount: cc_amount},
                    contentType: 'application/json',
                    success: function (res) {
                        console.log('Credit Transaction Status: '+res.credit_TRANSUCCESS);
                        console.log('Credit TRANSARMORTOKEN: '+res.credit_TRANSARMORTOKEN);
                        console.log('Credit TRANRESPMESSAGE: '+res.credit_TRANRESPMESSAGE);
                        console.log(res);
                        if(res.credit_TRANSUCCESS == 'TRUE'){
                            //this.afterPlaceOrder();
                            if (this.redirectAfterPlaceOrder) {
                                    redirectOnSuccessAction.execute();
                                }
                        }else{
                            return false;
                        }
                        // console.log('Token Transaction Status: '+res.token.token_TRANSUCCESS);
                        // console.log('Token TRANSARMORTOKEN: '+res.token.token_TRANSARMORTOKEN);
                        // console.log('Auth Transaction Status: '+res.auth.auth_TRANSUCCESS);
                        // console.log('Auth TRANSARMORTOKEN: '+res.auth.auth_TRANSARMORTOKEN);
                        
                        //return false;
                    }
                });

                //return false;

            },

            afterPlaceOrder: function () {
            // Override this function and put after place order logic here
        }




            

        });
    }
);
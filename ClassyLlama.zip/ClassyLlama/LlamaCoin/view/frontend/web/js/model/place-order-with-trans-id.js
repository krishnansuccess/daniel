/*jshint browser:true jquery:true*/
/*global alert*/
define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
    'use strict';
    return function (placeOrderAction) {
        /** Override default place order action and add agreement_ids to request */
        return wrapper.wrap(placeOrderAction, function (originalAction, paymentData, redirectOnSuccess, messageContainer) {
            var tumpusTransId = '';
            if (window.tumpusTransactionId) {
                var x=tumpusTransactionId.split(':');
                tumpusTransId = x[1].trim();
            }
            paymentData.extension_attributes = {tumpus_trans_id: tumpusTransId};
            return originalAction(paymentData, redirectOnSuccess, messageContainer);
        });
    };
});
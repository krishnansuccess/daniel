var domain = "https://ubuy.syf.com";
var dBuyURL = domain + "/DigitalBuy/processCart.do";
var fetchMerchantURL = domain + "/DigitalBuy/merchantType.do"
var fetchCallBackFlagURL = domain + "/DigitalBuy/callbackPostbackFlag.do"
var loadingImageURL = domain + "/digitalbuy/images/ajax-loader.gif";

var syfPayButtonURL = domain + "/Merchant/getImageURL?hostName=";
var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
var eventer = window[eventMethod];
var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

var authenticationSuccessUrl = null;
var transactionSuccessUrl = null;
var transactionFailUrl = null;
var authenticationFailUrl = null;
var callBackFlagValue = null;

eventer(messageEvent, function (e) {
    if (callBackFlagValue == null)
        //callBackFlagValue = fetchCallbackPostbackFlag(jQuery("#merchantID").val());
        if (typeof e.data == 'object') {
            var totalHeight = e.data.totalHeight;
            // this code has been added for displaying 100% in case of mobile device
            var parentHeight = jQuery(window.parent).height() - 20;
            var parentWidth = jQuery(window.parent).width();
            if (parentWidth <= 767 && totalHeight < parentHeight) {
                totalHeight = parentHeight;
            }

            jQuery(".changeHeight").height(totalHeight + 'px');

            var callbackMessage = e.data.callbackMessage;
            var merchantId = jQuery("#merchantID").val();
            var tokenId = jQuery("#tokenId").val();
            if (callBackFlagValue != null && callBackFlagValue == 'CallBack' && callbackMessage !== null && callbackMessage !== undefined && callbackMessage !== 'undefined') {
                passJsonCallBackToMerchant(callbackMessage);
            }

            jQuery("#callbackMessage").text(callbackMessage);
            jQuery("#cbmDisplayId").removeClass("hidden");
            jQuery("#cbmDisplayId").addClass("show");

            authenticationSuccessUrl = e.data.authenticationSuccessUrl;
            transactionSuccessUrl = e.data.transactionSuccessUrl;
            transactionFailUrl = e.data.transactionFailUrl;
            authenticationFailUrl = e.data.authenticationFailUrl;
        } else if (typeof e.data == 'string') {

            if (e.data == 'Close Model') {
                jQuery(".changeHeight").height('530px');
                daiva();
                closedBuyModal();
            } else if (e.data == 'Return To Merchant Shipping') {
                closedBuyModal();
            }
        }
}, false);


function daiva() {
    var protocol = location.protocol;
    var slashes = protocol.concat("//");
    var host = slashes.concat(window.location.hostname);
    jQuery.ajax({
        url: host + '/synchrony/payment/status',
        type: 'GET',
        data: {token: window.tokenId},
        contentType: 'application/json',
        success: function (res) {
            window.isSynchronyCompleted(true);
            if (res.StatusCode == '000') {
                window.transactionId=res.TransactionId;
                jQuery("#onestepcheckout-button-place-order").trigger('click');
            } else {
                window.isSynchronyFailed(true);
                openModalDialogError(res.message);
                
                // jQuery('#synchrony_error').text(res.message);
            }
        }
    });
}

function openModalDialogError(message) {
    jQuery('#errmodel').show();
    var modelText = '<div class="modal fade in" id="digBuyModal" tabindex="-1" role="dialog" '
            + 'aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">'
            + '<div class="modal-dialog" role="document" style="max-width: 650px; width: auto;">'
            + '<div class="modal-content" style="border: 2px solid #999;"><div class="changeHeight" style="height:150px; margin:40px;">'
            +'<p style="padding: 20px;font-size: 14px;">Your transaction did not complete successfully. Please try again.</p>'
            + '<button class="close-err" style="background: #e9daee !important; margin: 0 auto;display: block;" class="close_button">Close</button>'
            + '</div></div></div>';

    jQuery(modelText).appendTo("#errmodel");
    
    jQuery("#errmodel").on("click", ".close-err", function(e){
        e.preventDefault();
    jQuery('#errmodel').hide();
    location.reload();
});
}
function closeModalDialogError() {
    jQuery('#errmodel').hide();
}

function passJsonCallBackToMerchant(callbackMessage) {

    jQuery.ajax({
        url: "parseDbuyJsonCallBack.do",
        cache: false,
        data: {
            callbackMessage: callbackMessage
        },
        success: function () {
            console.log("Success");
        }
    });
}

function closedBuyModal() {
    jQuery('#digBuyModal').hide();
}

function calldBuyProcess1(formObj, passedJsonObj) {
    if (passedJsonObj != null) {
        formObj = document.createElement("form");
        document.body.appendChild(formObj);
        var inputField = document.createElement("input");
        inputField.name = "passedJson";
        inputField.id = "passedJson";
        inputField.type = "hidden";
        var successUrl = document.getElementById("successUrl");
        if (successUrl !== null && successUrl !== undefined
                && successUrl !== 'undefined') {
            passedJsonObj.successUrl = successUrl.value;
        }
        var failUrl = document.getElementById("failUrl");
        if (failUrl !== null && failUrl !== undefined
                && failUrl !== 'undefined') {
            passedJsonObj.failUrl = failUrl.value;
        }
        inputField.value = JSON.stringify(passedJsonObj);

        formObj.appendChild(inputField);
    }
    openModalDialog(formObj, 1, passedJsonObj);
}

window.onmessage = function (msg) {
    var frame = document.getElementById("dBuyInstallmentFrame");
    if (null != frame && msg.data && msg.data.name == "Close"
            && msg.source == frame.contentWindow) {
        closedBuyModal();
        jQuery('#dbuyform3').css('display', 'block');
    }
};

function openInstallmentModalDialog(formObj, merchantData) {

    var url = null;

    if (merchantData.tokenActive) {
        url = merchantData.installmentUrl;
    } else {
        url = merchantData.installmentExpiredUrl;
    }

    if (document.getElementById('digBuyModal') != null) {
        jQuery('#digBuyModal').remove();
    }

    var modalId = "#dbuymodel3";

    var modelText = '<div class="modal fade bs-example-modal-lg in" id="digBuyModal" data-target="#myModal" data-toggle="modal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" '
            + 'style="background-color: rgba(0,0,0,0.4); display: block; overflow-x: scroll; padding-left: 2px; padding-right: 2px;">'
            + '<div class="modal-lg" id = "modal-dialog-id" role="document" style="height: 100%;margin:2% auto 0 auto;">'
            + '<iframe id="dBuyInstallmentFrame" name="digitalBuyInstallmentFrame" frameborder="0px" style="width:100%;border: none;" ></iframe>'
            + '</div></div>';

    jQuery(modelText).appendTo(modalId);

    var inputField = createInputField("hidden", "channelId", "channelId");
    inputField.value = "DY";
    formObj.appendChild(inputField);

    var form = formObj;
    if (form == null || form == 'undefined' || form == 'Undefined') {
        form = document.getElementById('dbuyform1');
    }

    form.target = "digitalBuyInstallmentFrame";
    form.action = url;
    form.method = "POST";

    if ((navigator.userAgent.indexOf("Chrome") == -1)
            && (navigator.userAgent.indexOf("Safari") > 0)) {

        var dummyWindow = window.open(merchantData.installmentDummyIosUrl);
        window.setTimeout(function () {
            dummyWindow.close();
        }, 3000);
        window.setTimeout(function () {
            form.submit();
        }, 5000);

    } else {
        form.submit();
    }
    jQuery(".modal-dialog").hide();

    jQuery('#dBuyInstallmentFrame').on('load', function () {
        if (jQuery(this).parent().parent().hasClass('in')) {
            jQuery('#dbuyform3').css('display', 'none');
        }
        jQuery(".modal-dialog").show();
    });

    setTimeout(
            function () {
                if (window.matchMedia('(max-width: 767px)').matches) {
                    var res = navigator.userAgent.toLowerCase().indexOf(
                            "iphone");
                    if (res > -1) {
                        jQuery('#digBuyModal')
                                .css("cssText",
                                        "position: absolute !important; min-height: 550px !important;");
                        jQuery('#digBuyModal').css('bottom', 'initial');
                    }
                }
                if (window.matchMedia('(min-width: 320px)').matches
                        && window.matchMedia('(max-width: 480px)').matches) {
                    jQuery('#dBuyInstallmentFrame').css('height', '100%');
                } else if (window.matchMedia('(min-width: 480px)').matches
                        && window.matchMedia('(max-width: 767px)').matches) {
                    jQuery('#dBuyInstallmentFrame').css('height', '100%');
                } else {
                    jQuery('#dBuyInstallmentFrame').css('height', '93%');
                }
            }, 50);
}

function fetchMerchantType(merchantId, tokenId) {
    var merchantTypeData = null;
    jQuery.ajax({
        url: fetchMerchantURL,
        cache: false,
        type: "GET",
        async: false,
        data: {
            merchantId: merchantId,
            tokenId: tokenId
        },
        success: function (response) {
            merchantTypeData = response
        }
    });
    return merchantTypeData;
}


function fetchCallbackPostbackFlag(merchantId, tokenId) {
    var merchantTypeData = null;
    jQuery.ajax({
        url: fetchCallBackFlagURL,
        cache: false,
        type: "GET",
        async: false,
        data: {
            merchantId: merchantId,
        },
        success: function (response) {
            merchantTypeData = response
        }
    });
    return merchantTypeData;
}


function calldBuyProcess2(formObj, passedJsonObj) {
    if (passedJsonObj != null) {
        formObj = document.createElement("form");
        document.body.appendChild(formObj);
        var inputField = document.createElement("input");
        inputField.name = "passedJson";
        inputField.id = "passedJson";
        inputField.type = "hidden";
        var successUrl = document.getElementById("successUrl");
        if (successUrl !== null && successUrl !== undefined
                && successUrl !== 'undefined') {
            passedJsonObj.successUrl = successUrl.value;
        }
        var failUrl = document.getElementById("failUrl");
        if (failUrl !== null && failUrl !== undefined
                && failUrl !== 'undefined') {
            passedJsonObj.failUrl = failUrl.value;
        }
        inputField.value = JSON.stringify(passedJsonObj);

        formObj.appendChild(inputField);
    }
    console.log("Daiva");
    openModalDialog(formObj, 2, passedJsonObj);
}

function callCombinedModaldBuyProcess(formObj, passedJsonObj) {
    console.log('testststestsets');
    var merchantId = jQuery("#merchantID").val();
    var tokenId = jQuery("#tokenId").val();
    var merchantData = fetchMerchantType(merchantId, tokenId);
    console.log(merchantData);
    if (merchantData != null && merchantData.installmentFlag == 'Y') {

        openInstallmentModalDialog(formObj, merchantData);

    } else {
        if (passedJsonObj != null) {
            formObj = document.createElement("form");
            document.body.appendChild(formObj);
            var inputField = document.createElement("input");
            inputField.name = "passedJson";
            inputField.id = "passedJson";
            inputField.type = "hidden";
            var successUrl = document.getElementById("successUrl");
            if (successUrl !== null && successUrl !== undefined
                    && successUrl !== 'undefined') {
                passedJsonObj.successUrl = successUrl.value;
            }
            var failUrl = document.getElementById("failUrl");
            if (failUrl !== null && failUrl !== undefined
                    && failUrl !== 'undefined') {
                passedJsonObj.failUrl = failUrl.value;
            }
            inputField.value = JSON.stringify(passedJsonObj);

            formObj.appendChild(inputField);
        }
        openModalDialog(formObj, 3, passedJsonObj);
    }
}

function openModalDialog(formObj, processInd, passedJsonObj) {
    var url = dBuyURL;
    if (passedJsonObj != null) {
        url += "?tokenId=" + passedJsonObj.tokenId;
        url += "&merchantID=" + passedJsonObj.merchantID;
        url += "&processInd=" + passedJsonObj.processInd;
    }
    if (document.getElementById('digBuyModal') != null) {
        jQuery('#digBuyModal').remove();
    }
    var modalId = "#dbuymodel" + processInd;
    var modelText = '<div class="modal fade in" id="digBuyModal" tabindex="-1" role="dialog" '
            + 'aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">'
            + '<div class="modal-dialog" role="document" style="max-width: 650px; width: auto;">'
            + '<div class="modal-content"><div class="changeHeight" style="height:530px;">'
            + '<div id="iframeloading" style= " position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;">'
            + '<img id="dBuyLoadingImage" alt="loading" style="left:50%;margin-left:-15px;top: 50%;margin-top: -16px;position: relative;"/></div>'
            + '<iframe id="dBuyFrame" name="digitalBuyFrame" title="Online Payment" frameborder="0px" style="width:100%;height:100%;" scrolling="no" data-la-tb-sec-ok="true" sandbox="allow-top-navigation allow-popups allow-same-origin allow-forms allow-scripts"></iframe></div></div></div></div>';

    jQuery(modelText).appendTo(modalId);
    var form = formObj;
    if (form == null || form == 'undefined' || form == 'Undefined') {
        form = document.getElementById('dbuyform' + processInd);
    }

    form.target = "digitalBuyFrame";
    form.action = url;
    form.method = "POST";
    form.submit();

    jQuery('#dBuyLoadingImage').attr('src', loadingImageURL);
    jQuery("#iframeloading").show();

    jQuery('#dBuyFrame').on('load', function () {

        jQuery("#iframeloading").hide();
        if (navigator.userAgent.indexOf("Firefox") != -1) {
            jQuery('#dBuyFrame').focus();
        }
    });
}

function redirectToNextPage(successUrl, failUrl) {
    var processInd = document.getElementsByName('processInd')[0].value;
    var success = document.getElementById("successUrl");
    if (success == null || success == undefined || success == '') {
        success = document.createElement("input");
    }
    success.type = "hidden";
    success.name = "successUrl";
    success.id = "successUrl";
    success.value = successUrl;

    var fail = document.getElementById("failUrl");
    if (fail == null || fail == undefined || fail == '') {
        fail = document.createElement("input");
    }
    fail.type = "hidden";
    fail.name = "failUrl";
    fail.id = "failUrl";
    fail.value = failUrl;

    var form = document.getElementById('dbuyform' + processInd);
    form.appendChild(success);
    form.appendChild(fail);
}

function createInputField(type, name, id) {

    var inputField = document.createElement("input");
    inputField.type = type;
    inputField.name = name;
    inputField.id = id;

    return inputField;
}

function fetchPayNowButtonInformation() {
    jQuery.get(syfPayButtonURL + window.location.hostname, function (data, status) {
        if (status === "success") {
            var payNowButtonText = "<div><img src='" + data.URL + "'/> </div>";
            jQuery(payNowButtonText).appendTo("#syfPayButton");

        } else {
            // error to be handled
            console.log("Merchant has no pay now button configured " + status);
            console.log(data);
        }
    });
}

/*jQuery(document).ready(function() {
 if (jQuery("#syfPayButton").length == 0) {
 console.log("syfPayButton div is absent in the page");
 } else {
 fetchPayNowButtonInformation();
 }
 
 });*/
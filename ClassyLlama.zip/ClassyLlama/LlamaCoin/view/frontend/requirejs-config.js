var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'ClassyLlama_LlamaCoin/js/model/place-order-with-trans-id': true
            }
        }
    }
    // map: {
    //     '*': {
    //         'Magento_Checkout/js/view/payment/default':'Tempuspayment_Tempus/js/view/payment/default'
    //     }
    // }
};

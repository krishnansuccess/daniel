# LlamaCoin
Magento 2 Custom Payment Method Proof of Concept

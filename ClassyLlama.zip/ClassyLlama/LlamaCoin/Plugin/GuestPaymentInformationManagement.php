<?php

namespace ClassyLlama\LlamaCoin\Plugin;

/**
 * Description of GuestPaymentInformationManagement
 *
 * @author Daiva
 */
class GuestPaymentInformationManagement {

    /** @var \Magento\Sales\Model\OrderFactory $orderFactory */
    protected $orderFactory;
    protected $transactionBuilder;

    public function __construct(
    \Magento\Sales\Model\OrderFactory $orderFactory, \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder
    ) {
        $this->orderFactory = $orderFactory;
        $this->transactionBuilder = $transactionBuilder;
    }

    public function aroundSavePaymentInformationAndPlaceOrder(
    \Magento\Checkout\Api\GuestPaymentInformationManagementInterface $subject, \Closure $proceed, $cartId, $email,\Magento\Quote\Api\Data\PaymentInterface $paymentMethod, \Magento\Quote\Api\Data\AddressInterface $billingAddress = null
    ) {

        $extAttributes = $paymentMethod->getExtensionAttributes();
        $orderId = $proceed($cartId,$email, $paymentMethod, $billingAddress);

        if($extAttributes->getTumpusTransId())
        $this->createTransaction($orderId, ['trans_id' => $extAttributes->getTumpusTransId()]);
         return $orderId;
    }

    public function createTransaction($orderId = null, $paymentData = array()) {

$this->log($orderId);
$this->log($paymentData['trans_id']);
        $order = $this->orderFactory->create();
        $order->load($orderId);
        try {
            //get payment object from order object
            $payment = $order->getPayment();
            $payment->setLastTransId($paymentData['trans_id']);
            $payment->setTransactionId($paymentData['trans_id']);
            $payment->setAdditionalInformation(
                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array) $paymentData]
            );
            $formatedPrice = $order->getBaseCurrency()->formatTxt(
                    $order->getGrandTotal()
            );

            $message = __('The authorized amount is %1.', $formatedPrice);
            //get the object of builder class
            $trans = $this->transactionBuilder;
            $transaction = $trans->setPayment($payment)
                    ->setOrder($order)
                    ->setTransactionId($paymentData['trans_id'])
                    ->setAdditionalInformation(
                            [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array) $paymentData]
                    )
                    ->setFailSafe(true)
                    //build method creates the transaction and returns the object
                    ->build(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE);

            $payment->addTransactionCommentsToOrder(
                    $transaction, $message
            );
            $payment->setParentTransactionId(null);
            $payment->save();
            $order->setStatus('complete');
            $order->save();

            return $transaction->save()->getTransactionId();
        } catch (Exception $e) {
              $this->log($e->getMessage());
        }
    }
public function log($msg){

            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logfile.log');
$logger = new \Zend\Log\Logger();
$logger->addWriter($writer);
$logger->info($msg);
}
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Ccavenue
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace ClassyLlama\LlamaCoin\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Payment;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order;
//use Webkul\Ccavenue\Logger\Logger;

class Index extends Action
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    const SANDBOX = 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction';
    const PRODUCTION = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var OrderRepositoryInterface
     */
    protected $_orderRepository;

    protected $_ccavenueHelper;
    /**
     * Form factory
     *
     * @var \Magento\Framework\Data\FormFactory
     */
    protected $formFactory;
    /**
     * Form factory
     *
     * @var \Magento\Directory\Model\Country
     */
    protected $_country;
    /**
     * Form factory
     *
     * @var \Magento\Sales\Model\Order
     */
    protected $_order;

    protected $jsonHelper;
    /**
     * @var \Webkul\Ccavenue\Logger\Logger
     */
    private $logger;
    /**
     * @param Context                             $context
     * @param OrderRepositoryInterface            $orderRepository
     * @param \Magento\Checkout\Model\Session     $checkoutSession
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Webkul\Ccavenue\Helper\Data        $ccavenueHelper
     * @param \Magento\Directory\Model\Country    $country
     * @param \Magento\Sales\Model\Order          $order
     * @param Logger                              $logger
     * @param PageFactory                         $resultPageFactory
     */
    public function __construct(
        Context $context,
        OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Data\FormFactory $formFactory,
        //\Webkul\Ccavenue\Helper\Data $ccavenueHelper,
        \Magento\Directory\Model\Country $country,
        \Magento\Sales\Model\Order $order,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper
        //Logger $logger
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_checkoutSession = $checkoutSession;
        $this->_urlBuilder = $context->getUrl();
        $this->formFactory = $formFactory;
        $this->_country = $country;
        $this->_order = $order;
        $this->_resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->jsonHelper = $jsonHelper;
        //$this->_ccavenueHelper = $ccavenueHelper;
        //$this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        try {

            $cc_number = $this->getRequest()->getParam('mycc_number');
            $cc_amount = $this->getRequest()->getParam('mycc_amount');

            $url = "https://QA1.spectrumretailnet.com/PPSAPI";

//Store your XML Request in a variable
    $token_input_xml = '<TRANSACTION>
<RNID>91370</RNID>
<RNCERT>1595075161DF5CFF2A588020D8BBBF60F04037C8</RNCERT>
<TRANSACTIONTYPE>CCTATOKENIZE</TRANSACTIONTYPE>
<CCACCOUNT>'.$cc_number.'</CCACCOUNT>
<CCEXP>0420</CCEXP> 
<ENCODING>UTF-8</ENCODING>
</TRANSACTION>';

        //setting the curl parameters.
        $token_ch = curl_init();
        curl_setopt($token_ch, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
        curl_setopt($token_ch, CURLOPT_POSTFIELDS,
                    "xmlRequest=" . $token_input_xml);
        curl_setopt($token_ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($token_ch, CURLOPT_CONNECTTIMEOUT, 300);
        $token_data = curl_exec($token_ch);
        curl_close($token_ch);

        //convert the XML result into array
        $token_array_data = json_decode(json_encode(simplexml_load_string($token_data)), true);

        if($token_array_data != null)
                {
                    $result['token_TRANSUCCESS'] = $token_array_data['TRANSUCCESS'];
                    $result['token_TRANSARMORTOKEN'] = $token_array_data['TRANSARMORTOKEN'];


                    $token_TRANSUCCESS = $token_array_data['TRANSUCCESS'];
                    $token_TRANSARMORTOKEN = $token_array_data['TRANSARMORTOKEN'];
                    

                    if($token_TRANSUCCESS == "TRUE"){

                        $token_TRANSARMORPROVIDER = $token_array_data['TRANSARMORPROVIDER'];


            // $cc_number = $this->getRequest()->getParam('mycc_number');
            // $cc_amount = $this->getRequest()->getParam('mycc_amount');

            //$url = "https://QA1.spectrumretailnet.com/PPSAPI";

//Store your XML Request in a variable
    $auth_input_xml = '<TRANSACTION> 
<RNID>91370</RNID>
<RNCERT>1595075161DF5CFF2A588020D8BBBF60F04037C8</RNCERT>
<TRANSACTIONTYPE>CCAUTH</TRANSACTIONTYPE>
<CCAMT>'.$cc_amount.'</CCAMT>
<TRANSARMORTOKEN>'.$token_TRANSARMORTOKEN.'</TRANSARMORTOKEN>
<CCEXP>0420</CCEXP>
<TRANSARMORTOKENPROVIDERID>'.$token_TRANSARMORPROVIDER.'</TRANSARMORTOKENPROVIDERID>
<ENCODING>UTF-8</ENCODING>
</TRANSACTION>';

        //setting the curl parameters.
        $auth_ch = curl_init();
        curl_setopt($auth_ch, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
        curl_setopt($auth_ch, CURLOPT_POSTFIELDS,
                    "xmlRequest=" . $auth_input_xml);
        curl_setopt($auth_ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($auth_ch, CURLOPT_CONNECTTIMEOUT, 300);
        $auth_data = curl_exec($auth_ch);
        curl_close($auth_ch);

        //convert the XML result into array
        $auth_array_data = json_decode(json_encode(simplexml_load_string($auth_data)), true);

        if($auth_array_data != null)
                {
                    $result['auth_TRANSUCCESS'] = $auth_array_data['TRANSUCCESS'];
                    $result['auth_TRANSARMORTOKEN'] = $auth_array_data['TRANSARMORTOKEN'];

                    $auth_TRANSUCCESS = $auth_array_data['TRANSUCCESS'];
                    $auth_TRANSARMORTOKEN = $auth_array_data['TRANSARMORTOKEN'];
                    

                    if($auth_TRANSUCCESS == "TRUE"){


                        //Store your XML Request in a variable
    $credit_input_xml = '<TRANSACTION>
<RNID>91370</RNID>
<RNCERT>1595075161DF5CFF2A588020D8BBBF60F04037C8</RNCERT> 
<TRANSACTIONTYPE>CCCREDIT</TRANSACTIONTYPE>
<CCACCOUNT>'.$cc_number.'</CCACCOUNT>
<CCEXP>0420</CCEXP>
<TRANSARMORTOKEN>'.$auth_TRANSARMORTOKEN.'</TRANSARMORTOKEN > 
<TRANSARMORTOKENPROVIDERID>'.$token_TRANSARMORPROVIDER.'</TRANSARMORTOKENPROVIDERID> 
<CCEXP>0420</CCEXP>
<CCAMT>'.$cc_amount.'</CCAMT> 
<SERVICENAME>CARD</SERVICENAME> 
<ENCODING>UTF-8</ENCODING>
</TRANSACTION> 
';

        //setting the curl parameters.
        $credit_ch = curl_init();
        curl_setopt($credit_ch, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
        curl_setopt($credit_ch, CURLOPT_POSTFIELDS,
                    "xmlRequest=" . $credit_input_xml);
        curl_setopt($credit_ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($credit_ch, CURLOPT_CONNECTTIMEOUT, 300);
        $credit_data = curl_exec($credit_ch);
        curl_close($credit_ch);

        //convert the XML result into array
        $credit_array_data = json_decode(json_encode(simplexml_load_string($credit_data)), true);

        if($credit_array_data != null)
                {
                    $credit_TRANSUCCESS = $credit_array_data['TRANSUCCESS'];


                if($credit_TRANSUCCESS == "TRUE"){

                    $result['token_TRANSUCCESS'] = $token_array_data['TRANSUCCESS'];
                    $result['token_TRANSARMORTOKEN'] = $token_array_data['TRANSARMORTOKEN'];
                    $result['token_TRANRESPMESSAGE'] = $token_array_data['TRANRESPMESSAGE'];

                    $result['auth_TRANSUCCESS'] = $auth_array_data['TRANSUCCESS'];
                    $result['auth_TRANSARMORTOKEN'] = $auth_array_data['TRANSARMORTOKEN'];
                    $result['auth_TRANRESPMESSAGE'] = $auth_array_data['TRANRESPMESSAGE'];

                    $result['credit_TRANSUCCESS'] = $credit_array_data['TRANSUCCESS'];
                    $result['credit_TRANSARMORTOKEN'] = $credit_array_data['TRANSARMORTOKEN'];
                    $result['credit_TRANRESPMESSAGE'] = $credit_array_data['TRANRESPMESSAGE'];
                    $result['credit_res'] = $credit_array_data;

                    return $this->jsonResponse($result);
                }
                    
                }
                else {
                    $result['credit_TRANSUCCESS'] =null;
                    return $this->jsonResponse($result);
                } 
             
             
            //return $this->jsonResponse($result);


                
                

                    }
                    else{
                    $result['auth_TRANSUCCESS'] = $token_array_data['TRANSUCCESS'];
                    $result['auth_TRANSARMORTOKEN'] = $token_array_data['TRANSARMORTOKEN'];
                    return $this->jsonResponse($result);
                    }
                    
                }
                else {
                    $result['auth_TRANSUCCESS'] =null;
                } 
             
             
            //return $this->jsonResponse($result); //for auth return


                

                    }//trans success if end
                    else{
                    $result['token_TRANSUCCESS'] = $token_array_data['TRANSUCCESS'];
                    $result['token_TRANSARMORTOKEN'] = $token_array_data['TRANSARMORTOKEN'];
                    return $this->jsonResponse($result);
                    }
                    
                }
                else {
                   $result['token_TRANSUCCESS'] = null;
                   $result['token_TRANSARMORTOKEN'] = null;
                   return $this->jsonResponse($result);
                } 
             
             
            //return $this->jsonResponse($result); // for token return


        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            return $this->jsonResponse($e->getMessage());
        }
    }


    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }

}

/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
var config = {
    map: {
        '*': {
            optionAdditionalImages: 'MageWorx_OptionFeatures/js/swatches/additional',
            mwImageReplacer: 'MageWorx_OptionFeatures/js/swatches/imageReplacer'
        }
    }
};

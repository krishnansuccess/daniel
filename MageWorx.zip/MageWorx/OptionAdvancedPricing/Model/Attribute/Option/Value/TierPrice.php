<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OptionAdvancedPricing\Model\Attribute\Option\Value;

use Magento\Framework\App\ResourceConnection;
use MageWorx\OptionAdvancedPricing\Helper\Data as Helper;
use MageWorx\OptionBase\Helper\System as SystemHelper;
use MageWorx\OptionBase\Model\AttributeInterface;
use MageWorx\OptionAdvancedPricing\Model\TierPrice as TierPriceModel;
use MageWorx\OptionBase\Model\Product\Option\AbstractAttribute;

class TierPrice extends AbstractAttribute implements AttributeInterface
{
    /**
     * @var Helper
     */
    protected $helper;

    /**
     * @var SystemHelper
     */
    protected $systemHelper;

    /**
     * @var TierPriceModel
     */
    protected $tierPriceModel;

    /**
     * @param ResourceConnection $resource
     * @param Helper $helper
     * @param TierPriceModel $tierPriceModel
     * @param SystemHelper $systemHelper
     */
    public function __construct(
        ResourceConnection $resource,
        Helper $helper,
        TierPriceModel $tierPriceModel,
        SystemHelper $systemHelper
    ) {
        $this->helper         = $helper;
        $this->tierPriceModel = $tierPriceModel;
        $this->systemHelper   = $systemHelper;
        parent::__construct($resource);
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return TierPriceModel::KEY_TIER_PRICE;
    }

    /**
     * {@inheritdoc}
     */
    public function hasOwnTable()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getTableName($type = '')
    {
        $map = [
            'product' => TierPriceModel::TABLE_NAME,
            'group'   => TierPriceModel::OPTIONTEMPLATES_TABLE_NAME
        ];
        if (!$type) {
            return $map[$this->entity->getType()];
        }
        return $map[$type];
    }

    /**
     * {@inheritdoc}
     */
    public function collectData($entity, array $options)
    {
        if (!$this->helper->isTierPriceEnabled()) {
            return [];
        }

        $this->entity = $entity;

        $tierPrices = [];
        foreach ($options as $option) {
            if (empty($option['values'])) {
                continue;
            }
            foreach ($option['values'] as $value) {
                if (!isset($value[$this->getName()])) {
                    continue;
                }
                $tierPrices[$value['mageworx_option_type_id']] = $value[$this->getName()];
            }
        }

        return $this->collectTierPrices($tierPrices);
    }

    /**
     * Collect tier prices
     *
     * @param array $items
     * @return array
     */
    protected function collectTierPrices($items)
    {
        $data = [];

        foreach ($items as $itemKey => $itemValue) {
            $data['delete'][] = [
                TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID => $itemKey,
            ];
            $decodedJsonData  = json_decode($itemValue, true);
            if (empty($decodedJsonData) || !is_array($decodedJsonData)) {
                continue;
            }
            foreach ($decodedJsonData as $dataItem) {
                $dateFrom  = $dataItem[TierPriceModel::COLUMN_DATE_FROM] ?: null;
                $dateTo    = $dataItem[TierPriceModel::COLUMN_DATE_TO] ?: null;
                $price     = $dataItem[TierPriceModel::COLUMN_PRICE];
                $priceType = $dataItem[TierPriceModel::COLUMN_PRICE_TYPE];
                if ($priceType == Helper::PRICE_TYPE_PERCENTAGE_DISCOUNT) {
                    $price = abs($price);
                }
                $data['save'][] = [
                    TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID => $itemKey,
                    TierPriceModel::COLUMN_CUSTOMER_GROUP_ID       =>
                        (int)$dataItem[TierPriceModel::COLUMN_CUSTOMER_GROUP_ID],
                    TierPriceModel::COLUMN_PRICE                   => $price,
                    TierPriceModel::COLUMN_PRICE_TYPE              => $priceType,
                    TierPriceModel::COLUMN_QTY                     => $dataItem[TierPriceModel::COLUMN_QTY],
                    TierPriceModel::COLUMN_DATE_FROM               => $dateFrom,
                    TierPriceModel::COLUMN_DATE_TO                 => $dateTo,
                ];
            }
        }
        return $data;
    }

    /**
     * Delete old option value tier prices
     *
     * @param $data
     * @return void
     */
    public function deleteOldData(array $data)
    {
        $mageworxOptionValueIds = [];
        foreach ($data as $dataItem) {
            $mageworxOptionValueIds[] = $dataItem[TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID];
        }
        if (!$mageworxOptionValueIds) {
            return;
        }
        $tableName  = $this->resource->getTableName($this->getTableName());
        $conditions = TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID .
            " IN (" . "'" . implode("','", $mageworxOptionValueIds) . "'" . ")";
        $this->resource->getConnection()->delete($tableName, $conditions);
    }

    /**
     * {@inheritdoc}
     */
    public function prepareDataForFrontend($object)
    {
        $tierPrices = $this->tierPriceModel->getSuitableTierPrices($object);
        if (!$tierPrices) {
            return [];
        } else {
            return [$this->getName() => json_encode($tierPrices)];
        }
    }

    /**
     * Process attribute in case of product/group duplication
     *
     * @param string $newMageworxId
     * @param string $oldMageworxId
     * @param string $entityType
     * @return void
     */
    public function processDuplicate($newMageworxId, $oldMageworxId, $entityType = 'product')
    {
        $connection = $this->resource->getConnection();
        $table      = $this->resource->getTableName($this->getTableName($entityType));

        $select = $connection->select()->from(
            $table,
            [
                new \Zend_Db_Expr("'" . $newMageworxId . "'"),
                TierPriceModel::COLUMN_CUSTOMER_GROUP_ID,
                TierPriceModel::COLUMN_QTY,
                TierPriceModel::COLUMN_PRICE,
                TierPriceModel::COLUMN_PRICE_TYPE,
                TierPriceModel::COLUMN_DATE_FROM,
                TierPriceModel::COLUMN_DATE_TO
            ]
        )->where(
            TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID . ' = ?',
            $oldMageworxId
        );

        $insertSelect = $connection->insertFromSelect(
            $select,
            $table,
            [
                TierPriceModel::COLUMN_MAGEWORX_OPTION_TYPE_ID,
                TierPriceModel::COLUMN_CUSTOMER_GROUP_ID,
                TierPriceModel::COLUMN_QTY,
                TierPriceModel::COLUMN_PRICE,
                TierPriceModel::COLUMN_PRICE_TYPE,
                TierPriceModel::COLUMN_DATE_FROM,
                TierPriceModel::COLUMN_DATE_TO
            ]
        );
        $connection->query($insertSelect);
    }
}

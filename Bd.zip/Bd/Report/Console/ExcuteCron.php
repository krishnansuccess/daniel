<?php

namespace Bd\Report\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\State as AppState;

class ExcuteCron extends Command {

    protected $appState;
    protected $orderByVendorReport;

    public function __construct(AppState $appState, \Bd\Report\Cron\OrderByVendorReport $orderByVendorReport) {
        parent::__construct();
        $this->appState = $appState;
        $this->orderByVendorReport = $orderByVendorReport;
    }

    protected function configure() {
        $this->setName('bd:excute');
        $this->setDescription('Excutes the cron');
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $this->appState->setAreaCode('crontab');

        try {
            $this->orderByVendorReport->execute();
        } catch (\Exception $e) {
            $output->writeln( "--Exception" . $e->getMessage());
        }

        $output->writeln("Category assigned successfully");
    }

}

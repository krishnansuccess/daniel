<?php
namespace Bd\Report\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {


           $setup->getConnection()->addColumn(
                $setup->getTable('sales_order'), 'is_exported',
                ['type' => Table::TYPE_BOOLEAN,
                'length' => null,
                'option' => [ 'nullable' => false, 'default' => 0],
                'default' => 0,
                'comment' => 'Is Exported']);



         $installer    = $setup;
        $installer->startSetup();
        /**
         * Create table 'Vendor order report history'
         */
        $tableName    = $installer->getTable('vendor_order_report_history');
        $tableComment = 'Vendor order report history';
        $columns      = array(
            'id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Id',
            ),

            'order_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Order Id',
            ),
            'vendor_code' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Vendor Code',
            ),
            'email' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Email',
            ),
            'file' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 400,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Email',
            ),

        );
        // Table creation
        $table        = $installer->getConnection()->newTable($tableName);
        $foreignKeys  = array(  'order_id'=>array('ref_table' => 'sales_order', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_CASCADE),

        );
        // Columns creation
        foreach ($columns as $name => $values) {
            $table->addColumn(
                $name, $values['type'], $values['size'], $values['options'],
                $values['comment']
            );
        }
        // Foreign keys creation
        foreach ($foreignKeys as $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column,
                    $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column, $foreignKey['ref_table'], $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }
        // Table comment
        $table->setComment($tableComment);
        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);


    }
}
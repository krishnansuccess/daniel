<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Bd\Report\Model\Mail;

/**
 * Description of TransportBuilder
 *
 * @author Bd
 */
class TransportBuilder extends \Magento\Framework\Mail\Template\TransportBuilder {

    protected static $mimeTypes = [
        'xml' => 'text/xml',
        'pdf' => 'application/pdf',
        'json' => 'application/json',
        'csv' => 'text/csv',
    ];

    /**
     * @param Api\AttachmentInterface $attachment
     */
    public function addAttachment($fileName, $attachedName, $fileType) {
        $this->message->createAttachment(
        $fileName, self::$mimeTypes[$fileType],
         \Zend_Mime::DISPOSITION_ATTACHMENT,
                \Zend_Mime::ENCODING_BASE64,
                $attachedName
        );
        return $this;
    }

}

<?php

namespace Bd\Report\Model;

use \Magento\Framework\Model\AbstractModel;

/**
 * Description of Vendor
 *
 * @author Bd
 */
class Vendor extends AbstractModel
{

    protected function _construct()
    {
        $this->_init('Bd\Report\Model\ResourceModel\Vendor');
    }
}

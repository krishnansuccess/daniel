<?php

namespace Bd\Report\Model\Export;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Simplexml\Element;

/**
 * Class ConvertToXml
 */
class ConvertToXml {

    /**
     * @var WriteInterface
     */
    protected $directory;

    /**
     * @var MetadataProvider
     */
    protected $metadataProvider;

    /**
     * @var int|null
     */
    protected $pageSize = null;

    /**
     * @param Filesystem $filesystem
     * @param Filter $filter
     * @param MetadataProvider $metadataProvider
     * @param int $pageSize
     */
    public function __construct(
    Filesystem $filesystem, $pageSize = 200
    ) {

        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);

        $this->pageSize = $pageSize;
    }

    /**
     * Returns Xml file
     *
     * @return array
     * @throws LocalizedException
     */
    public function getXmlFile($items, $fileNameSuffix, $headers = []) {


       // $name = md5(microtime());
        $name='';
        $file = 'export/' . $fileNameSuffix . $name . '.Xml';

        $this->directory->create('export');
        $stream = $this->directory->openFile($file, 'w+');
        $stream->lock();

        $totalCount = count($items);
        if ($totalCount > 0) {
            $xml = $this->arrayToXml($items);
            $stream->write($xml->asNiceXml());
        }
        $stream->unlock();
        $stream->close();

        return [
            'type' => 'filename',
            'value' => $file,
            'rm' => true  // can delete file after use
        ];
    }

    private function arrayToXml($array, $rootElement = null, $xml = null) {

        $_xml = $xml;

        if ($_xml === null) {
            $_xml = new Element($rootElement !== null ? $rootElement : '<root/>');
        }

        foreach ($array as $k => $v) {
            if (is_array($v)) { //nested array
                $this->arrayToXml($v, $k, $_xml->addChild($k));
            } else {
                $_xml->addChild($k, $v);
            }
        }

        return $_xml;
    }

}

<?php

namespace Bd\Report\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of Vendor
 *
 * @author Bd
 */
class Vendor extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('Vendor_table', 'id');
    }
}

<?php

namespace Bd\Report\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of VendorReport
 *
 * @author Bd
 */
class VendorReport extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('vendor_order_report_history', 'id');
    }
}
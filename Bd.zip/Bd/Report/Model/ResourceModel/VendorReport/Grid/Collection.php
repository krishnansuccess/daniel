<?php

namespace Bd\Report\Model\ResourceModel\VendorReport\Grid;

use Bd\Report\Model\ResourceModel\VendorReport\Collection as ReportCollection;
use Magento\Framework\Api\Search\SearchResultInterface;

/**
 * Description of Collection
 *
 * @author Bd
 */
class Collection extends ReportCollection implements SearchResultInterface
{
    protected $helper;

    protected $_idFieldName = 'id';

    /**
     * @var Api\Search\AggregationInterface
     */
    protected $aggregations;

    /**
     * @var Api\Search\SearchCriteriaInterface
     */
    protected $searchCriteria;

    /**
     * @var int
     */
    protected $totalCount;

    /**
     * Resource initialization
     * @return $this
     */
    public function __construct(
    \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
    \Psr\Log\LoggerInterface $logger,
    \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
    \Magento\Framework\Event\ManagerInterface $eventManager,
    $mainTable, $eventPrefix,
    $eventObject, $resourceModel,
    $model = 'Magento\Framework\View\Element\UiComponent\DataProvider\Document',
    $connection = null,
    \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    )
    {

        parent::__construct(
            $entityFactory, $logger, $fetchStrategy, $eventManager, $connection,
            $resource
        );
        $this->_eventPrefix = $eventPrefix;
        $this->_eventObject = $eventObject;
        $this->_init($model, $resourceModel);
        $this->setMainTable($mainTable);
    }

    /**
     * @return \Magento\Framework\Api\Search\AggregationInterface
     */
    public function getAggregations()
    {
        return $this->aggregations;
    }

    /**
     * @param \Magento\Framework\Api\Search\AggregationInterface $aggregations
     * @return void
     */
    public function setAggregations($aggregations)
    {
        $this->aggregations = $aggregations;
    }

    /**
     * @return \Magento\Framework\Api\Search\SearchCriteriaInterface|null
     */
    public function getSearchCriteria()
    {
        return $this->searchCriteria;
    }

    /**
     * @return int
     */
    public function getTotalCount()
    {
        if (!$this->totalCount) {
            $this->totalCount = $this->getSize();
        }
        return $this->totalCount;
    }

    /**
     * Set items list.
     *
     * @param Document[] $items
     * @return $this
     */
    public function setItems(array $items = null)
    {
        if ($items) {
            foreach ($items as $item) {
                $this->addItem($item);
            }
            unset($this->totalCount);
        }
        return $this;
    }

    /**
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return $this
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function setSearchCriteria(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $this->searchCriteria = $searchCriteria;
        return $this;
    }

    /**
     * @param int $totalCount
     * @return $this
     */
    public function setTotalCount($totalCount)
    {
        $this->totalCount = $totalCount;
        return $this;
    }

    protected function _initSelect()
    {
        parent::_initSelect();


        $this->getSelect()->joinInner(array('order' => 'sales_order'),
                'order.entity_id=main_table.order_id',
                array('status', 'created_at'))
            ;

      //  $this->getSelect()->group('entity_id');
       // $unionSelect = clone $this->getSelect();
       // $this->getSelect()->reset()->from($unionSelect);
        return $this;
    }
}
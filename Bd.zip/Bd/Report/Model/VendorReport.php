<?php

namespace Bd\Report\Model;

use \Magento\Framework\Model\AbstractModel;

/**
 * Description of VendorReport
 *
 * @author Bd
 */
class VendorReport extends AbstractModel
{

    protected function _construct()
    {
        $this->_init('Bd\Report\Model\ResourceModel\VendorReport');
    }
}
<?php

namespace Bd\Report\Model\Export;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
/**
 * Class ConvertToJson
 */
class ConvertToJson
{
    /**
     * @var WriteInterface
     */
    protected $directory;

    /**
     * @var MetadataProvider
     */
    protected $metadataProvider;

    /**
     * @var int|null
     */
    protected $pageSize = null;

    /**
     * @param Filesystem $filesystem
     * @param Filter $filter
     * @param MetadataProvider $metadataProvider
     * @param int $pageSize
     */
    public function __construct(
        Filesystem $filesystem,

        $pageSize = 200
    ) {

        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);

        $this->pageSize = $pageSize;
    }

    /**
     * Returns Json file
     *
     * @return array
     * @throws LocalizedException
     */
    public function getJsonFile($items,$fileNameSuffix,$headers=[])
    {


       // $name = md5(microtime());
        $name='';
        $file = 'export/' .$fileNameSuffix. $name . '.json';

        $this->directory->create('export');
        $stream = $this->directory->openFile($file, 'w+');
        $stream->lock();

        $totalCount = count($items);
        if ($totalCount > 0) {

                $stream->write(json_encode($items));


        }
        $stream->unlock();
        $stream->close();

        return [
            'type' => 'filename',
            'value' => $file,
            'rm' => true  // can delete file after use
        ];
    }

}

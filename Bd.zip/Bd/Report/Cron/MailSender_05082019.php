<?php

namespace Bd\Report\Model\Mail;

/**
 * Description of MailSender
 *
 * @author Bd
 */
class MailSender {

    protected $scopeConfig;
    protected $transportBuilder;
    protected $mathRandom;
    protected $storeManager;
    protected $directoryList;

    public function __construct(
    \Bd\Report\Model\Mail\TransportBuilder $transportBuilder, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Framework\Math\Random $mathRandom, \Magento\Framework\Filesystem\DirectoryList $directoryList) {
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->mathRandom = $mathRandom;
        $this->directoryList = $directoryList;
    }

    public function send($file, $filetype='csv',$email = 'dhaneeshvj@gmail.com') {
        $fileName="OrderDetails".$filetype;
        
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $templateId = "vendor_order_report_template";
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND,
            'store' => $this->storeManager->getStore()->getId());
        $sender = [
            'email' => $this->scopeConfig->getValue(
                    "trans_email/ident_sales/email", $storeScope
            ),
            'name' => $this->scopeConfig->getValue(
                    "trans_email/ident_sales/name", $storeScope
            )
        ];
        $mails = $email);

        try {
            $transport = $this->transportBuilder
                    ->setTemplateIdentifier($templateId) // this code we have mentioned in the email_templates.xml
                    ->setTemplateOptions($templateOptions)
                    ->setFrom($sender)
                    ->addTo($mails)
                    ->addAttachment(file_get_contents($this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR) . '/' . $file), $fileName,$filetype)
                    ->getTransport();

            $transport->sendMessage();
        } catch (\Exception $e) {
            throw $e;
        }
    }

}

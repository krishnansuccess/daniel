<?php

namespace Bd\Report\Cron;

use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Bd\Report\Model\Export\ConvertToCsv;
use Bd\Report\Model\Export\ConvertToJson;
use Bd\Report\Model\Export\ConvertToXml;
use Bd\Report\Model\VendorReportFactory;
use Magento\Sales\Model\OrderFactory;

class OrderByVendorReport {

    protected $orderCollectionFactory;
    protected $convertToCsv;
    protected $convertToJson;
    protected $convertToXml;
    protected $vendorReportFactory;
    protected $orderFactory;

    /**
     * Constructor
     *
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(OrderFactory $orderFactory, VendorReportFactory $vendorReportFactory, ConvertToXml $convertToXml, ConvertToJson $convertToJson, ConvertToCsv $convertToCsv, OrderCollectionFactory $orderCollectionFactory) {
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->convertToCsv = $convertToCsv;
        $this->convertToJson = $convertToJson;
        $this->convertToXml = $convertToXml;
        $this->vendorReportFactory = $vendorReportFactory;
        $this->orderFactory = $orderFactory;
    }

    /**
     * Execute the cron
     *
     * @return void
     */
    public function execute() {
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addFieldTofilter('is_exported', 0);
        foreach ($orderCollection as $order) {

            $orderData = $this->getOrderArray($order);

            foreach ($orderData['vendors'] as $vendor) {

                $filteredOrder = array_filter($orderData['orderData'], function($v, $k) use ($vendor) {
                    return $v['ITEMVEND'] == $vendor;
                }, ARRAY_FILTER_USE_BOTH);

                $fileName = "";

                $fileName = $this->convertToCsv->getCsvFile($filteredOrder, "Bd");
                $fileName = $this->convertToJson->getJsonFile($filteredOrder, "Bd");
                $fileName = $this->convertToXml->getXmlFile($filteredOrder, "Bd");

                $vendorReport = $this->vendorReportFactory->create();
                $vendorReport->setOrderId($order->getId());
                $vendorReport->setVendorCode($vendor);
                $vendorReport->setEmail('krishnan.success21@gmail.com');
                $vendorReport->setFile($fileName['value']);
                $vendorReport->save();
            }
            $order = $this->orderFactory->create();
            $order->setIsExported(1);
            //$order->save();
        }
        echo $orderCollection->getSize();
        exit;
    }

    private function getOrderArray($order) {

        $billingAddress = $order->getBillingAddress();
        $shippingAddress = $order->getShippingAddress();
        $payment = $order->getPayment();

        $orderItems = $order->getItems();
        $result = [];
        $i = 0;
        $venders = [];
        foreach ($orderItems as $orderItem) {
            echo $i;
            $venders[] = $orderItem->getSku();
            $result['orderData'][$i]['ORDERNO'] = $order->getIncrementId();
            $result['orderData'][$i]['ORDERDT'] = $order->getCreatedAtFormatted(1);
            $result['orderData'][$i]['BILLTONAME'] = $billingAddress->getFirstname() . " " . $billingAddress->getLastname();
            $billStreet = $billingAddress->getStreet();
            $result['orderData'][$i]['BILLTOADDR1'] = $billStreet[0];
            $result['orderData'][$i]['BILLTOADDR2'] = isset($billStreet[1]) ? $billStreet[1] : "";
            $result['orderData'][$i]['BILLTOCITY'] = $billingAddress->getCity();
            $result['orderData'][$i]['BILLTOSTATE'] = $billingAddress->getRegion();
            $result['orderData'][$i]['BILLTOZIP'] = $billingAddress->getPostcode();
            $result['orderData'][$i]['BILLTOCNTRY'] = $billingAddress->getCountryId();
            $result['orderData'][$i]['SHIPTONAME'] = $shippingAddress->getFirstname() . " " . $shippingAddress->getLastname();
            $shipStreet = $shippingAddress->getStreet();
            $result['orderData'][$i]['SHIPTOADDR1'] = $shipStreet[0];
            $result['orderData'][$i]['SHIPTOADDR2'] = isset($shipStreet[1]) ? $shipStreet[1] : "";
            ;
            $result['orderData'][$i]['SHIPTOCITY'] = $shippingAddress->getCity();
            $result['orderData'][$i]['SHIPTOSTATE'] = $shippingAddress->getRegion();
            $result['orderData'][$i]['SHIPTOZIP'] = $shippingAddress->getPostcode();
            $result['orderData'][$i]['SHIPTOCNTRY'] = $shippingAddress->getCountryId();
            $result['orderData'][$i]['SHIPTYPE'] = $shippingAddress->getIncrementId();
            $result['orderData'][$i]['CUSTPHONE'] = $shippingAddress->getTelephone();
            $result['orderData'][$i]['CUSTEMAIL'] = $order->getCustomerEmail();

            /* if(isset($result['orderData'][$i]['NUMITEMS']))
              $result['orderData'][$i]['NUMITEMS']++;
              else
              $result['orderData'][$i]['NUMITEMS']=1;
             */

            $result['orderData'][$i]['SUBTOTAL'] = $order->getSubtotal();
            $result['orderData'][$i]['TAX'] = $order->getTaxAmount();
            $result['orderData'][$i]['SHIPPING'] = $order->getShippingAmount();
            $result['orderData'][$i]['TOTAL'] = $order->getGrandTotal();
            $result['orderData'][$i]['PAYMENTTYPE'] = $payment->getMethod();
            $result['orderData'][$i]['PAYMENTREF'] = $order->getIncrementId();
            $result['orderData'][$i]['PRINTCOMMENT'] = $order->getIncrementId();
            $result['orderData'][$i]['PROMOCODE'] = $order->getCouponCode();
            $result['orderData'][$i]['COMMENT'] = $order->getIncrementId();
            $result['orderData'][$i]['ITEMNO'] = $orderItem->getSku();
            $result['orderData'][$i]['ITEMDESC'] = $orderItem->getDescription();
            $result['orderData'][$i]['ITEMQTY'] = $orderItem->getQtyOrdered();
            $result['orderData'][$i]['ITEMPRICE'] = $orderItem->getPrice();
            $result['orderData'][$i]['ITEMVEND'] = $orderItem->getSku();

            $i++;
        }
        $result['vendors'] = $venders;
        return $result;
    }

}

<?php

namespace Bd\CustomOrder\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;


interface CustomOptionSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get options list.
     *
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface[]
     */
    public function getItems();

    /**
     * Set options list.
     *
     * @param \Bd\CustomOrder\Api\Data\CustomOptionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

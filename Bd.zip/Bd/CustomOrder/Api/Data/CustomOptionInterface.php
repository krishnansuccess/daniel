<?php

namespace Bd\CustomOrder\Api\Data;


interface CustomOptionInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ID                  = 'id';
    const SKU               = 'sku';
    const OPTIONS           = 'options';
    /**#@-*/

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get sku
     *
     * @return string
     */
    public function getSku();

    /**
     * Get options
     *
     * @return mixed|null
     */
    public function getOptions();


    /**
     * Set ID
     *
     * @param int $id
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setId($id);

    /**
     * Set sku
     *
     * @param string $sku
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setSku($sku);

    /**
     * Set options
     *
     * @param mixed $options
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setOptions($options);
}

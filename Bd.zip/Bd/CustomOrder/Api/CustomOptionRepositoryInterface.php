<?php

namespace Bd\CustomOrder\Api;

use Magento\Framework\Api\SearchCriteriaInterface;


interface CustomOptionRepositoryInterface
{
    /**
     * Save customOption.
     *
     * @param \Bd\CustomOrder\Api\Data\CustomOptionInterface $customOrder
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption);

    /**
     * Retrieve customOption.
     *
     * @param int $customOptionId
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($customOptionId);

    /**
     * Retrieve customOptions matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bd\CustomOrder\Api\Data\CustomOptionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete customOption.
     *
     * @param \Bd\CustomOrder\Api\Data\CustomOptionInterface $customOrder
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption);

    /**
     * Delete customOption by ID.
     *
     * @param int $customOptionId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($customOptionId);
}

<?php

namespace Bd\CustomOrder\Controller\Add;

class Index extends \Magento\Framework\App\Action\Action {

    protected $cart;
    protected $productRepository;
    protected $customOptionRepository;

    public function __construct(
        \Bd\CustomOrder\Api\CustomOptionRepositoryInterface $customOptionRepository,
    \Magento\Framework\App\Action\Context $context, \Magento\Checkout\Model\Cart $cart, \Magento\Catalog\Api\ProductRepositoryInterface $productRepository, \Magento\Checkout\Model\Session $checkoutSession, array $data = []) {

        $this->cart = $cart;
        $this->customOptionRepository=$customOptionRepository;
        $this->productRepository = $productRepository;
        $this->checkoutSession = $checkoutSession;
        parent::__construct($context);
    }

    public function execute() {

        $data = $data = json_decode($this->getRequest()->getParam('data'), true);
        $sku = $data['sku'];
        /*$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customOption=$objectManager->get('Bd\CustomOrder\Model\CustomOptionFactory')->create();
        $customOption->setSku($sku);
        $customOption->setOptions($data['custom_option']);
        print_r($customOption->getData());
        exit;
        $this->customOptionRepository->save($customOption);
        $customOptionId=$customOption->getId();*/

        $customOptionId=$data['custom_option_id'];


        $_product = $this->productRepository->get($sku);
        $this->cart->addProduct($_product, ['qty' => 1]);
        $this->cart->save();
        $quote = $this->checkoutSession->getQuote();
        $quoteItems = $quote->getAllItems();
        foreach ($quoteItems as $item) {
            if ($item->getProduct()->getSku() == $sku) {
                // $customOption=$this->customOptionRepository->getById($customOptionId);
                $item = ( $item->getParentItem() ? $item->getParentItem() : $item );

                $item->setCustomOption($customOption->getOptions());

                // $options=json_decode($customOption->getOptions(),true);;


                // $price = $options['price']; //set your price here
                // //var_dump($price); exit;
                // $item->setCustomPrice($price);
                // $item->setOriginalCustomPrice($price);
                // $item->getProduct()->setIsSuperMode(true);

                $item->save();
                break;
                $this->customOptionRepository->delete($customOption);
                break;
            }
        }
        $quote->save();
        $this->_redirect('checkout/cart/');
        // return $this->resultPageFactory->create();
    }

}

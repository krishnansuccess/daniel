function AddProduct(data) {

    var form = document.createElement('form');
    form.setAttribute('action', 'customorder/add/index');
    form.setAttribute('method', 'POST');
    var input1 = document.createElement('input');
    input1.setAttribute('type', 'text');
    input1.setAttribute('name', 'data');
    input1.setAttribute('value', JSON.stringify(data));
    form.appendChild(input1);
    document.body.appendChild(form);
    jQuery(form).submit();
    jQuery(form).css('display', 'none');
}


<?php

namespace Bd\CustomOrder\Model\ResourceModel\CustomOption;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Description of Collection
 *
 * @author Bd
 */
class Collection extends AbstractCollection
{

    protected function _construct()
    {
        $this->_init('Bd\CustomOrder\Model\CustomOption',
            'Bd\CustomOrder\Model\ResourceModel\CustomOption');
    }
}

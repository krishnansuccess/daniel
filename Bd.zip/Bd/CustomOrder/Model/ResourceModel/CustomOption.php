<?php

namespace Bd\CustomOrder\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of CustomOption
 *
 * @author Bd
 */
class CustomOption extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('custom_order_options', 'id');
    }
}

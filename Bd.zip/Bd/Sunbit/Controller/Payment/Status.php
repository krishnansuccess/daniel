<?php


namespace Bd\Sunbit\Controller\Payment;
use Magento\Sales\Model\Order;
use Magento\Framework\Exception\NoSuchEntityException;

class Status extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $jsonHelper;
    protected $quoteRepository;
    protected $serializer;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Catalog\Model\Product $product,
        \Magento\Quote\Model\QuoteFactory $quote,
  \Magento\Framework\Serialize\SerializerInterface $serializer,
\Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->jsonHelper = $jsonHelper;
        $this->quoteRepository = $quoteRepository;
        $this->cart = $cart;
        $this->_addressFactory = $addressFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        $this->_storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->_product = $product;
        $this->quote = $quote;
$this->serializer=$serializer;
        $this->productRepository = $productRepository;
        $this->customerRepository = $customerRepository;
        parent::__construct($context);
    }

public function addOrderItem($orderItem, $cart,$qtyFlag = null)
    {
        /* @var $orderItem \Magento\Sales\Model\Order\Item */
        if ($orderItem->getParentItem() === null) {
            $storeId = $this->_storeManager->getStore()->getId();
            try {
                /**
                 * We need to reload product in this place, because products
                 * with the same id may have different sets of order attributes.
                 */
                $product = $this->productRepository->getById($orderItem->getProductId(), false, $storeId, true);
            } catch (NoSuchEntityException $e) {
                return $cart;
            }
            $info = $orderItem->getProductOptionByCode('info_buyRequest');
	$additionalOptions=$orderItem->getProductOptionByCode('additional_options');
 	$product->addCustomOption('additional_options', $this->serializer->serialize($additionalOptions));
            $info = new \Magento\Framework\DataObject($info);
            if ($qtyFlag === null) {
                $info->setQty($orderItem->getQtyOrdered());
            } else {
                $info->setQty(1);
            }

            $cart->addProduct($product, $info);
        }
        return $cart;
    }


    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $lastorderId = $this->_checkoutSession->getLastOrderId();
        $order = $this->orderRepository->get($lastorderId);
        $cart = $this->_objectManager->get(\Magento\Checkout\Model\Cart::class);
        // $formKey = $objectManager->create('\Magento\Framework\Data\Form\FormKey')->getFormKey();
        foreach ($order->getAllItems() as $item) {
            try {
                $this->addOrderItem($item,$cart);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->_objectManager->get(\Magento\Checkout\Model\Session::class)->getUseNotice(true)) {
                    $this->messageManager->addNoticeMessage($e->getMessage());
                } else {
                    $this->messageManager->addErrorMessage($e->getMessage());
                }
                return $resultRedirect->setPath('*/*/history');
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage(
                    $e,
                    __('We can\'t add this item to your shopping cart right now.')
                );
                return $resultRedirect->setPath('checkout/cart');
            }
        }
        $cart->save();
        $orderState = 'dpaypending';
        $order->setState($orderState)->setStatus('dpaypending');
        $order->setSendEmail(0);
        $order->save();

  echo "Logiii Rsponse"; exit;
        $params = $this->getRequest()->getParams();
        try {

      $url="https://api-demo.sunbit.com/epay-service/api/v1/epay";  
$ch = curl_init( $url );
# Setup request to send json via POST.
$payload = json_encode( 
        array( 
        "transactionId"=> "completed-gthftredxserrr",
    "amount"=> 1008,
    "location"=> "Location1",
    "customerDetails"=> array (
        "firstName"=>"John",
        "lastName"=>"Doe",
        "email"=>"john.doe@emailaddress.email",
        "phone"=>"303-988-8945",
        "addressDetails"=> array (
            "address"=> "2491  Tavern Place ",
            "city"=> "Lakewood",
            "state"=> "CO",
    "zipCode"=> "80227")),
            "items"=> array (
        
            "serialNumber"=> "1111111",
            "amount"=> 166
  )
        ) 
        
        );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, 
        array(
            'Content-Type:application/json',
            'sunbit-key: XjwsWCKgoEWTNHzztgOeyUwq0Ys7jTUc',
    'sunbit-secret: XDVj0aPCcSxEK1LpFcAvkd9RAHlOQ45D' ));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
echo "Logiii Rsponse"." <pre>$result</pre>";

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            return $this->jsonResponse($e->getMessage());
        }
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}

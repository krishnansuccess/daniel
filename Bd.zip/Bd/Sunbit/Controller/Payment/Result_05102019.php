<?php

namespace Bd\Daniel\Controller\Payment;

class Result extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $jsonHelper;
    protected $cart;
    protected $orderRepository;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Cart $cart
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->cart = $cart;
        $this->orderRepository=$orderRepository;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $param = $this->getRequest()->getParam('success');
        $orderId = $this->getRequest()->getParam('orderId');
        $order = $this->orderRepository->get($lastorderId);
        $order->setSendEmail(1);
        $this->orderRepository->save($order);
        $this->cart->truncate();
        $this->cart->save();
    }
}
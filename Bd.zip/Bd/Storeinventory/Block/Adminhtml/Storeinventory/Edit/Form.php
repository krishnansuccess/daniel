<?php
namespace Bd\Storeinventory\Block\Adminhtml\Storeinventory\Edit;
 
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{ 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry             $registry
     * @param \Magento\Framework\Data\FormFactory     $formFactory
     * @param array                                   $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        array $data = []
    ) 
    {
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form', 
                            'enctype' => 'multipart/form-data', 
                            'action' => $this->getData('action'), 
                            'method' => 'post'
                        ]
            ]
        );
        // $form->setHtmlIdPrefix('wkgrid_');
        if ($model['STORE_INVENTORY_ID']) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Row Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('STORE_INVENTORY_ID', 'hidden', ['name' => 'STORE_INVENTORY_ID']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add New Item'), 'class' => 'fieldset-wide']
            );
        }
 
        $fieldset->addField(
            'StoreId',
            'text',
            [
                'name' => 'StoreId',
                'label' => __('Store Id'),
                'id' => 'StoreId',
                'title' => __('Store Id'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        if ($model['STORE_INVENTORY_ID']) {
            $fieldset->addField(
                'ProductId',
                'text',
                [
                    'name' => 'ProductId',
                    'label' => __('Product Id'),
                    'id' => 'ProductId',
                    'title' => __('Product Id'),
                    'readonly' => true
                ]
            );
        }
        $fieldset->addField(
            'ProductSku',
            'text',
            [
                'name' => 'ProductSku',
                'label' => __('Product Sku'),
                'id' => 'ProductSku',
                'title' => __('Product Sku'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'Quantity',
            'text',
            [
                'name' => 'Quantity',
                'label' => __('Quantity'),
                'id' => 'Quantity',
                'title' => __('Quantity'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}
<?php

namespace Bd\Storeinventory\Model;

use Magento\Framework\Model\AbstractModel;

class Storeinventory extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Bd\Storeinventory\Model\ResourceModel\Storeinventory');
    }
}
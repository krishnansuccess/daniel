<?php

namespace Bd\Storeinventory\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Storeinventory extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('STORE_INVENTORY', 'STORE_INVENTORY_ID');
    }
}
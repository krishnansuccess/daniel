<?php

namespace Bd\Storeinventory\Controller\Adminhtml\Storeinventory;
use Magento\Framework\Controller\ResultFactory;

class Save extends \Magento\Backend\App\Action
{ 
    /**
     * @var \Bd\Storeinventory\Model\StoreinventoryFactory
     */
    private $storeinventoryFactory;
    protected $_productRepository;
 
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Bd\Storeinventory\Model\StoreinventoryFactory $storeinventoryFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Bd\Storeinventory\Model\StoreinventoryFactory $storeinventoryFactory
    ) {
        parent::__construct($context);
        $this->storeinventoryFactory = $storeinventoryFactory;
        $this->_productRepository = $productRepository;
    }
 
    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('storeinventory/storeinventory/addnew');
            return;
        }
        $sku = $data['ProductSku'];
        try {
            $rowData = $this->storeinventoryFactory->create();
            $rowData->setData($data);
            $product = $this->_productRepository->get($sku);
            if (isset($data['STORE_INVENTORY_ID'])) {
                $rowData->setData('STORE_INVENTORY_ID', $data['STORE_INVENTORY_ID']);
            }
            $rowData->setData('ProductId', $product->getId());
            $rowData->save();
            $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e){
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('storeinventory/storeinventory/index');
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Bd_STOREINVENTORY::save');
    }
}
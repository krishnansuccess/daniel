<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Ccavenue
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Bd\Daniel\Controller\Payment;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Payment;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order;
//use Webkul\Ccavenue\Logger\Logger;

class Index extends Action
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    const SANDBOX = 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction';
    const PRODUCTION = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var OrderRepositoryInterface
     */
    protected $_orderRepository;

    protected $_ccavenueHelper;
    /**
     * Form factory
     *
     * @var \Magento\Framework\Data\FormFactory
     */
    protected $formFactory;
    /**
     * Form factory
     *
     * @var \Magento\Directory\Model\Country
     */
    protected $_country;
    /**
     * Form factory
     *
     * @var \Magento\Sales\Model\Order
     */
    protected $_order;

    protected $jsonHelper;
    /**
     * @var \Webkul\Ccavenue\Logger\Logger
     */
    private $logger;
    /**
     * @param Context                             $context
     * @param OrderRepositoryInterface            $orderRepository
     * @param \Magento\Checkout\Model\Session     $checkoutSession
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Webkul\Ccavenue\Helper\Data        $ccavenueHelper
     * @param \Magento\Directory\Model\Country    $country
     * @param \Magento\Sales\Model\Order          $order
     * @param Logger                              $logger
     * @param PageFactory                         $resultPageFactory
     */
    public function __construct(
        Context $context,
        OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Data\FormFactory $formFactory,
        //\Webkul\Ccavenue\Helper\Data $ccavenueHelper,
        \Magento\Directory\Model\Country $country,
        \Magento\Sales\Model\Order $order,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper
        //Logger $logger
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_checkoutSession = $checkoutSession;
        $this->_urlBuilder = $context->getUrl();
        $this->formFactory = $formFactory;
        $this->_country = $country;
        $this->_order = $order;
        $this->_resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->jsonHelper = $jsonHelper;
        //$this->_ccavenueHelper = $ccavenueHelper;
        //$this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return                                                                                                                                                                                                                                                                                                                                                                              \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        echo "weld";exit;
        $result=[];


        try {

            $url = "https://daniels.infinitybuss.com/dpay/paymentservices.ashx";

//Store your XML Request in a variable
    $token_input_xml = '<paymentservices><action>START</action><sendinprocesspacket>YES</sendinprocesspacket><transactionid>10000012345</transactionid><purchasetotal>1755.89</purchasetotal><customer><firstname>Daiva</firstname><lastname>Krish</lastname><emailaddr>test@gmail.com</emailaddr></customer><billing><street>chennai</street><city>chennai</city><state>AL</state><zipcode>90025</zipcode></billing><shipping><firstname></firstname><lastname></lastname><sameasbilling>Y</sameasbilling><street></street><city></city><state></state><zipcode>90025</zipcode></shipping></paymentservices>';

$headr = array();
$headr[] = 'Content-type:text/xml';
$headr[]= 'Accept:text/xml';
$headr[] = 'Authorization:Basic 13EA389425F847CD9615C15CA3571CF8';

        //setting the curl parameters.
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)');
        curl_setopt($curl, CURLOPT_POSTFIELDS,
                    $token_input_xml);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 900);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_HTTPHEADER,$headr);
        $token_data = curl_exec($curl);
var_dump($token_data);
//print_r(curl_getinfo($curl));
//die(curl_error($curl));
curl_close($curl);
//  exit;;
        //convert the XML result into array
        $token_array_data = json_decode(json_encode(simplexml_load_string($token_data)), true);

print_r($token_array_data);exit;
     return $this->jsonResponse($token_array_data);

            //return $this->jsonResponse($result); // for token return


        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            return $this->jsonResponse($e->getMessage());
        }
    }


    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }

}

<?php

namespace Bd\Daniel\Controller\Payment;

class Result extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $jsonHelper;
    protected $cart;
    protected $orderRepository;
	protected $_checkoutSession;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Cart $cart,
		\Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->cart = $cart;
		$this->_checkoutSession = $checkoutSession;
        $this->orderRepository=$orderRepository;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $lastorderId = $this->_checkoutSession->getLastOrderId();
        $order = $this->orderRepository->get($lastorderId);
        $order->setSendEmail(1);
        $this->orderRepository->save($order);
        $this->cart->truncate();
        $this->cart->save();
    }
}
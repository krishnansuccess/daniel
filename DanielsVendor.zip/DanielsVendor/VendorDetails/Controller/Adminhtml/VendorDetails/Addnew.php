<?php

namespace DanielsVendor\VendorDetails\Controller\Adminhtml\VendorDetails;
use Magento\Framework\Controller\ResultFactory;

class Addnew extends \Magento\Backend\App\Action
{
	/**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;
 
    /**
     * @var \DanielsVendor\VendorDetails\Model\VendorDetailsFactory
     */
    private $vendordetailsFactory;
 
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \DanielsVendor\VendorDetails\Model\VendorDetailsFactory $vendordetailsFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \DanielsVendor\VendorDetails\Model\VendorDetailsFactory $vendordetailsFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->vendordetailsFactory = $vendordetailsFactory;
    }
 
    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $rowId = (int) $this->getRequest()->getParam('id');
        $rowData = $this->vendordetailsFactory->create();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        if ($rowId) {
		   $rowData = $rowData->load($rowId);
           $rowTitle = $rowData->getTitle();
           if (!$rowData['ID']) {
               $this->messageManager->addError(__('row data no longer exist.'));
               $this->_redirect('vendordetails/vendordetails/index');
               return;
           }
       }
 
       $this->coreRegistry->register('row_data', $rowData);
       $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
       $title = $rowId ? __('Edit Row Data ').$rowTitle : __('Add New Item');
       $resultPage->getConfig()->getTitle()->prepend($title);
       return $resultPage;
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('DanielsVendor_VendorDetails::vendordetails');
    }
}
<?php

namespace DanielsVendor\VendorDetails\Controller\Adminhtml\VendorDetails;
use Magento\Framework\Controller\ResultFactory;

class Save extends \Magento\Backend\App\Action
{ 
    /**
     * @var \DanielsVendor\VendorDetails\Model\VendorDetailsFactory
     */
    private $vendordetailsFactory;
    protected $_productRepository;
 
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \DanielsVendor\VendorDetails\Model\VendorDetailsFactory $vendordetailsFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \DanielsVendor\VendorDetails\Model\VendorDetailsFactory $vendordetailsFactory
    ) {
        parent::__construct($context);
        $this->vendordetailsFactory = $vendordetailsFactory;
        $this->_productRepository = $productRepository;
    }
 
    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('vendordetails/vendordetails/addnew');
            return;
        }
        //$sku = $data['vendor_mail_id'];
        try {
            $rowData = $this->vendordetailsFactory->create();
            $rowData->setData($data);
            //$product = $this->_productRepository->get($sku);
            if (isset($data['ID'])) {
                $rowData->setData('ID', $data['ID']);
            }
            $rowData->setData('vendor_code', $data['vendor_code']);
            $rowData->save();
            $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e){
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('vendordetails/vendordetails/index');
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('DanielsVendor_VendorDetails::save');
    }
}
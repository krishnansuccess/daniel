<?php
namespace DanielsVendor\VendorDetails\Block\Adminhtml\VendorDetails\Edit;
 
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{ 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry             $registry
     * @param \Magento\Framework\Data\FormFactory     $formFactory
     * @param array                                   $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        array $data = []
    ) 
    {
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form', 
                            'enctype' => 'multipart/form-data', 
                            'action' => $this->getData('action'), 
                            'method' => 'post'
                        ]
            ]
        );
        // $form->setHtmlIdPrefix('wkgrid_');
        if ($model['ID']) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Row Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('ID', 'hidden', ['name' => 'ID']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add New Item'), 'class' => 'fieldset-wide']
            );
        }
 
        $fieldset->addField(
            'vendor_code',
            'text',
            [
                'name' => 'vendor_code',
                'label' => __('Vendor Code'),
                'id' => 'vendor_code',
                'title' => __('Vendor Code'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        if ($model['ID']) {
            $fieldset->addField(
                'vendor_mail_id',
                'text',
                [
                    'name' => 'vendor_mail_id',
                    'label' => __('Vendor MailID'),
                    'id' => 'vendor_mail_id',
                    'title' => __('Vendor MailID'),
                    'readonly' => true
                ]
            );
        }
        $fieldset->addField(
            'format',
            'text',
            [
                'name' => 'format',
                'label' => __('Format'),
                'id' => 'format',
                'title' => __('Format'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}
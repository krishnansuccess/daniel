<?php

namespace DanielsVendor\VendorDetails\Model\ResourceModel\VendorDetails;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'DanielsVendor\VendorDetails\Model\VendorDetails',
            'DanielsVendor\VendorDetails\Model\ResourceModel\VendorDetails'
        );
    }
}
<?php

namespace DanielsVendor\VendorDetails\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class VendorDetails extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('Vendor_table', 'ID');
    }
}
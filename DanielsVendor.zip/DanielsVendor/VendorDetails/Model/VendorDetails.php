<?php

namespace DanielsVendor\VendorDetails\Model;

use Magento\Framework\Model\AbstractModel;

class VendorDetails extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('DanielsVendor\VendorDetails\Model\ResourceModel\VendorDetails');
    }
}
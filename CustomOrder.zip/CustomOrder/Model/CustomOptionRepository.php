<?php

namespace Bd\CustomOrder\Model;

use Bd\CustomOrder\Api\Data;
use Bd\CustomOrder\Api\CustomOptionRepositoryInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Bd\CustomOrder\Model\ResourceModel\CustomOption as ResourceCustomOption;
use Bd\CustomOrder\Model\ResourceModel\CustomOption\CollectionFactory as CustomOptionCollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class CustomOptionRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CustomOptionRepository implements CustomOptionRepositoryInterface
{
    /**
     * @var ResourceCustomOption
     */
    protected $resource;

    /**
     * @var CustomOptionFactory
     */
    protected $customOptionFactory;

    /**
     * @var CustomOptionCollectionFactory
     */
    protected $customOptionCollectionFactory;

    /**
     * @var Data\CustomOptionSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * @var \Bd\CustomOrder\Api\Data\CustomOptionInterfaceFactory
     */
    protected $dataCustomOptionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @param ResourceCustomOption $resource
     * @param CustomOptionFactory $customOptionFactory
     * @param Data\CustomOptionInterfaceFactory $dataCustomOptionFactory
     * @param CustomOptionCollectionFactory $customOptionCollectionFactory
     * @param Data\CustomOptionSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceCustomOption $resource,
        CustomOptionFactory $customOptionFactory,
        Data\CustomOptionInterfaceFactory $dataCustomOptionFactory,
        CustomOptionCollectionFactory $customOptionCollectionFactory,
        Data\CustomOptionSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,

        CollectionProcessorInterface $collectionProcessor = null
    ) {
        $this->resource = $resource;
        $this->customOptionFactory = $customOptionFactory;
        $this->customOptionCollectionFactory = $customOptionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataCustomOptionFactory = $dataCustomOptionFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->collectionProcessor = $collectionProcessor ?: $this->getCollectionProcessor();
    }

    /**
     * Save CustomOption data
     *
     * @param \Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption
     * @return CustomOption
     * @throws CouldNotSaveException
     */
    public function save(\Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption)
    {

        try {
            $this->resource->save($customOption);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(
                __('Could not save the customOption: %1', $exception->getMessage()),
                $exception
            );
        }
        return $customOption;
    }

    /**
     * Load CustomOption data by given CustomOption Identity
     *
     * @param string $customOptionId
     * @return CustomOption
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($customOptionId)
    {
        $customOption = $this->customOptionFactory->create();
        $customOption->load($customOptionId);
        if (!$customOption->getId()) {
            throw new NoSuchEntityException(__('CustomOption with id "%1" does not exist.', $customOptionId));
        }
        return $customOption;
    }

    /**
     * Load CustomOption data collection by given search criteria
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Bd\CustomOrder\Api\Data\CustomOptionSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $criteria)
    {
        /** @var \Bd\CustomOrder\Model\ResourceModel\CustomOption\Collection $collection */



        $collection = $this->customOptionCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        /** @var Data\CustomOptionSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * Delete CustomOption
     *
     * @param \Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(\Bd\CustomOrder\Api\Data\CustomOptionInterface $customOption)
    {
        try {
            $this->resource->delete($customOption);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the customOption: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * Delete CustomOption by given CustomOption Identity
     *
     * @param string $customOptionId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($customOptionId)
    {
        return $this->delete($this->getById($customOptionId));
    }

    /**
     * Retrieve collection processor
     *
     * @deprecated 101.1.0
     * @return CollectionProcessorInterface
     */
    private function getCollectionProcessor()
    {
        if (!$this->collectionProcessor) {
            $this->collectionProcessor = \Magento\Framework\App\ObjectManager::getInstance()->get(
                'Bd\CustomOrder\Model\Api\SearchCriteria\CustomOptionCollectionProcessor'
            );
        }
        return $this->collectionProcessor;
    }
}

<?php

namespace Bd\CustomOrder\Model;

use Magento\Framework\Model\AbstractModel;
use Bd\CustomOrder\Api\Data\CustomOptionInterface;

/**
 * Description of CustomOption
 *
 * @author Bd
 */
class CustomOption extends AbstractModel implements CustomOptionInterface
{

    protected function _construct()
    {
        $this->_init('Bd\CustomOrder\Model\ResourceModel\CustomOption');
    }

       /**
     * Get ID
     *
     * @return int|null
     */
    public function getId(){
        return $this->getData(self::ID);
    }
    /**
     * Get sku
     *
     * @return string
     */
    public function getSku(){
        return $this->getData(self::SKU);
    }
    /**
     * Get options
     *
     * @return string|null
     */
    public function getOptions(){
        return $this->getData(self::OPTIONS);
    }

    /**
     * Set ID
     *
     * @param int $id
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setId($id){
    	return $this->setData(self::ID, $id);
    }

    /**
     * Set sku
     *
     * @param string $sku
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setSku($sku){
    	return $this->setData(self::SKU, $sku);
    }

    /**
     * Set options
     *
     * @param string $options
     * @return \Bd\CustomOrder\Api\Data\CustomOptionInterface
     */
    public function setOptions($options){
    	return $this->setData(self::OPTIONS, $options);
    }

}

<?php

namespace Bd\CustomOrder\Model\Plugin\Quote;

class OrderItem  {
protected$serializer;
    public function __construct(\Magento\Framework\Serialize\SerializerInterface $serializer) {
       $this->serializer = $serializer;
    }

    public function aroundConvert(
    \Magento\Quote\Model\Quote\Item\ToOrderItem $subject, \Closure $proceed, \Magento\Quote\Model\Quote\Item\AbstractItem $item, $additional = []
    ) {
        /** @var $orderItem Item */
        $orderItem = $proceed($item, $additional);
        // Get Quote Item's additional Options
        $additionalOptions = $item->getOptionByCode('additional_options');

        // Check if there is any additional options in Quote Item
        if (count($additionalOptions) > 0) {
            // Get Order Item's other options
            $options = $orderItem->getProductOptions();
            // Set additional options to Order Item
            $options['additional_options'] = $this->serializer->unserialize($additionalOptions->getValue());
            $orderItem->setProductOptions($options);
        }
        return $orderItem;
    }

}

<?php

namespace Bd\CustomOrder\Controller\Add;

class Index extends \Magento\Framework\App\Action\Action {

    protected $cart;
    protected $productRepository;

    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Checkout\Model\Cart $cart, \Magento\Catalog\Api\ProductRepositoryInterface $productRepository, \Magento\Checkout\Model\Session $checkoutSession, array $data = []) {

        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->checkoutSession = $checkoutSession;
        parent::__construct($context);
    }

    public function execute() {

        $data = $data = json_decode($this->getRequest()->getParam('data'), true);
        $sku = $data['sku'];
    
        $_product = $this->productRepository->get($sku);
        $this->cart->addProduct($_product, ['qty' => 1]);
        $this->cart->save();
        $quote = $this->checkoutSession->getQuote();
        $quoteItems = $quote->getAllItems();
        foreach ($quoteItems as $item) {
            if ($item->getProduct()->getSku() == $sku) {
                $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
                $item->setCustomOption($data['custom_option']);
                $item->getProduct()->setIsSuperMode(true);
                $item->save();
                break;
            }
        }
        $quote->save();
        $this->_redirect('checkout/cart/');
        // return $this->resultPageFactory->create();
    }

}

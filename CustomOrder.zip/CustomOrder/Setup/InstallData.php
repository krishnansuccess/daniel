<?php

namespace Bd\CustomOrder\Setup;

use Magento\Quote\Setup\QuoteSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Sales\Setup\SalesSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;

class InstallData implements InstallDataInterface {

    private $quoteSetupFactory;
    private $salesSetupFactory;

    /**
     * Constructor
     *
     * @param \Magento\Sales\Setup\QuoteSetupFactory $quoteSetupFactory
     */
    public function __construct(
    QuoteSetupFactory $quoteSetupFactory, SalesSetupFactory $salesSetupFactory
    ) {
        $this->quoteSetupFactory = $quoteSetupFactory;

        $this->salesSetupFactory = $salesSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function install(
    ModuleDataSetupInterface $setup, ModuleContextInterface $context
    ) {
        $options = ['type' => 'text', 'length' => null, 'visible' => true, 'grid' => false];
        $quoteSetup = $this->quoteSetupFactory->create(['setup' => $setup]);
        $quoteSetup->addAttribute('quote_item', 'custom_option', $options);

        $options = ['type' => 'text', 'length' => null, 'visible' => true, 'grid' => false];
        $salesSetup = $this->salesSetupFactory->create(['setup' => $setup]);
        $salesSetup->addAttribute('order_item', 'custom_option', $options);
    }

}

<?php

namespace Daiva\PreOrder\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of PreOrder
 *
 * @author Bd
 */
class PreOrder extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('daiva_preorder', 'id');
    }
}

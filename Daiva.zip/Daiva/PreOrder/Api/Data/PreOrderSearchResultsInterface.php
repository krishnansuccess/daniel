<?php

namespace Daiva\PreOrder\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;


interface PreOrderSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get options list.
     *
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface[]
     */
    public function getItems();

    /**
     * Set options list.
     *
     * @param \Daiva\PreOrder\Api\Data\PreOrderInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

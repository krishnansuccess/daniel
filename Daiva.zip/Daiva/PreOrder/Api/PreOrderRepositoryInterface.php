<?php

namespace Daiva\PreOrder\Api;

use Magento\Framework\Api\SearchCriteriaInterface;


interface PreOrderRepositoryInterface
{
    /**
     * Save preOrder.
     *
     * @param \Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder);

    /**
     * Retrieve preOrder.
     *
     * @param int $preOrderId
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($preOrderId);

    /**
     * Retrieve preOrders matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Daiva\PreOrder\Api\Data\PreOrderSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete preOrder.
     *
     * @param \Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder);

    /**
     * Delete preOrder by ID.
     *
     * @param int $preOrderId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($preOrderId);
}

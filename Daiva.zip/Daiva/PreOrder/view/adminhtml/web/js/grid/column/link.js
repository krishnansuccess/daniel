define([
    'Magento_Ui/js/grid/columns/column'
],
        function (Column) {
            'use strict';

            return Column.extend({
                defaults: {
                    bodyTmpl: 'Daiva_PreOrder/grid/column/link',

                },
                getSrc: function (row) {
                return row[this.index + '_src']
                },
                getFieldHandler: function (record) {
                    return false;
                }
            });
        }
);
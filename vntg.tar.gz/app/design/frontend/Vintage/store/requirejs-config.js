var config = {
    paths: {
        slick:'js/slick',
        mmenu:'js/jquery.mmenu.all.min',
	fancy: 'js/fancybox',
    fancyhelpers: 'js/fancybox-media'
    },
    shim: {
            mmenu: {
                       deps: ['jquery']
            }  
    }
};

define(['jquery', 'jquery/ui', 'slick'], function ($) {
    return function () {
        //Also viewed product slider
        if (!$(".product-items").hasClass('slick-initialized')) {
            var assignwidth = $(window).width();
            $(".alsoviewed-products").width(assignwidth);
            $(".product-items").slick({
                infinite: true,
                slidesToShow: 4,
                slidesToScroll: 1,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            infinite: true,
                            slidesToShow: 3,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            infinite: true,
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            infinite: true,
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        }

        //Also like product slider
        if (!$(".slide-like").hasClass('slick-initialized')) {
            var relatedproductwidth = $(window).width();
            $(".top_related_items").width(relatedproductwidth);
            $(".slide-like").slick({
                infinite: true,
                slidesToShow: 4,
                slidesToScroll: 1,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            infinite: true,
                            slidesToShow: 3,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            infinite: true,
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            infinite: true,
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        }
        $(window).resize(function () {
            var w_a = $(window).width();
            $(".alsoviewed-products").width(w_a);
            $('.slide-like').slick('resize');
            var relatedproductwidth = $(window).width();
            $(".top_related_items").width(relatedproductwidth);
            $('.slide-like').slick('resize');
        });
    };
});

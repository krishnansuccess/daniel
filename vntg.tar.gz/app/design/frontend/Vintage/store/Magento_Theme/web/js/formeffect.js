require(['jquery', 'jquery/ui'], function($) {
    $(document).ready(function($) {
        /*input box*/
        var digital_trade_txt_pass = $('.procure-digitalprocurement-index #step-1 input[type="text"], #trade-signup-form input[type="text"], #trade-signup-form input[type="password"], .form-contact-us input[type="text"], .contact-index-index .form-contact-us input[type="email"], .form-contact-us textarea');

        digital_trade_txt_pass.attr('autocomplete', 'off');

        $('body').click(function(e) {
            var container = digital_trade_txt_pass;
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                var formrest = digital_trade_txt_pass.each(function() {
                    var input = $(this);
                    if (input[0].value != '') {
                        $(this).parent().find('.palceholder_temp').addClass('edited');
                    } else {
                        $('.palceholder_temp').removeClass('move_up');
                    }
                });
            }
        });

        digital_trade_txt_pass.bind('paste', function(event) {
            $(this).parent().find('.palceholder_temp').addClass('edited');
        });

        digital_trade_txt_pass.bind('focus', function() {
            $(this).parent().find('.palceholder_temp').addClass('move_up');
            var formrest = digital_trade_txt_pass.each(function() {
                var input = $(this);
                if (input[0].value != '') {
                    $(this).parent().find('.palceholder_temp').addClass('edited');
                } else {
                    digital_trade_txt_pass.click(function(event) {
                        $(this).parent().find('.palceholder_temp').addClass('move_up');
                    });

                    digital_trade_txt_pass.keypress(function() {
                        $(this).parent().find('.palceholder_temp').addClass('edited');
                    });

                    digital_trade_txt_pass.keyup(function() {
                        if (!this.value) {
                            $(this).parent().find('.palceholder_temp').removeClass('edited');
                        }
                    });
                }
            });
        });

        digital_trade_txt_pass.each(function() {
            var placeholder_temp = $(this).attr('placeholder');
            var placeholder_name = $(this).attr('name');
            $('<label class="palceholder_temp" id=' + placeholder_name + '>' + placeholder_temp + '</label>').insertAfter($(this));
        });
        /*if logged in */
        var formrest = digital_trade_txt_pass.each(function() {
            var input = $(this);
            if (input[0].value != '') {
                $(this).parent().find('.palceholder_temp').addClass('edited');
            } else {
                $(this).parent().find('.palceholder_temp').removeClass('edited');
            }
        });
        /* if logged in End */

        /*All Select color chabnge*/
        var allselect = $(".procure-digitalprocurement-index #step-1 select, .procure-digitalprocurement-index #step-2 select, #trade-signup-form select");
        allselect.css({ 'background-color': 'transparent', 'opacity': '1' });


        var allselectcolor = $(".procure-digitalprocurement-index #step-1 select, .procure-digitalprocurement-index #step-2 select, #trade-signup-form select").each(function() {
            var input = $(this);

            if ($(this).children('option:first-child').is(':selected')) {
                input.css({ 'color': '#a2a1a1' });
            } else {
                input.css({ 'color': '#000000 !important' });
            }
            input.change(function() {
                if ($(this).children('option:first-child').is(':selected')) {
                    input.css({ 'color': '#a2a1a1' });
                } else {
                    input.css({ 'color': '#000000' });
                }
            });
        });

        var allselectchild = $(".procure-digitalprocurement-index #step-1 select option:first-child, .procure-digitalprocurement-index #step-2 select option:first-child, #trade-signup-form select option:first-child");

        allselectchild.attr({ 'disabled': 'disabled' }).css({ 'color': '#a2a1a1' });

        $('#is-brand').css({ 'color': '#000 !important' });
        $('#is-brand').change(function() {
            $('#is-brand').css({ 'color': '#000 !important' });
        });
        if ($('#is-brand option:first-child').attr('disabled')) {
            $('#is-brand option:first-child').removeAttr('disabled');
            $('#is-brand').css({ 'color': '#000 !important' });
            $('#is-brand').change(function() {
                $('#is-brand option:first-child').css({ 'color': '#000 !important' });
            });
        }

        /*select country*/
        var countryselect = $('#country');
        countryselect.css({ 'background-color': 'transparent', 'color': '#000' });
        countryselect.each(function() {
            if ($(this).val() != '') {
                $(this).parent().find('.palceholder_temp').addClass('edited');
            }
            var placeholder_temp = $(this).attr('title');
            $('<label class="palceholder_temp">' + placeholder_temp + '*</label>').insertAfter($(this)).css({ 'top': '10px', 'z-index': '1', 'background-color': '#fff' });
        });
        /*select state */
        var stateselect = $('#state');
        stateselect.each(function() {
            if ($(this).val() != '') {
                $(this).parent().find('.palceholder_temp').addClass('edited');
            }
            var placeholder_temp = $(this).attr('title');
            $('<label class="palceholder_temp">' + placeholder_temp + '*</label>').insertAfter($(this)).css({ 'top': '10px', 'z-index': '1', 'background-color': '#fff' });
        });

        $(document).ready(function() {
            /*select size */
            var sizeselect = $('#size');
            sizeselect.each(function() {
                if ($(this).val() != '') {
                    $(this).parent().find('.palceholder_temp').addClass('edited');
                }
                var placeholder_temp = $(this).children('option:first-child').html();
                $('<label class="palceholder_temp">' + placeholder_temp + '</label>').insertAfter($(this)).css({ 'top': '10px', 'z-index': '1', 'background-color': '#fff' });
                $("#size option:first").text("Select");
            });

            /*select role */
            var roleselect = $('#role');
            roleselect.each(function() {
                if ($(this).val() != '') {
                    $(this).parent().find('.palceholder_temp').addClass('edited');
                }
                var placeholder_temp = $(this).children('option:first-child').html();
                $('<label class="palceholder_temp">' + placeholder_temp + '</label>').insertAfter($(this)).css({ 'top': '10px', 'z-index': '1', 'background-color': '#fff' });
                $("#role option:first").text("Select");
            });
        });

    });
});
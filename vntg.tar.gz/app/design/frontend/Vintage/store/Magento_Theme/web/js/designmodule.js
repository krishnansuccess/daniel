define(['jquery', 'jquery/ui', 'mmenu'], function($) {

    var timeOut;
 	if ($('#backtop').length) {
            var scrollTrigger = 100, // px
            backToTop = function () {
                var scrollTop = $(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    $('#backtop').addClass('show');
                } else {
                    $('#backtop').removeClass('show');
                }
            };
            backToTop();
            $(window).on('scroll', function () {
                backToTop();
            });
        }
    $(document).ready(function() {
        if($('.register-menu-link').length > 0){
            $('.panel.header > .toplinkes-left .header li').clone().appendTo('.mob-menu');
        }else if($('.myaccount-menu-link').length > 0){
            $('.panel.header > .toplinkes-left .header .submenu li').clone().appendTo('.mob-menu');
        }
        if($('#my-menu').length >0 ){
            $("#my-menu input").attr("id","mobile-menu-input");
        }
        if($('#mmenuatag').length >0){
            $('#mmenuatag').click(function (){
                $('.mob-menu').removeClass('ui-menu-item');
            });
        }
        $("#mmenu-add-new-a").mmenu({
            "navbars": [
                { 			
                    "position": "top",
                    "content": [
                        "close",
                        "prev",
                        "title"
                    ]
                }
            ] 
        }); 
    });

   
});

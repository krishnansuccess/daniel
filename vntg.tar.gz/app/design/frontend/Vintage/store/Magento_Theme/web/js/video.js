define(['jquery', 'jquery/ui', 'fancy'], function($) {

    $(document).ready(function() {
	$('a.fancybox').fancybox({
		wrapCSS: 'video-fancy',
		padding: 5,
		width: 1280,
		height: 720,
		aspectRatio : true,
    	scrolling   : 'no'		
	});

	var src = jQuery('.video-section').find('img').attr('src');
	jQuery('.video-section').css('backgroundImage','url('+src+')');
	jQuery('.video-section').find('img').hide();
    }); 
});

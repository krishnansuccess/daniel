define(['jquery', 'mage/validation'], function ($)
{
    return function () {
        /*maxlength="10" minlength="10"*/
        window.customphoneno = $(document).ready(function ($) {
            $.validator.addMethod('validate-phoneno', function (value) {
                return value.length > 9 && value.length < 11
                        && value.match(/^\d{10}$/);
            }, $.mage.__('Please Enter 10 Digit Number')); 
            /*End*/
        });
    }
});
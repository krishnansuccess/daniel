define(['jquery', 'Magento_Ui/js/modal/modal'], function ($, modal) {
    return function () {
        $(document).ready(function ($) {
            $('.free-delivery').click(function () {
                var options = {
                                type: 'popup',
                                responsive: true,
                                innerScroll: true,
                                buttons: false,
                                modalClass: 'popup-free-delivery',
                                };
                var popup = modal(options, $('.free-delivery-popup-content'));
                $('.free-delivery-popup-content').modal('openModal');
            });
           
        });
    }
});

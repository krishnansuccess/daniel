define(['jquery', 'Magento_Ui/js/modal/modal'], function($, modal) {
    $(document).ready(function() {
        var options = {
            type: 'popup',
            responsive: true,
            innerScroll: true,
            buttons: false,
            modalClass: 'mcs-login-form',

        };
        var popup = modal(options, $('#mcs-ajaxloginForm'));


        if ($('.guestcheckout-context').length > 0) {
            var url = $('#guestcheckout-url').val();
            $('#guestcheckout-anchor').attr('href', url);
            $('.guestcheckout-context').show();
        } else {
            $('.guestcheckout-context').hide();
        }

        $('.guest-checkout-login').click(function() {
            $('#mcs-ajaxloginForm').modal('openModal');
        });

    });
});
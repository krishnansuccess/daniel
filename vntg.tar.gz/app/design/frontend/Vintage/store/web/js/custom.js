require(['jquery', 'jquery/ui', 'slick'], function($) {
    $(document).ready(function($) {
        new WOW().init();
        /*home banner silder desktop & mobile view */
        if (window.innerWidth > 768) {
            $('.bx-wrapper:has(.banner-slider-desktop)').show();
            $('.bx-wrapper:has(.banner-slider-mobile)').hide();
        } else {
            $('.bx-wrapper:has(.banner-slider-desktop)').hide();
            $('.bx-wrapper:has(.banner-slider-mobile)').show();
        }

        if ($(window).width() <= 1024) {
            $('#assigned').addClass('assignwidth');
        } else if ($(window).width() > 1024) {
            $('#assigned').removeClass('assignwidth');
        }

        /* to find if mobile */
        var win_w = $(window).width();

        var is_mobile = (win_w < 768) ? true : false;
        var is_tab = (win_w < 993) ? true : false;

        /* footer toggle mobile only  */
        if (is_mobile) {
            $('.foot-title').on('click', function() {
                var content = $(this).next('.foot-data');
                $(this).toggleClass('active');
                content.slideToggle('slow');
                $('.foot-data').not(content).slideUp('slow');
                $('.foot-title').not($(this)).removeClass('active');
            });
        }

        /* service menu slider*/
        $('#desktopmenu .nav-3 > ul').slick({
            slidesToShow: 5,
            centerMode:false, 
            infinite: false

        });


        /*prdoct list effect*/
        $('.products-grid .product-item').each(function(index) {
            var _this = this;
            setTimeout(function() { $(_this).addClass('menu-list-fade'); }, 300 * index);
        });
        /*end*/

        /*product detail page product image sticky */
        if (is_mobile) {
            /*$('.top-toolbar span.filter-toggle').prepend('<span class="filtericon"><i class="fa fa-filter" aria-hidden="true"></i></span>');
            $('.top-toolbar span.sort-toggle').prepend('<span class="sorticon"><i class="fa fa-sort-alpha-asc" aria-hidden="true"></i></span>');*/
        }
        /*accordion */
        $('.toggle-head').click(function() {
            var content = $(this).next();
            $(this).toggleClass('active');
            content.slideToggle('slow');
            $('.toggle-content').not(content).slideUp('slow');
            $('.toggle-head').not($(this)).removeClass('active');
        });

        $('.product-info-main .read-more').on('click', function() {
            $(this).toggleClass('active');
            $('.detailed .about_product_tab').slideToggle('slow');
        });

        /*sticky screen for product detail*/
        detail_stiky();

        function detail_stiky() {
            if (!is_mobile) {
                var media = $('.product_detail_container .media');
                if (media.length) {
                    var product_w;
                    product_w = $('.product-info-main').width();

                    var stickyTop = media.offset().top;
                    product_w = $('.product-info-main').width();
                    media.width(product_w + 2);


                    $(window).scroll(function() {
                        var hT = $('.product-info-main').offset().top,
                            hH = $('.product-info-main').outerHeight(),
                            wH = $(window).height(),
                            wS = $(this).scrollTop();


                        if (wS > (hT + hH - wH)) {
                            media.css({ position: "absolute", top: hH - wH });
                        } else {
                            media.width(product_w + 2);
                            if ($(window).scrollTop() >= stickyTop) {
                                media.css({ position: 'fixed', top: '0px' });
                            } else {

                                media.css({ position: "absolute", bottom: '0', top: '0' });

                            }

                        }
                    });
                }
            }
        }
        $(window).resize(function() {
            detail_stiky();
        });
        /*scroll top product detail page*/



        /*read more product decription*/
        var showTotalChar = 250,
            showChar = "Read More (+)",
            hideChar = "Read More (-)";
        $('.value').each(function() {
            var content = $(this).text();
            if (content.length > showTotalChar) {
                var con = content.substr(0, showTotalChar);
                var hcon = content.substr(showTotalChar, content.length - showTotalChar);
                var txt = con + '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
                $(this).html(txt);
            }
        });
        $(".showmoretxt").click(function() {
            if ($(this).hasClass("sample")) {
                $(this).removeClass("sample");
                $(this).text(showChar);
            } else {
                $(this).addClass("sample");
                $(this).text(hideChar);
            }
            $(this).parent().prev().toggle();
            $(this).prev().toggle();
            return false;
        });
        /*convert image to bg*/
        var afford_img = $('.afford a');
        var post_img = $('.blog-post-index .post-image');
        var post_img0 = $('.blog-post-view .post-image');
        var post_img1 = $('.info-border .post-image');
        var post_img2 = $('.paint-content .post-image');
        var post_home_blog = $('.featured .post-image');
        imgToBg(post_img);
        imgToBg(post_img0);
        imgToBg(post_img1);
        imgToBg(post_img2);
        imgToBg(afford_img);
        imgToBg(post_home_blog);
        /* img to bg */
        function imgToBg(obj) {
            if (obj.length) {
                obj.each(function() {
                    var src = $(this).find('img').attr('src');
                    $(this).css('background-image', 'url("' + src + '")');
                });
            }
        }

        /* custom check-box */
        var urlVal = getUrlVars();
        var changePass = urlVal[0];
        if (changePass.indexOf('changepass') !== -1) {
            if ($('form').hasClass('form-edit-account') == true) {
                $('#change-password').wrap("<span class='check-box checked' />");
                /*$('#change-email').wrap("<span class='check-box' />");*/
                $("body #change-password.check-box").click(function() {
                    $(this).toggleClass('checked');
                });
            }
            if ($('#menu_login_dropdown').hasClass('myaccount-menu-link') == true) {
                $("#menu_login_dropdown input[type='checkbox']").each(function() {
                    $(this).wrap("<span class='check-box' />");
                });
                $("body .check-box").click(function() {
                    $(this).toggleClass('checked');
                });

            }

        } else {

            $("input[type='checkbox']").each(function() {
                $(this).wrap("<span class='check-box' />");
            });
            $("body .check-box").click(function() {
                $(this).toggleClass('checked');
            });
        }

        function getUrlVars() {
            var vars = [],
                hash;
            var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split('=');
                vars.push(hash[0]);
                vars[hash[0]] = hash[1];
            }
            return vars;
        }

        /*product Detail js*/
        if ($(".product_detail").length > 0) {
            $('.free-pickup-content').hide();
            $('.free-pickup .text-left').click(function() {
                $(".free-pickup-content").slideToggle("slow");
                $(this).toggleClass('active');
                return false;
            });

            $('.policyreturns').hide();
            $('.freepolicy .returns').click(function() {
                $(".policyreturns").slideToggle("slow");
                $(this).toggleClass('active');
                return false;
            });
        }
        /*end*/
        /*For community support slider */
        if ($('.abtus, .post-post_content').length == 0 ){
        $('.category-nonprofit-partnership .post-image').slick({
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1
        });
    }
        $('.logo-slider').slick({
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 5,
            responsive: [{
                breakpoint: 480,
                settings: {
                    dots: true,
                    centerMode: true,
                    infinite: true,
                    centerPadding: '40px',
                    slidesToScroll: 1,
                    slidesToShow: 1
                }
            }]
        });
        
        /*End*/
        /*Dropdown Menu Start*/
        $('body').click(function(e) {
            var container = $(".myaccount-menu-link, span.checked");

            if (!container.is(e.target) && container.has(e.target).length === 0) {
                $('.myaccount-menu-link span').removeClass('checked');
            }
        });
        /*End*/

        /*Search Page Filter Empty Remove*/
        if ($('.sidebar').length > 0) {
            if ($('#layered-filter-block').parents().hasClass('sidebar')) {} else {
                if ($('.page-with-filter').length > 0 || $('.catalogsearch-result-index').length > 0 || $('.catalog-category-view').length > 0) {
                    if ($('.sidebar').length > 0) {
                        $('.page-wrapper').addClass('emptysearch');
                    }
                    $('.sidebar').hide();
                }
            }
        }
        /*End*/
    });
});

/*Model Popup*/

require(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function($, modal) {
        $(document).ready(function($) {
            var options = {
                type: 'popup',
                responsive: true,
                innerScroll: false,
                buttons: false,
                focus: 'input',
                modalClass: 'search-model-container'
            };
            var search_content = modal(options, $('#search_popup_model'));


            if ($("#search_popup_model").length > 0) {
                $('#search_popup_button').click(function() {
                    $('#search_popup_model').modal('openModal');
                });
            }

            if ($("#search_popup_model").length > 0) {
                $('#search_popup_button_no_results').click(function() {
                    $('#search_popup_model').modal('openModal');
                });

            }

            if ($('#only-one-store').length > 0) {
                var onlyOneStore = $('#only-one-store').val();
                $('#place-id-value').val(onlyOneStore);
            }

            if ($('.search-model-container').length > 0) {
                $('.search-model-container .action-close').click(function() {
                    if ($('.catalogsearch-result-index').length > 0) {} else {
                        $('#search_mini_form #search').val('');
                    }
                });
            }
        });


         
              function searchForm(){
                var searchFlag = false;
                var winWidth = window.innerWidth;
           if (winWidth < 768 && searchFlag === false)
                {       
                            if(jQuery('.search-header-popup #search_popup_model').length != 1){
                                jQuery('.search-model-container #search_popup_model').appendTo('#search-header-popup');
                                
                            }
                            searchFlag = true;
                }else if (winWidth >= 768)
                {
                            if(jQuery('.search-model-container #search_popup_model').length != 1){
                            jQuery('#search_popup_model').appendTo('.search-model-container .modal-content');
                            }
                            searchFlag = false;
                            
                    }
                }

                 jQuery(window).on('load resize', function() {
               searchForm();
            });

            
    }
);

/*Button Effect*/
require(
    [
        'jquery',
        'jquery/ui'
    ],
    function($) {
        if ($('.link-btn').length > 0) {
            $(".link-btn").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('button.action').length > 0) {
            $("button.action").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('a.action.primary').length > 0) {
            $("a.action.primary").click(function(e) {
                button_effect(e, this);
            });
        }

        if ($('a.continue').length > 0) {
            $("a.continue").click(function(e) {
                button_effect(e, this);
            });
        }

        if ($('button.staticbtn').length > 0) {
            $("button.staticbtn").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('a.tocart').length > 0) {
            $("a.tocart").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('a.submit').length > 0) {
            $("a.submit").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('button.continue').length > 0) {
            $("button.continue").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('button.action-secondary').length > 0) {
            $("button.action-secondary").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('a.create').length > 0) {
            $("a.create").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('button.btn-success').length > 0) {
            $("button.btn-success").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('#print').length > 0) {
            $("#print").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('#print').length > 0) {
            $("#print").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('.action-show-popup').length > 0) {
            $(".action-show-popup").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('#wk_rma_new_request a').length > 0) {
            $("#wk_rma_new_request a").click(function(e) {
                button_effect(e, this);
            });
        }
        if ($('a.checkout').length > 0) {
            $("a.checkout").click(function(e) {
                button_effect(e, this);
            });
        }

        function button_effect(e, element) {
            var rippler = $(element);

            /* create .ink element if it doesn't exist */
            if (rippler.find(".ink").length == 0) {
                rippler.append("<span class='ink'></span>");
            }

            var ink = rippler.find(".ink");

            /* prevent quick double clicks */
            ink.removeClass("animate");

            /* set .ink diametr */
            if (!ink.height() && !ink.width()) {
                var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
                ink.css({ height: d, width: d });
            }

            /* get click coordinates */
            var x = e.pageX - rippler.offset().left - ink.width() / 2;
            var y = e.pageY - rippler.offset().top - ink.height() / 2;

            /* set .ink position and add class .animate */
            ink.css({
                top: y + 'px',
                left: x + 'px'
            }).addClass("animate");
        }
    });

/*static page sticky effect*/
require(
    [
        'jquery',
        'jquery/ui'
    ],
    function($) {
        function static_sticky() {
                var win_w = $(window).width();
                var is_tab = (win_w < 1025) ? true : false;
            if (!is_tab) {                
                var media = jQuery('.post-image');
                product_w = jQuery('.abtus').width();
                media.width(product_w);
                jQuery(window).scroll(function() {
                    var fixSidebar = jQuery('.page-header').innerHeight();
                    var contentHeight = jQuery('.tradetxt, .abtustxt').innerHeight();
                    var sidebarHeight = jQuery('.post-image').height();

                    var sidebarBottomPos = contentHeight - sidebarHeight;
                    var trigger = jQuery(window).scrollTop() - fixSidebar;

                    if (jQuery(window).scrollTop() >= fixSidebar) {
                        jQuery('.post-image').addClass('fixed');
                        jQuery('.abtus').addClass('scrolled');
                    } else {
                        jQuery('.post-image').removeClass('fixed');
                        jQuery('.abtus').removeClass('scrolled');
                    }

                    if (trigger >= sidebarBottomPos) {
                        jQuery('.post-image').addClass('bottom');
                        jQuery('.post-image').removeClass('fixed');
                    } else {
                        jQuery('.post-image').removeClass('bottom');
                    }
                });                
            }
        }
        static_sticky();
        $(window).resize(function() {
            console.log('1');
                static_sticky();
        });

        /*check customize*/
        if (!($('.customize_button').length > 0)) {
            $('.product-social-links').addClass('no-customize');
        } else {

        }

        if ($('#desktopmenu').length > 0) {
            var menuTop = $('#desktopmenu').offset().top;
            $(document).scroll(function() {
                var windowTop = $(this).scrollTop();
                if (windowTop > menuTop) {
                    $('#desktopmenu').addClass('sticky_header');
                    $('.toplinkes-left').addClass('sticky_header_left');
                    $('.toplinks-right').addClass('sticky_header_right');
                } else {
                    $('#desktopmenu').removeClass('sticky_header');
                    $('.toplinkes-left').removeClass('sticky_header_left');
                    $('.toplinks-right').removeClass('sticky_header_right');
                }
            });
        }
    });

/*menu slide*/
require(
    [
        'jquery',
        'jquery/ui'
    ],
    function($) {
        $("#desktopmenu li.level0:not(.nav-1) .level1 a").each(function() {
            if ($(this).hasClass('image_anchor')) {
                $(this).parent().addClass('col_6');
            }
        });

        $(document).ready(function() {
            $('#desktopmenu li.level0.nav-1 ul.level0 li.level1.nav-1-6').css('padding-bottom', '10px');
            $('#desktopmenu li.level0 ul.level0').mouseover(function() {
                $(this).prev().addClass('arrowup');
            });
            $('#desktopmenu li.level0 ul.level0').mouseout(function() {
                $(this).prev().removeClass('arrowup');
            });
            $(window).resize(function() {
                $('#desktopmenu li.level0.nav-1 ul.level0 li.level1').sort(function(a, b) {
                    return $(a).outerHeight() < $(b).outerHeight() ? 1 : -1;
                }).appendTo('#desktopmenu li.level0.nav-1 ul.level0');
            });
        });

        $('#desktopmenu li.level1').mouseover(function() {
            $('#desktopmenu li.level1').not(this).addClass('blurthis');
        });
        $('#desktopmenu li.level1').mouseout(function() {
            $('#desktopmenu li.level1').removeClass('blurthis');
        });
        $('#desktopmenu li.level0.parent').mouseover(function() {
            $('#maincontent').addClass('menubgfade');
        });
        $('#desktopmenu li.level0.parent').mouseout(function() {
            $('#maincontent').removeClass('menubgfade');
        });
    });

/*about & static page content read more*/
require(
    [
        'jquery',
        'jquery/ui'
    ],
     function($) {
        jQuery(document).ready(function() {            
            $('.category-cms .explorecontent').children('p').not(':first-child').wrapAll('<div class="wrapitexplore" />');
            if ($(window).width() < 768){
                if ($('.wrapitexplore').length > 0) {
                  $('<button class="explore_more seemore">show more</button>').appendTo('.explorecontent .readmorebtn');
                  $('.explore_more').click(function() {
                      var $this = $(this);
                      $this.toggleClass('seemore');
                      if ($this.hasClass('seemore')) {
                          $this.text('Show more');
                      } else {
                          $this.text('Show less');
                      }
                      $('.explorecontent .wrapitexplore').slideToggle(1000);
                  });
                } else {
                    $('.explore_more').css('display', 'none');
                }  
            }

            if ($(window).width() < 768) {
                if ($('.readmorebtn-sec p').length == 0) {
                    $('<button class="explore_more1 seemore1">show more</button>').appendTo('.explorecontent1 .readmorebtn');
                    $('.explore_more1').click(function() {
                        var $this = $(this);                    
                        $this.toggleClass('seemore1');
                        if ($this.hasClass('seemore1')) {
                            $this.text('Show more');
                        } else {
                            $this.text('Show less');
                        }
                        $('.explorecontent1 .readmore-sec').slideToggle(1000);
                    });
                }else {
                        $('.explore_more1').css('display', 'none');
                    }
            } 

            $('.founder-disc .explorecontent2').children('p').not(':first-child').wrapAll('<div class="wrapitexplore2" />');
            if ($(window).width() < 768){
                if ($('.wrapitexplore2').length > 0) {
                  $('<button class="explore_more2 seemore2">show more</button>').appendTo('.explorecontent2 .readmorebtn');
                  $('.explore_more2').click(function() {
                      var $this = $(this);
                      $this.toggleClass('seemore2');
                      if ($this.hasClass('seemore2')) {
                          $this.text('Show more');
                      } else {
                          $this.text('Show less');
                      }
                      $('.explorecontent2 .wrapitexplore2').slideToggle(1000);
                  });
                } else {
                    $('.explore_more2').css('display', 'none');
                }  
            }            
        });
    });
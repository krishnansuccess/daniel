# Also Viewed Products

Also Viewed Products - is the products recommendation module. Products
suggestions are based on automatically collected anonymous browsing history of
other customers.

### Installation

```bash
cd magento2/root/folder
composer require vovayatsyuk/magento2-alsoviewed
php bin/magento module:enable Vovayatsyuk_Alsoviewed
php bin/magento setup:upgrade
```

### Docs and Guides

See docs, guides and screenshots at the [wiki pages][wiki]

### License

This software is licensed under the [OSL-3.0 License][license]

[wiki]: https://github.com/vovayatsyuk/magento2-alsoviewed/wiki
[license]: https://opensource.org/licenses/osl-3.0.php

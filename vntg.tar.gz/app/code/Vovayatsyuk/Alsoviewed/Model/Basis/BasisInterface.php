<?php

namespace Vovayatsyuk\Alsoviewed\Model\Basis;

interface BasisInterface
{
    public function getIds();
}

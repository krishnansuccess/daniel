<?php

namespace Vovayatsyuk\Alsoviewed\Model\Relation\Locator;

interface LocatorInterface
{
    /**
     * @return \Vovayatsyuk\Alsoviewed\Model\Relation
     */
    public function getRelation();
}

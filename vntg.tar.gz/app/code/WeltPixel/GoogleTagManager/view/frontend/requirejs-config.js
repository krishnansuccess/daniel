var config = {
    map: {
        '*': {
            weltpixel_gtm: 'WeltPixel_GoogleTagManager/js/weltpixel_gtm'
        }
    }
};
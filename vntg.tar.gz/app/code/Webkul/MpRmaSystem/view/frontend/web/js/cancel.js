/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
define([
    "jquery",
    "jquery/ui",
], function ($) {
    'use strict';
    $.widget('mprma.cancel', {
        options: {},
        _create: function () {
            var self = this;
            $(document).ready(function () {
                $(".wk-cancel-rma").click(function (e) {
                    var result = confirm("Do you want to cancel RMA.");
                    if (result == false) {
                        return false;
                    }
                });
            });
        }
    });
    return $.mprma.cancel;
});

/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
define([
    "jquery",
    "jquery/ui",
], function ($) {
    'use strict';
    $.widget('mprma.rma', {
        options: {},
        _create: function () {
            var self = this;
            $(document).ready(function () {
                var totalPrice = self.options.totalPrice;
                $("#payment_type").change(function (e) {
                    var val = $(this).val();
                    if (val == 1) {
                        $(".wk-partial-amount").hide();
                        $("#partial_amount").removeClass("required-entry");
                    } else {
                        $(".wk-partial-amount").show();
                        $("#partial_amount").addClass("required-entry");
                    }
                });
                $(".wk-refund").click(function (e) {
                    if ($('#wk_rma_refund_form').valid()) {
                        var price = $("#partial_amount").val();
                        if (price > totalPrice) {
                            alert("Partial amount can not be more then "+totalPrice);
                            return false;
                        }
                    }
                });
            });
        }
    });
    return $.mprma.rma;
});

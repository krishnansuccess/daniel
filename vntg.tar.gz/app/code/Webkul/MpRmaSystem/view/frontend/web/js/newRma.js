/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
define([
    "jquery",
    "jquery/ui",
], function ($) {
    'use strict';
    $.widget('mprma.newRma', {
        options: {},
        _create: function () {
            var self = this;
            $(document).ready(function () {
                var count = 0;
                var skip = [];
                var flag = 1;
                $("#orders").val("");
                $("#orders").on('change', function () {
                    var orderId = $(this).val();
                    if (orderId == "") {
                        resetArea();
                    } else {
                        showLoadingMask();
                        $.ajax({
                            type: 'post',
                            url: self.options.orderUrl,
                            async: true,
                            dataType: 'json',
                            data : { order_id : orderId, is_guest : self.options.isGuest },
                            success:function (data) {
                                if (data.isLoggedIn == 1) {
                                    var orderStatus = data.order_status;
                                    var items = data.items;
                                    $("#order_items").empty();
                                    $.each(items, function (key, obj) {
                                        var html = getHtml(obj);
                                        $("#order_items").append(html);
                                    });
                                    setResolutionType(orderStatus);
                                    setProductStatus(orderStatus);
                                } else {
                                    location.reload();
                                }
                                hideLoadingMask();
                            }
                        });
                    }
                });
                $('body').on('change', '.order_qty', function () {
                    var orderQty = $(this);
                    var qty = $(this).val();
                    var orderId = $("#orders").val();
                    var itemId = $(this).parent().parent().find(".order_item").val();
                    if (qty != "") {
                        showLoadingMask();
                        $.ajax({
                            type: 'post',
                            url: self.options.checkUrl,
                            async: true,
                            dataType: 'json',
                            data : { order_id : orderId, item_id : itemId, qty : qty, is_guest : self.options.isGuest },
                            success:function (data) {
                                if (data.isLoggedIn == 1) {
                                    if (data.error == 1) {
                                        alert("Quantity not allowed for RMA.");
                                        orderQty.val("");
                                    }
                                } else {
                                    location.reload();
                                }
                                hideLoadingMask();
                            }
                        });
                    }
                });
                $(".wk-save").on('click', function () {
                    if ($('#wk_new_rma_form').valid()) {
                        var val = $(".order_item:checked").val();
                        if (val > 0) {
                            var qty = $(".order_item:checked").parent().parent().find(".order_qty").val();
                            var productId = $(".order_item:checked").attr("data-id");
                            if (qty == "") {
                                alert("Please select quantity.");
                                return false;
                            } else {
                                $("#qty").val(qty);
                                $("#product").val(productId);
                            }
                        } else {
                            alert("Please select item.");
                            return false;
                        }
                    }
                });
                $("#image").change(function () {
                    count = 0;
                    skip = [];
                    setSkippedImg(skip);
                    if (typeof (FileReader) != "undefined") {
                        var preview = $("#preview");
                        preview.html("");
                        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png)$/;
                        $($(this)[0].files).each(function () {
                            var file = $(this);
                            var fileName = file[0].name;
                            if (regex.test(fileName.toLowerCase())) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var removeImg = $("<div />", { class : 'wk-remove-img', text: 'X', 'data-id': count});
                                    count++;
                                    var box = $("<div />", { class : 'wk-preview-image' });
                                    var img = $("<img />");
                                    img.attr("src", e.target.result);
                                    box.append(removeImg);
                                    box.append(img);
                                    preview.append(box);
                                    $("#isChecked").val(count);
                                    setSelectedImages(count);
                                }
                                reader.readAsDataURL(file[0]);
                            } else {
                                alert("Image type not allowed.");
                                preview.html("");
                                $("#image").val("");
                                $("#isChecked").val(0);
                                return false;
                            }
                        });
                    } else {
                        alert("There is some error in preview image.");
                    }
                });
                $('body').on('click', '.wk-remove-img', function () {
                    var dataId = $(this).attr("data-id");
                    count--;
                    $(this).parent().remove();
                    setSelectedImages(count);
                    skip.push(dataId);
                    setSkippedImg(skip);
                });
                $('body').on('change', '#order_status', function () {
                    var type = $(this).val();
                    if (type == 1) {
                        addConsignmentBlock();
                    } else {
                        removeConsignmentBlock();
                    }
                });
                function setSelectedImages(count)
                {
                    var txt = "";
                    if (count == 0) {
                        txt = "";
                    } else if (count == 1) {
                        txt = count+" image selected";
                    } else {
                        txt = count+" images selected";
                    }
                    $(".wk-selected-img-info").html(txt);
                }
                function setSkippedImg(skip)
                {
                    var skipIndexes = skip.join(",");;
                    $("#skipChecked").val(skipIndexes);
                }
            });
            
            function resetArea()
            {
                var html = '<td colspan="5">No Order Selected</td>';
                $("#order_items").empty();
                $("#order_items").append(html);
            }

            function setResolutionType(type)
            {
                var html = "";
                if (type == 1) {
                    html += '<option value="1">Refund</option>';
                    html += '<option value="2">Replace</option>';
                } else {
                    html += '<option value="3">Cancel Items</option>';
                }
                $("#resolution_type").empty();
                $("#resolution_type").append(html);
            }

            function setProductStatus(type)
            {
                var html = "";
                if (type == 1) {
                    html += '<option value="0">Not Delivered</option>';
                    html += '<option value="1">Delivered</option>';
                } else {
                    html += '<option value="0">Not Delivered</option>';
                }
                $("#order_status").empty();
                $("#order_status").append(html);
            }

            function getHtml(obj)
            {
                var qty =  obj.qty;
                if (qty > 0) {
                    var html = $('<tr/>');
                    html.append($('<td/>', { class : 'col', text : obj.name }));
                    html.append($('<td/>', { class : 'col', text : obj.sku }));
                    html.append($('<td/>', { class : 'col' }).append(getDropDownList(obj.qty)));
                    html.append($('<td/>', { class : 'col', text : obj.price }));
                    html.append($('<td/>', { class : 'col' })
                        .append($('<input/>', { type : 'radio', name : 'item_id', class : 'order_item', value : obj.item_id, 'data-id' : obj.id })));
                    return html;
                } else {
                    return "";
                }
                
            }

            function getDropDownList(qty)
            {
                var combo = $("<select class='order_qty'></select>");
                combo.append("<option value=''>Select Quantity</option>");
                var count = 1;
                while (count <= qty) {
                    combo.append("<option value='"+count+"'>" + count + "</option>");
                    count++;
                };
                return combo;
            }

            function hideLoadingMask()
            {
                $(".wk-loading-mask").addClass("wk-display-none");
            }

            function showLoadingMask()
            {
                $(".wk-loading-mask").removeClass("wk-display-none");
            }

            function addConsignmentBlock()
            {
                var input = $('<input/>', { class : 'input-text required-entry', id : 'consignment_number', type : 'text', 'data-validate' :'{required:true}', name:'number' });
                var html = $('<div/>', { class : 'field required' });
                html.append(
                    $('<label class="label" for="consignment_number"></label>')
                    .append($('<span/>', { text : 'Enter Consignment Number' }))
                );
                html.append($('<div/>', { class : 'control' }).append(input));
                $("#consignment_number").remove();
                $("#order_status").parent().parent().after(html);
            }

            function removeConsignmentBlock()
            {
                $("#consignment_number").parent().parent().remove();
            }
        }
    });
    return $.mprma.newRma;
});

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpRmaSystem\Block\Seller;

use Webkul\MpRmaSystem\Model\ResourceModel\Details\CollectionFactory;

class Allrma extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_resource;

    /**
     * @var \Magento\Eav\Model\ResourceModel\Entity\Attribute
     */
    protected $_eav;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var CollectionFactory
     */
    protected $_detailsCollection;

    /**
     * @var Webkul\MpRmaSystem\Model\ResourceModel\Details\Collection
     */
    protected $_allrma;

    /**
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute $eav
     * @param \Magento\Customer\Model\Session $customerSession
     * @param CollectionFactory $detailsCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute $eav,
        \Magento\Customer\Model\Session $customerSession,
        CollectionFactory $detailsCollection,
        array $data = []
    ) {
        $this->_resource = $resource;
        $this->_eav = $eav;
        $this->_customerSession = $customerSession;
        $this->_detailsCollection = $detailsCollection;
        parent::__construct($context, $data);
    }

    /**
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('All RMA'));
    }

    /**
     * @return bool | collection object
     */
    public function getAllRma()
    {
        $customerTable = $this->_resource
                            ->getTableName('customer_grid_flat');
        $productTable = $this->_resource
                            ->getTableName('catalog_product_entity_varchar');
        $proAttrId = $this->_eav->getIdByCode('catalog_product', 'name');
        if (!($sellerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        if (!$this->_allrma) {
            $collection = $this->_detailsCollection
                                ->create()
                                ->addFieldToFilter('seller_id', $sellerId)
                                ->setOrder('id', 'desc');

            $collection->getSelect()
                        ->joinLeft(
                            ['cfg'=> $customerTable],
                            'main_table.customer_id = cfg.entity_id',
                            ['customer_name' => 'name']
                        );
            $collection->addFilterToMap('customer_name', 'cgf.customer_name');
            $sql = 'cpev.store_id = 0 AND cpev.attribute_id = '.$proAttrId;
            $collection->getSelect()
                        ->join(
                            $productTable.' as cpev',
                            'main_table.product_id = cpev.entity_id',
                            ['product_name' => 'value']
                        )
                        ->where($sql);
            $collection->addFilterToMap('product_name', 'cpev.value');

            $this->_allrma = $collection;
        }

        return $this->_allrma;
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getAllRma()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'mprmasystem.allrma.list.pager'
            )->setCollection(
                $this->getAllRma()
            );
            $this->setChild('pager', $pager);
            $this->getAllRma()->load();
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpRmaSystem\Controller\Order;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\RequestInterface;

class Items extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Webkul\MpRmaSystem\Helper\Data
     */
    protected $_mpRmaHelper;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_order;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @param Context $context
     * @param \Webkul\MpRmaSystem\Helper\Data $mpRmaHelper
     * @param \Magento\Sales\Model\OrderFactory $order
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context,
        \Webkul\MpRmaSystem\Helper\Data $mpRmaHelper,
        \Magento\Sales\Model\OrderFactory $order,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        $this->_mpRmaHelper = $mpRmaHelper;
        $this->_order = $order;
        $this->_resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $error = false;
        $helper = $this->_mpRmaHelper;
        $data = $this->_request->getParams();
        if (array_key_exists("is_guest", $data)) {
            $isGuest = $data['is_guest'];
            if ($isGuest == 1) {
                if (!$helper->isGuestLoggedIn()) {
                    $error= true;
                }
            } else {
                if (!$helper->isLoggedIn()) {
                    $error= true;
                }
            }
            if (!$error) {
                $orderId = $this->_request->getParam('order_id');
                $order = $this->_order->create()->load($orderId);
                $orderedItems = $order->getAllVisibleItems();
                $orderStatus = $order->getStatus();
                $type = 1;
                if ($orderStatus == "pending") {
                    $type = 0;
                }
                $info = ['isLoggedIn' => 1, 'order_status' => $type];
                foreach ($orderedItems as $item) {
                    $itemId = $item->getId();
                    $productId = $item->getProductId();
                    $qty = $item->getQtyOrdered();
                    $qty = $helper->getRmaQty($itemId, $orderId, $qty, $type);
                    $sku = $item->getSku();
                    $price = $item->getPrice();
                    $name = $item->getName();
                    $arr = [
                            'price' => $price,
                            'sku' => $sku,
                            'name' => $name,
                            'qty' => $qty,
                            'id' => $productId,
                            'item_id' => $itemId
                        ];
                    $info['items'][] = $arr;
                }
            } else {
                $info = ['isLoggedIn' => 0];
            }
        } else {
            $info = ['isLoggedIn' => 0];
        }
        $result = $this->_resultJsonFactory->create();
        $result->setData($info);
        return $result;
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpRmaSystem\Controller\Customer;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Webkul\MpRmaSystem\Helper\Data as Helper;

class Create extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $_url;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_session;

    /**
     * @var \Webkul\MpRmaSystem\Helper\Data
     */
    protected $_mpRmaHelper;

    /**
     * @var \Webkul\MpRmaSystem\Model\DetailsFactory
     */
    protected $_details;

    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $_customer;

    /**
     * @var \Magento\Sales\Model\Order\Item
     */
    protected $_orderItem;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_fileSystem;

    /**
     * @param Context $context
     * @param \Magento\Customer\Model\Url $url
     * @param \Magento\Customer\Model\Session $session
     * @param \Webkul\MpRmaSystem\Helper\Data $mpRmaHelper
     * @param \Webkul\MpRmaSystem\Model\DetailsFactory $details
     * @param \Magento\Customer\Model\Customer $customer
     * @param \Magento\Sales\Model\Order\Item $orderItem
     * @param \Magento\Framework\Filesystem $fileSystem
     */
    public function __construct(
        Context $context,
        \Magento\Customer\Model\Url $url,
        \Magento\Customer\Model\Session $session,
        \Webkul\MpRmaSystem\Helper\Data $mpRmaHelper,
        \Webkul\MpRmaSystem\Model\DetailsFactory $details,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Sales\Model\Order\Item $orderItem,
        \Magento\Framework\Filesystem $fileSystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
    ) {
        $this->_url = $url;
        $this->_session = $session;
        $this->_mpRmaHelper = $mpRmaHelper;
        $this->_details = $details;
        $this->_customer = $customer;
        $this->_orderItem = $orderItem;
        $this->_fileSystem = $fileSystem;
        $this->_fileUploader = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Check customer authentication.
     *
     * @param RequestInterface $request
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function dispatch(RequestInterface $request)
    {
        $loginUrl = $this->_url->getLoginUrl();
        if (!$this->_session->authenticate($loginUrl)) {
            $this->_actionFlag->set('', self::FLAG_NO_DISPATCH, true);
        }
        return parent::dispatch($request);
    }

    /**
     * Create New Customer Rma
     */
    public function execute()
    {
        $helper = $this->_mpRmaHelper;
        if (!$this->getRequest()->isPost()) {
            $this->messageManager->addError(__('Something went wrong.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/allrma');
        }
        $error = false;
        $msg = '';
        $allowedExtensions = ['png', 'jpg', 'jpeg', 'gif'];
        $rmaData = $this->getRequest()->getParams();
        if (count($rmaData) > 0) {
            $orderId = $rmaData['order_id'];
            $itemId = $rmaData['item_id'];
            $qty = $rmaData['qty'];
            $time = date('Y-m-d H:i:s');
            
            if (!$this->_mpRmaHelper->isRmaAllowed($itemId, $orderId, $qty)) {
                $this->messageManager->addError(__('Quantity not allowed for RMA.'));
                return $this->resultRedirectFactory->create()->setPath('*/*/newrma');
            }
            $sellerId = $this->_mpRmaHelper->getSellerIdByProductId($rmaData['product_id']);
            $customerId = $this->_mpRmaHelper->getCustomerId();
            $customer = $this->_customer->load($customerId);
            $email = $customer->getEmail();
            $customerName = $customer->getName();
            $order = $this->_mpRmaHelper->getOrder($orderId);
            $rmaData['seller_id'] = $sellerId;
            $rmaData['customer_id'] = $customerId;
            $rmaData['customer_email'] = $email;
            $rmaData['seller_status'] = 0;
            $rmaData['status'] = 0;
            $rmaData['updated_date'] = $time;
            $rmaData['created_date'] = $time;
            $rmaData['order_ref'] = '#'.$order->getIncrementId();
            $orderItem = $this->_orderItem->load($itemId);
            $price = $orderItem->getPrice();
            $rmaData['price'] = $price;
            $numberOfImages = (int) $rmaData['is_checked'];
            if (!$helper->isAllowedImageUpload($numberOfImages)) {
                $msg = __('Error in image uploading.');
                $this->messageManager->addError(__($msg));
                return $this->resultRedirectFactory->create()->setPath('*/*/newrma');
            }
            $model = $this->_details->create();
            $model->setData($rmaData)->save();
            $helper->uploadImages($numberOfImages, $model->getId());
            //Start: Send Email After RMA Creation
            $rmaInfo = $rmaData;
            $rmaInfo['rma_id'] = $model->getId();
            $details = [
                        'template' => Helper::NEW_RMA,
                        'type' => 0,
                        'name' => $customerName,
                        'rma' => $rmaInfo
                    ];
            $helper->sendNewRmaEmail($details);
            //End: Send Email After RMA Creation
            $this->messageManager->addSuccess(__('New RMA request generated.'));
        } else {
            $this->messageManager->addError(__('Something went wrong.'));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/allrma');
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpRmaSystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpRmaSystem\Helper;

use Magento\Sales\Model\OrderFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Sales\Model\ResourceModel\Order\Invoice\Item\CollectionFactory as ItemCollection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollection;
use Webkul\Marketplace\Model\ResourceModel\Seller\CollectionFactory as SellerCollection;
use Webkul\Marketplace\Model\ResourceModel\Product\CollectionFactory as ProductCollection;
use Webkul\Marketplace\Model\ResourceModel\Orders\CollectionFactory as OrdersCollection;
use Webkul\MpRmaSystem\Model\ResourceModel\Details\CollectionFactory as DetailsCollection;
use Webkul\MpRmaSystem\Model\ResourceModel\Reasons\CollectionFactory as ReasonsCollection;
use Webkul\MpRmaSystem\Model\ResourceModel\Conversation\CollectionFactory as ConversationCollection;

use Magento\Framework\Locale\CurrencyInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const ADMIN = 'Admin';
    const NEW_RMA = 'new_rma';
    const UPDATE_RMA = 'update_rma';
    const RMA_MESSAGE = 'rma_message';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Framework\Session\SessionManager
     */
    protected $_session;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_fileSystem;

    /**
     * @var SellerCollection
     */
    protected $_sellerCollection;

    /**
     * @var ProductCollection
     */
    protected $_productCollection;

    /**
     * @var OrdersCollection
     */
    protected $_ordersCollection;

    /**
     * @var OrderCollection
     */
    protected $_orderCollectionFactory;

    /**
     * @var DetailsCollection
     */
    protected $_detailsCollection;

    /**
     * @var ReasonsCollection
     */
    protected $_reasonsCollection;

    /**
     * @var ConversationCollection
     */
    protected $_conversationCollection;

    /**
     * @var \Webkul\MpRmaSystem\Model\DetailsFactory
     */
    protected $_rma;

    /**
     * @var \Webkul\MpRmaSystem\Model\ReasonsFactory
     */
    protected $_reason;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;

    /**
     * @var OrderFactory
     */
    protected $_order;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $_inlineTranslation;

    /**
     * @var \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader
     */
    protected $_memoLoader;

    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender
     */
    protected $_memoSender;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_resource;

    /**
     * @var \Magento\Framework\Locale\CurrencyInterface
     */
    protected $_currency;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var \Magento\Sales\Api\CreditmemoManagementInterface
     */
    protected $_creditmemoManagement;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Session\SessionManager $session
     * @param \Magento\Framework\Filesystem $fileSystem
     * @param SellerCollection $sellerCollection
     * @param ProductCollection $productCollection
     * @param OrdersCollection $ordersCollection
     * @param OrderCollection $orderCollectionFactory
     * @param DetailsCollection $detailsCollectionFactory
     * @param ReasonsCollection $reasonsCollectionFactory
     * @param ConversationCollection $conversationCollectionFactory
     * @param \Webkul\MpRmaSystem\Model\DetailsFactory $rma
     * @param \Webkul\MpRmaSystem\Model\ReasonsFactory $reason
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param OrderFactory $orderFactory
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader $creditmemoLoader
     * @param \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender $creditmemoSender
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Framework\Locale\CurrencyInterface $currency
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Sales\Api\CreditmemoManagementInterface $creditmemoManagement
     * @param \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\Session\SessionManager $session,
        \Magento\Framework\Filesystem $fileSystem,
        SellerCollection $sellerCollection,
        ProductCollection $productCollection,
        ItemCollection $itemCollection,
        OrdersCollection $ordersCollection,
        OrderCollection $orderCollectionFactory,
        DetailsCollection $detailsCollectionFactory,
        ReasonsCollection $reasonsCollectionFactory,
        ConversationCollection $conversationCollectionFactory,
        \Webkul\MpRmaSystem\Model\DetailsFactory $rma,
        \Webkul\MpRmaSystem\Model\ReasonsFactory $reason,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        OrderFactory $orderFactory,
        \Webkul\MpRmaSystem\Model\ResourceModel\Details $detailsResource,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader $creditmemoLoader,
        \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender $creditmemoSender,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\Locale\CurrencyInterface $currency,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Sales\Api\CreditmemoManagementInterface $creditmemoManagement,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
    ) {
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_request = $context->getRequest();
        $this->_storeManager = $storeManager;
        $this->_customerSession = $customerSession;
        $this->_session = $session;
        $this->_fileSystem = $fileSystem;
        $this->_sellerCollection = $sellerCollection;
        $this->_productCollection = $productCollection;
        $this->_itemCollection = $itemCollection;
        $this->_ordersCollection = $ordersCollection;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_detailsCollection = $detailsCollectionFactory;
        $this->_reasonsCollection = $reasonsCollectionFactory;
        $this->_conversationCollection = $conversationCollectionFactory;
        $this->_rma = $rma;
        $this->_reason = $reason;
        $this->_product = $productFactory;
        $this->_orderFactory = $orderFactory;
        $this->_detailsResource = $detailsResource;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_memoLoader = $creditmemoLoader;
        $this->_memoSender = $creditmemoSender;
        $this->_resource = $resource;
        $this->_currency = $currency;
        $this->_customerFactory = $customerFactory;
        $this->_creditmemoManagement = $creditmemoManagement;
        $this->_fileUploader = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Get Default Days to Request RMA
     *
     * @return int
     */
    public function getDefaultDays()
    {
        $days = (int) $this->_scopeConfig->getValue('mprmasystem/settings/default_days');
        if ($days <= 0) {
            $days = 30;
        }
        return $days;
    }

    /**
     * Check Whether Notification to Admin is Allowed or Not
     *
     * @return bool
     */
    public function isAllowedNotification()
    {
        return $this->_scopeConfig->getValue('mprmasystem/settings/admin_notification');
    }

    /**
     * Get Admin Email Id
     *
     * @return string
     */
    public function getAdminEmail()
    {
        return $this->_scopeConfig->getValue('mprmasystem/settings/admin_email');
    }

    /**
     * Get Current Customer Id
     *
     * @return int
     */
    public function getCustomerId()
    {
        $customerId = 0;
        if ($this->_customerSession->isLoggedIn()) {
            $customerId = (int) $this->_customerSession->getCustomerId();
        }

        return $customerId;
    }

    /**
     * Check Customer is Logged In or Not
     *
     * @return bool
     */
    public function isLoggedIn()
    {
        if ($this->_customerSession->isLoggedIn()) {
            return true;
        }

        return false;
    }

    /**
     * Get Mediad Path
     *
     * @return string
     */
    public function getMediaPath()
    {
        return $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
    }

    /**
     * Get Current RMA Id
     *
     * @return int
     */
    public function getCurrentRmaId()
    {
        $id = (int) $this->_request->getParam('id');

        return $id;
    }

    /**
     * Get Seller Details
     *
     * @return Object
     */
    public function getSellerDetails($sellerId)
    {
        $collection = $this->_sellerCollection
                            ->create()
                            ->addFieldToFilter('seller_id', ['eq' => $sellerId]);
        foreach ($collection as $seller) {
            return $seller;
        }

        return $seller;
    }

    /**
     * Check Whether Customer Is Seller Or Not
     *
     * @param int $sellerId [optional]
     *
     * @return bool
     */
    public function isSeller($sellerId = '')
    {
        if ($sellerId == '') {
            $sellerId = $this->getCustomerId();
        }
        $seller = $this->getSellerDetails($sellerId);
        $isSeller = $seller->getIsSeller();
        if ($isSeller == 1) {
            return true;
        }

        return false;
    }

    /**
     * Get Customer's Orders
     *
     * @param int $customerId [optional]
     *
     * @return array
     */
    public function getOrdersOfCustomer($customerId = '')
    {
        $days = $this->getDefaultDays();
        $from = date('Y-m-d', strtotime("-".$days." days"));
        $allowedStatus = ['pending', 'processing', 'complete'];
        if ($customerId == '') {
            $customerId = $this->getCustomerId();
        }
        $orders = $this->_orderCollectionFactory->create()
                        ->addFieldToSelect('*')
                        ->addFieldToFilter('customer_id', $customerId)
                        ->addFieldToFilter('status', ['in'=> $allowedStatus])
                        ->addFieldToFilter('created_at', ['from'  => $from])
                        ->setOrder('created_at', 'desc');

        return $orders;
    }

    /**
     * Get Guest's Orders
     *
     * @param int $customerId Optional
     *
     * @return array
     */
    public function getOrdersOfGuest($email = '')
    {
        if (strlen($email) <= 0) {
            $email = $this->getGuestEmailId();
        }
        $days = $this->getDefaultDays();
        $from = date('Y-m-d', strtotime("-".$days." days"));
        $allowedStatus = ['pending', 'processing', 'complete'];
        $orders = $this->_orderCollectionFactory->create()
                        ->addFieldToSelect('*')
                        ->addFieldToFilter('customer_email', $email)
                        ->addFieldToFilter('status', ['in'=> $allowedStatus])
                        ->addFieldToFilter('created_at', ['from'  => $from])
                        ->setOrder('created_at', 'desc');

        return $orders;
    }

    /**
     * Get Currency Symbol By Currency Code
     *
     * @param string $code Optional
     *
     * @return string
     */
    public function getCurrencySymbol($code = 'USD')
    {
        return $this->_currency->getCurrency($code)->getSymbol();
    }

    /**
     * Get Reasons
     *
     * @param int $type Optional
     *
     * @return array
     */
    public function getAllReasons()
    {
        $reasons = [];
        $collection = $this->_reasonsCollection
                            ->create()
                            ->addFieldToFilter('status', 1);
        foreach ($collection as $reason) {
            $reasons[$reason->getId()] = $reason->getReason();
        }

        return $reasons;
    }

    /**
     * Get Seller Id By Order Id
     *
     * @param int $orderId
     *
     * @return int
     */
    public function getSellerIdByOrderId($orderId)
    {
        $sellerId = 0;
        $collection = $this->_ordersCollection
                            ->create()
                            ->addFieldToFilter('order_id', $orderId);
        foreach ($collection as $order) {
            $sellerId = $order->getSellerId();
        }

        return $sellerId;
    }

    /**
     * Get Seller Id By Product Id
     *
     * @param int $productId
     *
     * @return int
     */
    public function getSellerIdByProductId($productId)
    {
        $sellerId = 0;
        $collection = $this->_productCollection
                            ->create()
                            ->addFieldToFilter('mageproduct_id', $productId);
        foreach ($collection as $order) {
            $sellerId = $order->getSellerId();
        }

        return $sellerId;
    }

    /**
     * Get All Rma of Customer
     *
     * @param int $customerId [optional]
     *
     * @return object
     */
    public function getAllRma($customerId = '')
    {
        if ($customerId == '') {
            $customerId = $this->getCustomerId();
        }
        $collection = $this->_detailsCollection
                            ->create()
                            ->addFieldToFilter('customer_id', $customerId);

        return $collection;
    }

    /**
     * Get All Rma of Seller
     *
     * @param int $sellerId
     *
     * @return object
     */
    public function getAllRmaForSeller($sellerId)
    {
        $collection = $this->_detailsCollection
                            ->create()
                            ->addFieldToFilter('seller_id', $sellerId);

        return $collection;
    }

    /**
     * Check For Valid RMA For Admin
     *
     * @return bool
     */
    public function isAdminRma()
    {
        $id = $this->getCurrentRmaId();
        $collection = $this->_detailsCollection
                            ->create()
                            ->addFieldToFilter('seller_id', 0)
                            ->addFieldToFilter('id', $id);
        if ($collection->getSize()) {
            return true;
        }
        return false;
    }

    /**
     * Check For Valid RMA To View
     *
     * @param int $type [optional]
     *
     * @return bool
     */
    public function isValidRma($type = 0)
    {
        $id = $this->getCurrentRmaId();
        $customerId = $this->getCustomerId();
        $email = $this->getGuestEmailId();
        $collection = $this->_detailsCollection
                            ->create()
                            ->addFieldToFilter('id', $id);
        if ($type == 1) { // Checking for Customer's Requested RMA
            $collection->addFieldToFilter('customer_id', $customerId);
        } elseif ($type == 2) { // Checking for Guest's Requested RMA
            $collection->addFieldToFilter('customer_email', $email);
        } else { // Checking for Seller's RMA
            $collection->addFieldToFilter('seller_id', $customerId);
        }
        if ($collection->getSize()) {
            return true;
        }
        return false;
    }

    /**
     * Get RMA Details by Id
     *
     * @param int $rmaId [optional]
     *
     * @return object
     */
    public function getRmaDetails($rmaId = 0)
    {
        if ($rmaId == 0) {
            $rmaId = $this->getCurrentRmaId();
        }
        $rma = $this->_rma->create()->load($rmaId);
        return $rma;
    }

    /**
     * Get Reason by Id
     *
     * @param int $reasonId
     *
     * @return string
     */
    public function getReasonById($reasonId)
    {
        $reason = $this->_reason->create()->load($reasonId);
        if ($reason->getId()) {
            return $reason->getReason();
        }
        return "";
    }

    /**
     * Get Order Details by Id
     *
     * @param int $orderId
     *
     * @return object
     */
    public function getOrder($orderId)
    {
        $order = $this->_orderFactory->create()->load($orderId);
        return $order;
    }

    /**
     * Get Order Item Details by Item Id
     *
     * @param int $orderId
     * @param int $itemId
     *
     * @return object
     */
    public function getOrderItem($orderId, $itemId)
    {
        $order = $this->getOrder($orderId);
        $orderedItems = $order->getAllVisibleItems();
        foreach ($orderedItems as $item) {
            if ($item->getId() == $itemId) {
                return $item;
            }
        }
        return "";
    }

    /**
     * Get Images by Rma Id
     *
     * @param int $rmaId
     *
     * @return array
     */
    public function getImages($rmaId)
    {
        $currentStore = $this->_storeManager->getStore();
        $type = \Magento\Framework\UrlInterface::URL_TYPE_MEDIA;
        $mediaUrl = $currentStore->getBaseUrl($type);
        $imageArray = [];
        $path = $this->getMediaPath()."marketplace/rma/".$rmaId."/*";
        $images = glob($path);
        foreach ($images as $image) {
            $fileName = explode("/", $image);
            $fileName = end($fileName);
            $imageUrl = $mediaUrl.'marketplace/rma/'.$rmaId."/".$fileName;
            $imageArray[] = $imageUrl;
        }
        return $imageArray;
    }

    /**
     * Get Conversation on Rma by RMA Id
     *
     * @param int $rmaId
     *
     * @return object
     */
    public function getConversations($rmaId)
    {
        $collection = $this->_conversationCollection
                            ->create()
                            ->addFieldToFilter("rma_id", $rmaId)
                            ->setOrder("created_time", "desc");
        return $collection;
    }

    /**
     * Get Customer/Seller Name By RMA Id
     *
     * @param int $rmaId
     *
     * @return string
     */
    public function getCustomerName($rmaId, $isSeller = true)
    {
        $rma = $this->_rma->create()->load($rmaId);
        if ($rma->getId()) {
            $customerId = $rma->getCustomerId();
            if ($isSeller) {
                $customerId = $rma->getSellerId();
            }
            $customer = $this->getCustomer($customerId);
            return $customer->getName();
        }
        return "";
    }

    /**
     * Get Customner by Customer Id
     *
     * @param int $customerId
     *
     * @return object
     */
    public function getCustomer($customerId)
    {
        $customer = $this->_customerFactory->create()->load($customerId);
        return $customer;
    }

    /**
     * Get Seller Status Title
     *
     * @param int $status
     *
     * @return string
     */
    public function getSellerStatusTitle($status)
    {
        if ($status == 0 || $status == 1) {
            $sellerStatus = "Pending";
        } elseif ($status == 2 || $status == 3) {
            $sellerStatus = "Processing";
        } elseif ($status == 4) {
            $sellerStatus = "Solved";
        } elseif ($status == 5) {
            $sellerStatus = "Declined";
        } else {
            $sellerStatus = "Item Canceled";
        }
        return $sellerStatus;
    }

    /**
     * Get Resolution Type Title
     *
     * @param int $status
     *
     * @return string
     */
    public function getResolutionTypeTitle($status)
    {
        if ($status == 1) {
            $resolution = "Refund";
        } elseif ($status == 2) {
            $resolution = "Replace";
        } else {
            $resolution = "Cancel Items";
        }
        return $resolution;
    }

    /**
     * Get Order Status Title
     *
     * @param int $status
     *
     * @return string
     */
    public function getOrderStatusTitle($status)
    {
        if ($status ==  1) {
            $orderStatus = "Delivered";
        } else {
            $orderStatus = "Not Delivered";
        }
        return $orderStatus;
    }

    /**
     * Get RMA Status Title
     *
     * @param int $status
     * @param int $finalStatus
     *
     * @return string
     */
    public function getRmaStatusTitle($status, $finalStatus = 0)
    {
        if ($finalStatus == 0) {
            if ($status == 1) {
                $rmaStatus = "Processing";
            } elseif ($status == 2) {
                $rmaStatus = "Solved";
            } elseif ($status == 3) {
                $rmaStatus = "Declined";
            } elseif ($status == 4) {
                $rmaStatus = "Canceled";
            } else {
                $rmaStatus = "Pending";
            }
        } else {
            if ($finalStatus == 1) {
                $rmaStatus = "Canceled";
            } elseif ($finalStatus == 2) {
                $rmaStatus = "Declined";
            } elseif ($finalStatus == 3 || $finalStatus == 4) {
                $rmaStatus = "Solved";
            } else {
                $rmaStatus = "Pending";
            }
        }
        return $rmaStatus;
    }

    /**
     * Get Final Status Title
     *
     * @param int $status
     *
     * @return string
     */
    public function getFinalStatusTitle($status)
    {
        if ($status == 1) {
            $finalStatus = "Canceled";
        } elseif ($status == 2) {
            $finalStatus = "Declined";
        } elseif ($status == 3) {
            $finalStatus = "Solved";
        } elseif ($status == 4) {
            $finalStatus = "Closed";
        } else {
            $finalStatus = "Pending";
        }
        return $rmaStatus;
    }

    /**
     * Get Seller's All Status
     *
     * @param int $status
     *
     * @return array
     */
    public function getAllStatus($resolutionType = 0)
    {
        if ($resolutionType == 3) {
            $allStatus = [
                            0 => 'Pending',
                            5 => 'Declined',
                            6 => 'Item Canceled'
                        ];
        } else {
            $allStatus = [
                        0 => 'Pending',
                        1 => 'Not Receive Package yet',
                        2 => 'Received Package',
                        3 => 'Dispatched Package',
                        5 => 'Declined'
                    ];
        }
        return $allStatus;
    }

    /**
     * Create Creditmemo
     *
     * @param array $data
     *
     * @return array
     */
    public function createCreditMemo($data)
    {
        $error = 0;
        $result = ['msg' => '', 'error' => ''];
        $rmaId = $data['rma_id'];
        $negative = $data['negative'];
        $rma = $this->getRmaDetails($rmaId);
        $orderId = $rma->getOrderId();
        $memo = [
                    'items' => [$rma->getItemId() => ['qty' => $rma->getQty()]],
                    'do_offline' => 1,
                    'comment_text' => "",
                    'shipping_amount' => 0,
                    'adjustment_positive' => 0,
                    'adjustment_negative' => $negative
                ];
        try {
            $this->_memoLoader->setOrderId($orderId);
            $this->_memoLoader->setCreditmemoId("");
            $this->_memoLoader->setCreditmemo($memo);
            $this->_memoLoader->setInvoiceId("");
            $memo = $this->_memoLoader->load();
            if ($memo) {
                if (!$memo->isValidGrandTotal()) {
                    $result['msg'] = __('Total must be positive.');
                    $result['error'] = 1;
                    return $result;
                }
                if (!empty($memo['comment_text'])) {
                    $memo->addComment(
                        $memo['comment_text'],
                        isset($memo['comment_customer_notify']),
                        isset($memo['is_visible_on_front'])
                    );

                    $memo->setCustomerNote($memo['comment_text']);
                    $memo->setCustomerNoteNotify(isset($memo['comment_customer_notify']));
                }
                if (isset($memo['do_offline'])) {
                    //do not allow online refund for Refund to Store Credit
                    if (!$memo['do_offline'] && !empty($memo['refund_customerbalance_return_enable'])) {
                        $result['msg'] = __('Cannot create online refund.');
                        $result['error'] = 1;
                        return $result;
                    }
                }
                $memoManagement = $this->_creditmemoManagement;
                $memoManagement->refund($memo, (bool)$memo['do_offline'], !empty($memo['send_email']));

                if (!empty($memo['send_email'])) {
                    $this->_memoSender->send($memo);
                }
                $result['msg'] = __('Credit memo generated succesfully.');
                $result['error'] = 0;
                return $result;
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $result['msg'] = $e->getMessage();
            $result['error'] = 1;
        } catch (\Exception $e) {
            $result['msg'] = __('Unable to save credit memo right now.');
            $result['error'] = 1;
        }
        return $result;
    }
    
    /**
     * Get Close RMA Text
     *
     * @param int $status
     *
     * @return string
     */
    public function getCloseRmaLabel($status)
    {
        $label = "";
        if ($status == 1) {
            $label = __("RMA is canceled by Customer.");
        } elseif ($status == 2) {
            $label = __("RMA is declined by Seller.");
        } elseif ($status == 3 || $status == 4) {
            $label = __("RMA is Solved.");
        }
        return $label;
    }

    /**
     * Get Product Details of Requested RMA
     *
     * @param int $rmaId
     *
     * @return collection object
     */
    public function getRmaProductDetails($rmaId)
    {
        return $this->_detailsResource->getRmaProductDetails($rmaId);
    }

    /**
     * Get Requested Quantity of RMA by Order Item Id
     *
     * @param int $itemId
     * @param int $orderId
     *
     * @return collection object
     */
    public function getItemRmaQty($itemId, $orderId)
    {
        $totalQty = 0;
        $collection = $this->_detailsCollection
                            ->create()
                            ->addFieldToFilter('item_id', $itemId)
                            ->addFieldToFilter('order_id', $orderId)
                            ->addFieldToFilter('final_status', ['eq' => 0]);
        foreach ($collection as $item) {
            $totalQty += $item->getQty();
        }
        return $totalQty;
    }

    /**
     * Get Final Quantity Which Can Be Requested
     *
     * @param int $itemId
     * @param int $orderId
     * @param int $qty
     * @param int $type
     *
     * @return int
     */
    public function getRmaQty($itemId, $orderId, $qty, $type)
    {
        if ($type == 1) {
            $qty = 0;
            $collection = $this->_itemCollection
                                ->create()
                                ->addFieldToFilter('order_item_id', $itemId);
            foreach ($collection as $item) {
                $qty += $item->getQty();
            }
        }
        $rmaQty = $this->getItemRmaQty($itemId, $orderId);
        $qty = $qty - $rmaQty;
        return $qty;
    }

    /**
     * Check Whether RMA is Allowed for Quantity or Not
     *
     * @param int $itemId
     * @param int $orderId
     * @param int $qty
     *
     * @return collection object
     */
    public function isRmaAllowed($itemId, $orderId, $qty)
    {
        $rmaQty = $this->getItemRmaQty($itemId, $orderId);
        $orderItem = $this->getOrderItem($orderId, $itemId);
        $totalQty = $orderItem->getQtyOrdered();
        $allowedQty = $totalQty - $rmaQty;
        if ($qty > $allowedQty) {
            return false;
        }
        return true;
    }

    /**
     * Send New RMA Email
     *
     * @param array $details
    */
    public function sendNewRmaEmail($details = [])
    {
        $details['template'] = self::NEW_RMA;
        $orderStatus = $this->getOrderStatusTitle($details['rma']['order_status']);
        $resolutionType = $this->getResolutionTypeTitle($details['rma']['resolution_type']);
        $reason = $this->getReasonById($details['rma']['reason_id']);
        $additionalInfo = $details['rma']['additional_info'];
        $customerName = $details['name'];
        $product = $this->_product->create()->load($details['rma']['product_id']);
        $templateVars = [
                            'name' => $customerName,
                            'rma_id' => $details['rma']['rma_id'],
                            'order_id' => $details['rma']['order_ref'],
                            'order_status' => $orderStatus,
                            'resolution_type' => $resolutionType,
                            'additional_info' => $additionalInfo,
                            'product_name' => $product->getName(),
                            'sku' => $product->getSku(),
                            'reason' => $reason,
                            'qty' => $details['rma']['qty']
                        ];

        $details['email'] = $details['rma']['customer_email'];
        if ($details['rma']['customer_id'] > 0) {
            $msg = __("New RMA is requested by customer.");
        } else {
            $msg = __("New RMA is requested by guest.");
        }

        //send to seller
        $sellerId = $details['rma']['seller_id'];
        if ($sellerId > 0) {
            $seller = $this->getCustomer($sellerId);
            $email = $seller->getEmail();
            $sellerName = $seller->getName();
            $templateVars['msg'] = $msg;
            $templateVars['name'] = $sellerName;
            $details['email'] = $email;
            $details['template_vars'] = $templateVars;
            $this->sendEmail($details);
        }
        
        //send to admin
        if ($this->isAllowedNotification()) {
            $adminEmail = $this->getAdminEmail();
            $templateVars['msg'] = $msg;
            $templateVars['name'] = self::ADMIN;
            $details['template_vars'] = $templateVars;
            $details['email'] = $adminEmail;
            $this->sendEmail($details);
        }

        //send to customer/guest
        $msg = __("You requested new RMA.");
        $templateVars['msg'] = $msg;
        $templateVars['name'] = $customerName;

        $details['template_vars'] = $templateVars;
        $details['email'] = $details['rma']['customer_email'];
        $this->sendEmail($details);
    }

    /**
     * Send Update RMA Email
     *
     * @param array $details
    */
    public function sendUpdateRmaEmail($details = [])
    {
        $details['template'] = self::UPDATE_RMA;
        $rma = $this->getRmaDetails($details['rma_id']);
        $finalStatus = $rma->getFinalStatus();
        $sellerStatus = $rma->getSellerStatus();
        $status = $rma->getStatus();
        $rmaStatusTitle = $this->getRmaStatusTitle($status, $finalStatus);
        $sellerStatusTitle = $this->getSellerStatusTitle($sellerStatus);
        $sellerId = $rma->getSellerId();
        $customerId = $rma->getCustomerId();
        $email = $rma->getCustomerEmail();
        $customerEmail = $rma->getCustomerEmail();
        $adminEmail = $this->getAdminEmail();
        $adminName = self::ADMIN;
        if ($customerId > 0) {
            $customer = $this->getCustomer($customerId);
            $customerName = $customer->getName();
        } else {
            $customerName = 'Guest';
        }
        $templateVars = [
                            'name' => $customerName,
                            'rma_status' => $rmaStatusTitle,
                            'seller_status' => $sellerStatusTitle
                        ];
        //send to customer/guest
        $msg = __("RMA status is updated.");
        $templateVars['msg'] = $msg;
        $details['template_vars'] = $templateVars;
        $details['email'] = $customerEmail;
        $this->sendEmail($details);
        //send to seller
        $msg = __("RMA status is updated.");
        $templateVars['msg'] = $msg;
        $seller = $this->getCustomer($sellerId);
        $email = $seller->getEmail();
        $sellerName = $seller->getName();
        $templateVars['name'] = $sellerName;
        $details['email'] = $email;
        $details['template_vars'] = $templateVars;
        $this->sendEmail($details);
        //send to admin
        $templateVars['name'] = self::ADMIN;
        $details['template_vars'] = $templateVars;
        $this->sendNotificationToAdmin($details);
    }

    /**
     * Send New Message Email
     *
     * @param array $details
    */
    public function sendNewMessageEmail($details)
    {
        $isAdmin = false;
        $details['template'] = self::RMA_MESSAGE;
        $rmaId = $details['rma_id'];
        $message = $details['message'];
        $senderType = $details['sender_type'];
        $rma = $this->getRmaDetails($rmaId);
        $sellerId = $rma->getSellerId();
        $seller = $this->getCustomer($rma->getSellerId());
        $customerId = $rma->getCustomerId();
        $customerEmail = $rma->getCustomerEmail();
        $adminEmail = $this->getAdminEmail();
        $adminName = self::ADMIN;
        $customerName = $this->getSenderName($customerId);
        $senderData = $this->getSenderDetails($sellerId);

        if ($senderType == 1) { // seller send message
            $msg = __("Seller sent message on RMA #%1", $rmaId);
            $senderData = [
                            'email' => $customerEmail,
                            'name' => $customerName
                        ];
        } elseif ($senderType == 2) { // Customer send message
            $msg = __("Customer sent message on RMA #%1", $rmaId);
        } elseif ($senderType == 3) { // Guest send message
            $msg = __("Guest sent message on RMA #%1", $rmaId);
        } else { // Admin send message
            $isAdmin = true;
            $msg = __("Admin sent message on RMA #%1", $rmaId);
        }
        $details['email'] = $senderData['email'];
        $templateVars = [
                        'name' => $senderData['name'],
                        'message' => $message,
                        'msg' => $msg
                    ];
        $details['template_vars'] = $templateVars;
        $this->sendEmail($details);
        if ($isAdmin) {
            //Send to Customer
            $details['email'] = $customerEmail;
            $details['template_vars']['name'] = $customerName;
        } else {
            //Send to Admin
            $this->sendNotificationToAdmin($details);
        }
    }

    /**
     * Send Email
     *
     * @param array $details
    */
    public function sendEmail($details)
    {
        try {
            $adminEmail = $this->getAdminEmail();
            $area = \Magento\Framework\App\Area::AREA_FRONTEND;
            $storeId = \Magento\Store\Model\Store::DEFAULT_STORE_ID;
            $sender = ['name' => self::ADMIN, 'email' => $adminEmail];
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $transport = $this->_transportBuilder
                            ->setTemplateIdentifier($details['template'])
                            ->setTemplateOptions(['area' => $area, 'store' => $storeId])
                            ->setTemplateVars($details['template_vars'])
                            ->setFrom($sender)
                            ->addTo($details['email'])
                            ->getTransport();
            $transport->sendMessage();
            $this->_inlineTranslation->resume();
            return;
        } catch (\Exception $e) {
            $this->_inlineTranslation->resume();
        }
    }

    /**
     * Check Guest Details
     *
     * @param int $incrementId
     * @param string $emil
     *
     * @return bool
     */
    public function authenticate($incrementId, $email)
    {
        $orders = $this->_orderCollectionFactory->create()
                        ->addFieldToSelect('*')
                        ->addFieldToFilter('customer_email', $email)
                        ->addFieldToFilter('increment_id', $incrementId)
                        ->addFieldToFilter('customer_is_guest', 1)
                        ->setPageSize(1);
        if ($orders->getSize()) {
            return true;
        }
        return false;
    }

    /**
     * Login Guest
     *
     * @param string $email
     */
    public function loginGuest($email)
    {
        $this->_session->setGuestEmailId($email);
    }

    /**
     * Check Whether Guest is Logged In or Not
     *
     * @return bool
     */
    public function isGuestLoggedIn()
    {
        $email = trim($this->_session->getGuestEmailId());
        if (strlen($email) > 0) {
            return true;
        }
        return false;
    }

    /**
     * Get Guest Email Id
     *
     * @return bool
     */
    public function getGuestEmailId()
    {
        return trim($this->_session->getGuestEmailId());
    }

    /**
     * Get List of Jquery Errors
     *
     * @return array
     */
    public function getJsErrorList()
    {
        $errors = [];
        $errors[] = "There is some error in preview image.";
        $errors[] = "Quantity not allowed for RMA.";
        $errors[] = "Please select item.";
        $errors[] = "Please select quantity.";
        $errors[] = "Image type not allowed.";
        return $errors;
    }

    /**
     * Validate Image
     *
     * @param string $imagePath
     *
     * @return bool
     */
    public function validateImage($imagePath)
    {
        try {
            $imageDetails = getimagesize($imagePath);
            $success = true;
        } catch (\Exception $e) {
            $success = false;
        }
        return $success;
    }

    /**
     * Check Whether Image Upload Allowed or Not
     *
     * @param int $numberOfImages
     *
     * @return bool
     */
    public function isAllowedImageUpload($numberOfImages)
    {
        $success = true;
        $allowedExtensions = ['png', 'jpg', 'jpeg', 'gif'];
        if ($numberOfImages > 0) {
            for ($i = 0; $i < $numberOfImages; $i++) {
                $fileId = "image[$i]";
                try {
                    $uploader = $this->_fileUploader->create(['fileId' => $fileId]);
                    $uploader->setAllowedExtensions($allowedExtensions);
                    $imageData = $uploader->validateFile();
                    $isValidImage = $this->validateImage($imageData['tmp_name']);
                    if (!$isValidImage) {
                        $success =  false;
                        break;
                    }
                } catch (\Exception $e) {
                    $success =  false;
                    break;
                }
            }
        }
        return $success;
    }

    /**
     * Get Skipped Images Indexes
     *
     * @return array
     */
    public function getSkippedImagesIndex()
    {
        $skippedIndexs = $this->_request->getParam('skip_checked');
        $skippedIndexs = trim($skippedIndexs);
        if (strpos($skippedIndexs, ",") !== false) {
            $skippedIndexs = explode(",", $skippedIndexs);
        } else {
            if ($skippedIndexs == "") {
                $skippedIndexs = [];
            } else {
                $skippedIndexs = [$skippedIndexs];
            }
        }
        return $skippedIndexs;
    }

    /**
     * Upload All Images of Rma
     *
     * @param int $numberOfImages
     * @param int $id
     */
    public function uploadImages($numberOfImages, $id)
    {
        $skippedIndexs = $this->getSkippedImagesIndex();
        $allowedExtensions = ['png', 'jpg', 'jpeg', 'gif'];
        if ($numberOfImages > 0) {
            $uploadPath = $this->_fileSystem
                                ->getDirectoryRead(DirectoryList::MEDIA)
                                ->getAbsolutePath('marketplace/rma/');
            $uploadPath .= $id;
            $count = 0;
            for ($i = 0; $i < $numberOfImages; $i++) {
                $fileId = "image[$i]";
                if (!in_array($i, $skippedIndexs)) {
                    ++$count;
                    $this->uploadImage($fileId, $uploadPath, $count);
                }
            }
        }
    }

    /**
     * Upload Image of Rma
     *
     * @param string $fileId
     * @param string $uploadPath
     * @param int $count
     */
    public function uploadImage($fileId, $uploadPath, $count)
    {
        $allowedExtensions = ['png', 'jpg', 'jpeg', 'gif'];
        try {
            $uploader = $this->_fileUploader->create(['fileId' => $fileId]);
            $uploader->setAllowedExtensions($allowedExtensions);
            $imageData = $uploader->validateFile();
            $name = $imageData['name'];
            $ext = explode('.', $name);
            $ext = strtolower(end($ext));
            $imageName = 'image'.$count.'.'.$ext;
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(false);
            $uploader->save($uploadPath, $imageName);
        } catch (\Exception $e) {
            $error =  true;
        }
    }

    /**
     * Upload Image of Rma
     *
     * @param int $customerId
     *
     * @return string
     */
    public function getSenderName($customerId)
    {
        if ($customerId > 0) {
            $customer = $this->getCustomer($customerId);
            $customerName = $customer->getName();
        } else {
            $customerName = __('Guest');
        }
        return $customerName;
    }

    /**
     * Send Notification to Admin
     *
     * @param array $details
     */
    public function sendNotificationToAdmin($details)
    {
        $adminEmail = $this->getAdminEmail();
        $adminName = self::ADMIN;
        if ($this->isAllowedNotification()) {
            $details['email'] = $adminEmail;
            $details['template_vars']['name'] = $adminName;
            $this->sendEmail($details);
        }
    }

    /**
     * Get Sender Details
     *
     * @param int $sellerId
     */
    public function getSenderDetails($sellerId)
    {
        $result = [];
        if ($sellerId > 0) {
            $seller = $this->getCustomer($sellerId);
            $result['email'] = $seller->getEmail();
            $result['name'] = $seller->getName();
        } else {
            $result['email'] = $this->getAdminEmail();
            $result['name'] = self::ADMIN;
        }
        return $result;
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Block;

use Magento\Framework\Session\SessionManager;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Customer View RMA Block.
 */
class Viewrma extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Directory\Model\Currency;
     */
    protected $_currency;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime;
     */
    protected $_date;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Rmaitem\CollectionFactory
     */
    protected $_rmaItemCollectionFactory;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;

    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Allrma\Collection
     */
    protected $rma;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager = null;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Conversation\CollectionFactory
     */
    protected $_conversationCollectionFactory;
    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $_imageHelper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context           $context
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Customer\Model\Session                            $customerSession
     * @param \Magento\Sales\Model\Order\Config                          $orderConfig
     * @param array                                                      $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\Block\Product\Context $productContext,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\View\Element\FormKey $formKey,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Webkul\Rmasystem\Model\ResourceModel\Rmaitem\CollectionFactory $rmaItemCollectionFactory,
        \Webkul\Rmasystem\Model\ResourceModel\Conversation\CollectionFactory $conversationCollectionFactory,
        array $data = []
    ) {
     
        $this->_rmaItemCollectionFactory = $rmaItemCollectionFactory;
        $this->_conversationCollectionFactory = $conversationCollectionFactory;
        $this->_customerSession = $customerSession;
        $this->_currency = $currency;
        $this->_date = $date;
        $this->_formKey = $formKey;
        $this->_objectManager = $objectManager;
        $this->_imageHelper = $productContext->getImageHelper();
        parent::__construct($context, $data);
    }

    /**
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('RMA Details'));
    }

    /**
     * @return bool|\Magento\Sales\Model\ResourceModel\Order\Collection
     */
    public function getRmaCollection($id)
    {
        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }

        if (!$this->rma) {
            $collection = $this->_conversationCollectionFactory->create()->addFieldToFilter('rma_id', $id);
            $this->rma = $collection;
        }
        return $this->rma;
    }
    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    /**
     * @return int
     */
    public function getRmaId()
    {
        $id = $this->getRequest()->getParam('id');

        return $id;
    }
    /**
     * @return int
     */
    public function getCustomerId()
    {
        return $this->_customerSession->getCustomerId();
    }
    /**
     * @return string
     */
    public function getLabelBaseUrl()
    {
        return $this->_objectManager->create('Webkul\Rmasystem\Model\Shippinglabel\Image')->getBaseUrl();
    }
    /**
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma\Image')->getBaseUrl().$this->getRmaId().'/image';
    }
    /**
     * @return string
     */
    public function getBaseDirRead()
    {
        return $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma\Image')->getBaseDirRead();
    }
    /**
     * @return string
     */
    public function getBarBaseUrl()
    {
        return $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma\Image')->getBarcodeBaseUrl();
    }

    public function getImages()
    {
        $folderName = $this->getBaseDirRead().$this->getRmaId().'/image/';
        $images = glob($folderName.'*.{jpg,JPG,jpeg,JPEG,gif,GIF,png,PNG,bmp,BMP}', GLOB_BRACE);
        return $images;
    }

    /**
     * @return Mixed
     */
    public function getRmaDetail()
    {
        $id = $this->getRequest()->getParam('id');
        $collection = $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma')
            ->getCollection()
            ->addFieldToFilter('customer_id', ['eq' => $this->getCustomerId()])
            ->addFieldToFilter('rma_id', ['eq' => $id]);
        if ($collection->getSize()) {
            foreach ($collection as $value) {
                return $value;
            }
        } else {
            return false;
        }
        //return $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma')->load($id);
    }
    /**
     * @return Mixed
     */
    public function getRmaShippingLabelModel($id)
    {
        $collection = $this->_objectManager->create('Webkul\Rmasystem\Model\Shippinglabel')->load($id);

        return $collection;
    }
    /**
     * @return Mixed
     */
    public function getSalesOrderItemDetail($itemId)
    {
        return $this->_objectManager->create('Magento\Sales\Model\Order\Item')->load($itemId);
    }
    /**
     * @return Mixed
     */
    public function getProductDetail($productId)
    {
        return $this->_objectManager->create('Magento\Catalog\Model\Product')->load($productId);
    }
    /**
     * @return Mixed
     */
    public function getReason($reasonId)
    {
        return $this->_objectManager->create('Webkul\Rmasystem\Model\Reason')->load($reasonId);
    }

    /**
     * @return array
     */
    public function getItemCollection($rma_id)
    {
        $collection = $this->_rmaItemCollectionFactory->create()->addFieldToFilter('rma_id', $rma_id);

        return $collection;
    }

    /**
     * @return float
     */
    public function getCurrency($price)
    {
        return $currency = $this->_currency->format($price);
    }
    /**
     * @param  String Date
     *
     * @return String Timestamp
     */
    public function getTimestamp($date)
    {
        return $date = $this->_date->timestamp($date);
    }

    /**
     * Get form key.
     *
     * @return string
     */
    public function getFormKey()
    {
        return $this->_formKey->getFormKey();
    }

    /**
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('customer/account/');
    }

    public function imageHelperObj()
    {
        return $this->_imageHelper;
    }
}

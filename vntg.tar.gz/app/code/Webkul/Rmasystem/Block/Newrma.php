<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Block;

use Magento\Framework\Session\SessionManager;
use Webkul\Rmasystem\Helper\Filter;

/**
 * Customer Create new RMA block.
 */
class Newrma extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface;
     */
    protected $_scopeConfig;
    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $_currency;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Resion\CollectionFactory
     */
    protected $_regionCollectionFactory;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory
     */
    protected $_orderShipmentCollectionFactory;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\
     */
    protected $_orderCollectionFactory;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /**
     * @var Session
     */
    protected $_session;
    /**
     * @var Webkul\Rmasystem\Helper\Filter
     */
    protected $_filterSorting;
    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $_orderConfig;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;

    /** @var \Magento\Sales\Model\ResourceModel\Order\Collection */
    protected $_rma;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager = null;
    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    protected $_connection;

    /**
     * @param \Magento\Framework\View\Element\Template\Context                      $context
     * @param \Magento\Customer\Model\Session                                       $customerSession
     * @param \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory   $orderShipmentCollectionFactory
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory            $orderCollectionFactory
     * @param \Magento\Directory\Model\CurrencyFactory                              $currencyFactory
     * @param \Magento\Framework\Stdlib\DateTime\DateTime                           $date
     * @param \Magento\Framework\View\Element\FormKey                               $formKey
     * @param \Magento\Framework\ObjectManagerInterface                             $objectManager
     * @param \Webkul\Rmasystem\Model\ResourceModel\Reason\CollectionFactory        $regionCollectionFactory
     * @param SessionManager                                                        $session
     * @param Filter                                                                $filterSorting
     * @param array                                                                 $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory $orderShipmentCollectionFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\View\Element\FormKey $formKey,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Webkul\Rmasystem\Model\ResourceModel\Reason\CollectionFactory $regionCollectionFactory,
        SessionManager $session,
        Filter $filterSorting,
        array $data = []
    ) {
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_orderShipmentCollectionFactory = $orderShipmentCollectionFactory;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_customerSession = $customerSession;
        $this->_session = $session;
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_currency = $currency;
        $this->_date = $date;
        $this->_formKey = $formKey;
        $this->_filterSorting = $filterSorting;
        $this->_objectManager = $objectManager;
        parent::__construct($context, $data);
    }

    /**
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('New RMA'));
    }

    /**
     * @return bool|\Magento\Sales\Model\ResourceModel\Order\Collection
     */
    public function getRmaCollection()
    {
        if (!($customerId = $this->_customerSession->getCustomerId())) {
            return false;
        }
        $this->_session->unsFilterData();
        $this->_session->unsSortingSession();
        $allowedStatus = $this->_scopeConfig->getValue('rmasystem/parameter/allow_order');
        $allowedDays = $this->_scopeConfig->getValue('rmasystem/parameter/days');
        if (!$this->_rma) {
            $joinTable = $this->_objectManager->create(
                'Webkul\Rmasystem\Model\ResourceModel\Allrma\Collection'
            )->getTable('sales_order');
            if ($allowedStatus == 'complete') {
                $collection = $this->_orderShipmentCollectionFactory->create();
                $collection->getSelect()->join(
                    $joinTable.' as so',
                    'main_table.order_id = so.entity_id',
                    ['grand_total', 'so.increment_id', 'so.created_at']
                )->where('main_table.customer_id ='.$customerId);

                $collection->addFilterToMap('created_at', 'so.created_at');
                $collection->addFilterToMap('customer_id', 'so.customer_id');
                $collection->addFilterToMap('increment_id', 'so.increment_id');
                $collection->addFieldToFilter('customer_id', $customerId);
                $collection->addFieldToFilter('so.status', 'complete');
            } else {
                $collection = $this->_objectManager->create(
                    'Magento\Sales\Model\Order'
                )->getCollection()
                    ->addFieldToFilter(
                        'customer_id',
                        $customerId
                    )
                    ->addFieldToFilter(
                        'status',
                        ['neq' => 'canceled']
                    )
                    ->addFieldToFilter(
                        'status',
                        ['neq' => 'closed']
                    );
            }
            if ($allowedDays != '') {
                $todaySecond = time();
                $allowedSeconds = $allowedDays * 86400;
                $pastSecondFromToday = $todaySecond - $allowedSeconds;
                $validFrom = date('Y-m-d H:i:s', $pastSecondFromToday);
                $collection->addFieldToFilter('created_at', ['gteq' => $validFrom]);
            }
            $collection->setOrder('increment_id', 'desc');
            $sortingData = $this->getSortingSession();
            if ($sortingData['attr'] != '' && $sortingData['direction'] != '') {
                $collection->setOrder($sortingData['attr'], $sortingData['direction']);
            }
            $filterData = $this->getFilterData();
            if ($filterData['order_id'] != '') {
                $collection->addFieldToFilter('increment_id', $filterData['order_id']);
            }
            if ($filterData['price'] != '') {
                $collection->addFieldToFilter('grand_total', $filterData['price']);
            }
            if ($filterData['date'] != '') {
                $collection->addFieldToFilter('created_at', ['gteq' => $filterData['date'].' 00:00:00']);
            }
            $this->_rma = $collection;
        }

        return $this->_rma;
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();

        if ($this->getRmaCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'webkul.rmasystem.new.pager'
            )->setAvailableLimit([5 => 5, 10 => 10, 50 => 50])
            ->setCollection(
                $this->getRmaCollection()
            );
            $this->setChild('pager', $pager);

            $this->getRmaCollection()->load();
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    /**
     * @return array
     */
    public function getSortingSession()
    {
        return $this->_filterSorting->getNewRmaSortingSession();
    }
    /**
     * @return array
     */
    public function getFilterData()
    {
        return $this->_filterSorting->getNewRmaFilterSession();
    }
    /**
     * @return array
     */
    public function getOrderCollection($orderId)
    {
        return $this->_orderCollectionFactory->create()
                    ->addFieldToFilter(
                        'entity_id',
                        $orderId
                    );
    }
    /**
     * @return array
     */
    public function getRegionCollection()
    {
        return $this->_regionCollectionFactory->create()
                    ->addFieldToFilter('status', 1);
    }
    /**
     * [loadOrderModel description].
     *
     * @param int $orderId
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrderModel($orderId)
    {
        return $this->_objectManager->create('Magento\Sales\Model\Order')->load($orderId);
    }
    /**
     * @param Decimal $price
     *
     * @return [type] [description]
     */
    public function getCurrency($price)
    {
        return $currency = $this->_currency->format($price);
    }
    /**
     * @param Decimal $price
     *
     * @return [type] [description]
     */
    public function getCurrencySymbol()
    {
        return $this->_currency->getCurrencySymbol();
    }
    /**
     * @param  String Date
     *
     * @return String Timestamp
     */
    public function getTimestamp($date)
    {
        return $date = $this->_date->timestamp($date);
    }
    /**
     *
     */
    public function getAllowedStatus()
    {
        return $this->_scopeConfig->getValue('rmasystem/parameter/allow_order');
    }
    /**
     *
     */
    public function getPolicy()
    {
        return $this->_scopeConfig->getValue('rmasystem/parameter/returnpolicy');
    }
    /**
     * Get form key.
     *
     * @return string
     */
    public function getFormKey()
    {
        return $this->_formKey->getFormKey();
    }

    /**
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('customer/account/');
    }
}

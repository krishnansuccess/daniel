<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Block\Adminhtml\Allrma;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $_currency;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Allrma\CollectionFactory
     */
    protected $_rmaCollectionFactory;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Rmaitem\CollectionFactory
     */
    protected $_rmaItemCollectionFactory;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Shippinglabel\CollectionFactory
     */
    protected $_labelCollectionFactory;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Conversation\CollectionFactory
     */
    protected $_conversationCollectionFactory;
    /**
     * @var \Webkul\Rmasystem\Model\ResourceModel\Resion\CollectionFactory
     */
    protected $_regionCollectionFactory;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory
     */
    protected $_orderShipmentCollectionFactory;
    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $_orderModel;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\
     */
    protected $_orderCollectionFactory;
    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $_orderConfig;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;

    /** @var \Webkul\Rmasystem\Model\ResourceModel\Allrma\Collection */
    protected $rma;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager = null;
    /**
     * Core registry.
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Magento\Framework\View\Element\FormKey $formKey
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Webkul\Rmasystem\Model\ResourceModel\Allrma\CollectionFactory $rmaCollectionFactory
     * @param \Webkul\Rmasystem\Model\ResourceModel\Reason\CollectionFactory $regionCollectionFactory
     * @param \Webkul\Rmasystem\Model\ResourceModel\Rmaitem\CollectionFactory $rmaItemCollectionFactory
     * @param \Webkul\Rmasystem\Model\ResourceModel\Shippinglabel\CollectionFactory $labelCollectionFactory
     * @param \Webkul\Rmasystem\Model\ResourceModel\Conversation\CollectionFactory $conversationCollectionFactory
     * @param \Magento\Framework\Registry $registry
     * @param array                                 $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\View\Element\FormKey $formKey,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Webkul\Rmasystem\Model\ResourceModel\Allrma\CollectionFactory $rmaCollectionFactory,
        \Webkul\Rmasystem\Model\ResourceModel\Reason\CollectionFactory $regionCollectionFactory,
        \Webkul\Rmasystem\Model\ResourceModel\Rmaitem\CollectionFactory $rmaItemCollectionFactory,
        \Webkul\Rmasystem\Model\ResourceModel\Shippinglabel\CollectionFactory $labelCollectionFactory,
        \Webkul\Rmasystem\Model\ResourceModel\Conversation\CollectionFactory $conversationCollectionFactory,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_rmaCollectionFactory = $rmaCollectionFactory;
        $this->_labelCollectionFactory = $labelCollectionFactory;
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_rmaItemCollectionFactory = $rmaItemCollectionFactory;
        $this->_conversationCollectionFactory = $conversationCollectionFactory;
        $this->_coreRegistry = $registry;
        $this->_currency = $currency;
        $this->_date = $date;
        $this->_formKey = $formKey;
        $this->_objectManager = $objectManager;
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * Initialize blog post edit block.
     */
    protected function _construct()
    {
        $this->_objectId = 'rma_id';
        $this->_blockGroup = 'Webkul_Rmasystem';
        $this->_controller = 'adminhtml_allrma';

        parent::_construct();

        if ($this->_isAllowedAction('Webkul_Rmasystem::update')) {
            $this->buttonList->update('save', 'label', __('Update'));
        } else {
            $this->buttonList->remove('save');
        }
        $this->buttonList->remove('delete');
    }

    /**
     * Retrieve text for header element depending on loaded post.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('rmasystem_allrma')->getId()) {
            return __(
                "Edit Post '%1'",
                $this->escapeHtml(
                    $this->_coreRegistry->registry('rmasystem_allrma')->getTitle()
                )
            );
        } else {
            return __('New Rma');
        }
    }

    /**
     * Check permission for passed action.
     *
     * @param string $resourceId
     *
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
    /**
     * Retrieve url for form submiting.
     *
     * @return string
     */
    public function getUpdateUrl()
    {
        return $this->getUrl('rmasystem/allrma/update');
    }

    /**
     * Getter of url for "Save and Continue" button
     * tab_id will be replaced by desired by JS later.
     *
     * @return string
     */
    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl('allrma/*/update', ['_current' => true, 'back' => 'edit', 'active_tab' => '{{tab_id}}']);
    }
    /**
     * @return bool|\Magento\Sales\Model\ResourceModel\Order\Collection
     */
    public function getRmaCollection($id)
    {
        if (!$this->rma) {
            $collection = $this->_conversationCollectionFactory->create()->addFieldToFilter('rma_id', $id);
            $this->rma = $collection;
        }

        return $this->rma;
    }

    /**
     * @return int
     */
    public function getRmaId()
    {
        $id = $this->getRequest()->getParam('id');

        return $id;
    }

    /**
     * @return int
     */
    public function getCustomerDetail($id)
    {
        return $this->_objectManager->get('Magento\Customer\Model\Customer')->load($id);
    }
    /**
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_objectManager->create(
            'Webkul\Rmasystem\Model\Allrma\Image'
        )->getBaseUrl().$this->getRmaId().'/image';
    }
    /**
     * @return string
     */
    public function getBaseDirRead()
    {
        return $this->_objectManager->create(
            'Webkul\Rmasystem\Model\Allrma\Image'
        )->getBaseDirRead();
    }

    public function getImages()
    {
        $folderName = $this->getBaseDirRead().$this->getRmaId().'/image/';
        
        $images = glob($folderName.'*.{jpg,JPG,jpeg,JPEG,gif,GIF,png,PNG,bmp,BMP}', GLOB_BRACE);
        return $images;
    }

    /**
     * @return Mixed \Webkul\Rmasystem\Model\Allrma
     */
    public function getRmaDetail()
    {
        $id = $this->getRequest()->getParam('id');

        return $this->_objectManager->create('\Webkul\Rmasystem\Model\Allrma')->load($id);
    }
    /**
     * @return Mixed
     */
    public function getSalesOrderItemDetail($itemId)
    {
        return $this->_objectManager->create('\Magento\Sales\Model\Order\Item')->load($itemId);
    }
    /**
     * @return Mixed \Magento\Sales\Model\Order\Item
     */
    public function getProductDetail($productId)
    {
        return $this->_objectManager->create('\Magento\Catalog\Model\Product')->load($productId);
    }
    /**
     * @return Mixed \Webkul\Rmasystem\Model\Reason
     */
    public function getReason($reasonId)
    {
        return $this->_objectManager->create('\Webkul\Rmasystem\Model\Reason')->load($reasonId);
    }

    /**
     * @return array
     */
    public function getItemCollection($rmaId)
    {
        $collection = $this->_rmaItemCollectionFactory->create()->addFieldToFilter('rma_id', $rmaId);

        return $collection;
    }
    /**
     * @return array
     */
    public function getShippingLabelCollection()
    {
        $collection = $this->_labelCollectionFactory->create()->addFieldToFilter('status', 1);

        return $collection;
    }
    /**
     * @return string
     */
    public function getLabelBaseUrl()
    {
        return $this->_objectManager->create('\Webkul\Rmasystem\Model\Shippinglabel\Image')->getBaseUrl();
    }
    /**
     * @param Decimal $price
     *
     * @return formated
     */
    public function getCurrency($price)
    {
        return $currency = $this->_currency->format($price);
    }
    /**
     * @param  String Date
     *
     * @return String Timestamp
     */
    public function getTimestamp($date)
    {
        return $date = $this->_date->timestamp($date);
    }

    /**
     * Get form key.
     *
     * @return string
     */
    public function getFormKey()
    {
        return $this->_formKey->getFormKey();
    }
}

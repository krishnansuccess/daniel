<?php
/**
 *
 *
 */
namespace Webkul\Rmasystem\Model\Config\Source;

class Orderstatus implements \Magento\Framework\Option\ArrayInterface
{
    public function __construct()
    {
    }
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label'=>__('Select Status Type'), 'value' => ''];
        $options[] = ['label'=>__('Complete'), 'value' => 'complete'];
        $options[] =['label'=>__('All Status'), 'value' => 'all'];
        return $options;
    }
}

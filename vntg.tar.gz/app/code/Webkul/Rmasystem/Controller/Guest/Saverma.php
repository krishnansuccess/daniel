<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Guest;

use Magento\Framework\App\Action\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlFactory;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Session\SessionManager;

class Saverma extends \Magento\Framework\App\Action\Action
{
    /** @var \Magento\Framework\UrlInterface */
    protected $urlModel;
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    protected $_emailHelper;

    protected $_fileIo;
    /**
     * @var Session
     */
    protected $session;
    /**
     *
     * @var string
     */
    protected $rmaModel = 'Webkul\Rmasystem\Model\Allrma';
    /**
     * Filesystem facade.
     *
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * File Uploader factory.
     *
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @param Action\Context $context
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        UrlFactory $urlFactory,
        SessionManager $session,
        \Webkul\Rmasystem\Helper\Email $emailHelper,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        File $file_Io
    ) {
    
        $this->urlModel = $urlFactory->create();
        $this->storeManager = $storeManager;
        $this->_fileIo = $file_Io;
        $this->session = $session;
        $this->_emailHelper = $emailHelper;
        $this->_filesystem = $filesystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $post = $this->getRequest()->getPost();
        $error = $this->validatePostValue();
        if ($error) {
            $this->messageManager->addError(
                __('All required fields must have value.')
            );
            return $resultRedirect->setPath('*/guest/rmanew');
        }
        $data = $this->session->getGuestData();
        if (isset($data)) {
            $error = false;
            $order = $this->_objectManager->create('Magento\Sales\Model\Order')->load($post["order_id"]);
            $orderItems = $order->getAllItems();
            $remainsQty = 0;
            foreach ($post["item_checked"] as $key => $item) {
                $collection = $this->_objectManager->create('Webkul\Rmasystem\Model\Rmaitem')
                    ->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $post["order_id"]])
                    ->addFieldToFilter('item_id', ['eq' => $key]);

                if ($collection->getSize()) {
                    foreach ($orderItems as $item) {
                        if ($item->getId() == $collection->getFirstItem()->getItemId()) {
                            $remainsQty = $item->getQtyOrdered() - $collection->getFirstItem()->getQty();
                            if ($post["return_item"][$key] > $remainsQty) {
                                $error = true;
                            }
                        }
                    }
                }
            }
            if ($error) {
                $this->messageManager->addError(
                    __('Invalid requested item qty(s).')
                );
                return $resultRedirect->setPath('*/guest/rmanew');
            }
            $model = $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma');
            $model->setOrderId($post["order_id"])
                ->setGroup("guest")
                ->setIncrementId($post["increment_id"])
                ->setResolutionType($post["resolution_type"])
                ->setPackageCondition($post["package_condition"])
                ->setAdditionalInfo($post["additional_info"])
                ->setCustomerDeliveryStatus($post["customer_delivery_status"])
                ->setCustomerConsignmentNo($post["customer_consignment_no"])
                ->setGuestEmail($data["email"])
                ->setStatus(1)
                ->setCreatedAt(time());

            $lastRmaId = $model->save()->getId();
            $imageArray = [];
            $imageModel = $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma\Image');
            $path = $imageModel->getBaseDir($lastRmaId);

            $extArray = ['jpg','JPG','jpeg','JPEG','gif','GIF','png','PNG','bmp','BMP'];
            try {
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'related_images']);
                $uploader->setAllowedExtensions($extArray);
                $uploader->setAllowRenameFiles(true);
                $uploader->setAllowCreateFolders(true);
                $result = $uploader->save($path);
                $imageArray[$result['file']] = $result['file'];
            } catch (\Exception $e) {
                $error = false;
            }
            $rma = $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma')->load($lastRmaId);
            $rma->setImage(serialize($imageArray))->save();
            foreach ($post["item_checked"] as $key => $item) {
                $model = $this->_objectManager->create('Webkul\Rmasystem\Model\Rmaitem');
                $model->setRmaId($lastRmaId)
                        ->setItemId($key)
                        ->setReasonId($post["item_reason"][$key])
                        ->setQty($post["return_item"][$key])
                        ->setOrderId($post['order_id']);
                $model->save();
            }
            $this->_emailHelper->sendNewRmaEmail($post, $rma);

            $barCode = new \Webkul\Rmasystem\Model\Rmaitem\Barcode39($post['increment_id']);
            $barCode->barcode_text_size = 5;
            $barCode->barcode_bar_thick = 4;
            $barCode->barcode_bar_thin = 2;
            $barCodePath = $imageModel->getBarcodeDir();
            $this->_fileIo->mkdir($barCodePath);
            $barCode->draw($barCodePath.$lastRmaId.".gif");
            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
             $this->messageManager->addSuccess(
                 __('RMA Successfully Saved.')
             );
            return $resultRedirect->setPath('*/guest/rmalist');
        } else {
            $this->messageManager->addError(
                __('You are not authorized to create RMA.')
            );
            return $resultRedirect->setPath('*/guest/login');
        }
    }

    public function validatePostValue()
    {
        $error1 = false;
        $error2 = false;
        $error3 = false;
        $error = false;
        $post = $this->getRequest()->getPost();
        
        foreach ($post['item_checked'] as $itemId) {
            foreach ($post['return_item'] as $key => $value) {
                if ($itemId == $key) {
                    $error1 = $value?false:true;
                }
            }
            foreach ($post['item_reason'] as $key => $value) {
                if ($itemId == $key) {
                    $error2 = $value?false:true;
                }
            }
        }
        if ($post['increment_id'] == '' ||
            $post['order_id'] == '' ||
            $post['resolution_type'] == '' ||
            $post['package_condition'] == ''
        ) {
            $error3 = true;
            // return $resultRedirect->setPath('*/newrma/index');
        }
        if ($error1 || $error2 || $error3) {
            $error = true;
        }
        return $error;
    }
}

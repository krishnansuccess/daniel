<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Guest;

use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlFactory;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Session\SessionManager;

class Rmacancel extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /** @var \Magento\Framework\UrlInterface */
    protected $urlModel;
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    protected $_emailHelper;

    protected $_fileIo;
    /**
     * @var Session
     */
    protected $session;
    /**
     *
     * @var string
     */
    protected $rmaModel = 'Webkul\Rmasystem\Model\Allrma';
    /**
     * @param Action\Context $context
     */
    public function __construct(
        Context $context,
        SessionManager $session,
        \Webkul\Rmasystem\Helper\Email $emailHelper
    ) {
    
        $this->session = $session;
        $this->_emailHelper = $emailHelper;
        parent::__construct($context);
    }


    /**
     * Cancel action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $data = $this->session->getGuestData();
        $model = $this->_objectManager->get('Webkul\Rmasystem\Model\Allrma')->load($id);
        if ($model->getGuestEmail() == $data["email"] && isset($data)) {
            $model->setStatus(5)->save();
            $this->_emailHelper->cancelRmaEmail($model);
            //Mage::getModel("rmasystem/mails")->CancelRma($id,$rma->getGroup());
            $this->messageManager->addSuccess(
                __('RMA with id ').$id.__(' has been cancelled successfully')
            );
            return $resultRedirect->setPath('*/guest/rmalist');
        } else {
            $this->messageManager->addError(
                __('Sorry You Are Not Authorised to cancel this RMA request')
            );
            return $resultRedirect->setPath('*/guest/rmalist');
        }
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Guest;

use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Session\SessionManager;

class Rmaupdate extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    protected $_emailHelper;

    protected $_fileIo;
    /**
     * @var Session
     */
    protected $_session;
    /**
     * Filesystem facade.
     *
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * File Uploader factory.
     *
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @param Action\Context $context
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        StoreManagerInterface $storeManager,
        SessionManager $session,
        \Webkul\Rmasystem\Helper\Email $emailHelper,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        File $fileIo
    ) {
        $this->_customerSession = $customerSession;
        $this->storeManager = $storeManager;
        $this->_fileIo = $fileIo;
        $this->_emailHelper = $emailHelper;
        $this->_session = $session;
        $this->_filesystem = $filesystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Update action.
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $post = $this->getRequest()->getPost();
        $data = $this->_session->getGuestData();
        if ($post) {
            $isRmaSaveRequired = false;
            $statusFlag = false;
            $deliveryFlag = false;
            $error = false;
            $customerId = $this->_objectManager->create('Magento\Customer\Model\Session')->getCustomerId();
            $model = $this->_objectManager->get('Webkul\Rmasystem\Model\Allrma')->load($post['rma_id']);
            if ($post['message'] != '') {
                $this->_objectManager->create('Webkul\Rmasystem\Model\Conversation')
                    ->setRmaId($post['rma_id'])
                    ->setMessage($post['message'])
                    ->setCreatedAt(time())
                    ->setSender($data['email'])
                    ->save();
            } else {
                $this->messageManager->addError(
                    __('Unable to save Conversation.')
                );
            }
            if (isset($post['solved'])) {
                $model->setStatus(4);
                $isRmaSaveRequired = true;
                $statusFlag = true;
            }
            if (isset($post['pending'])) {
                $model->setStatus(1);
                $isRmaSaveRequired = true;
                $statusFlag = true;
            }
            if ($model->getCustomerConsignmentNo() != $post['customer_consignment_no']) {
                $model->setCustomerConsignmentNo($post['customer_consignment_no']);
                $isRmaSaveRequired = true;
                $deliveryFlag = true;
            }
            $lastRmaId = $model->save()->getId();
            $imageArray = [];
            $imageModel = $this->_objectManager->create('Webkul\Rmasystem\Model\Allrma\Image');
            $path = $imageModel->getBaseDir($lastRmaId);

            $extArray = ['jpg','JPG','jpeg','JPEG','gif','GIF','png','PNG','bmp','BMP'];
            try {
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'related_images']);
                $uploader->setAllowedExtensions($extArray);
                $uploader->setAllowRenameFiles(true);
                $uploader->setAllowCreateFolders(true);
                $result = $uploader->save($path);
                $imageArray[$result['file']] = $result['file'];
                $model->setImages(serialize($imageArray));
                $isRmaSaveRequired = true;
            } catch (\Exception $e) {
                $error = true;
            }
            if ($isRmaSaveRequired == true) {
                $model->save();
            }

            if ($statusFlag == true || $deliveryFlag == true) {
                $this->_emailHelper->updateRmaEmail($post, $model, $statusFlag, $deliveryFlag, 'front');
            } else {
                $this->_emailHelper->newMessageEmail($post, $model, 'front');
            }

            $this->messageManager->addSuccess(
                __('RMA Successfully Saved.')
            );

            return $resultRedirect->setPath('*/guest/rmaview', ['id' => $post['rma_id']]);
        } else {
            $this->messageManager->addError($this->__('Unable to save.'));

            return $resultRedirect->setPath('*/guest/rmaview', ['id' => $post['rma_id']]);
        }
    }
}

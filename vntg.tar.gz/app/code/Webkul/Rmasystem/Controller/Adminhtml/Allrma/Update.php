<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Adminhtml\Allrma;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Framework\App\Filesystem\DirectoryList;

class Update extends \Magento\Backend\App\Action
{

    protected $_emailHelper;
    /**
     * @param Action\Context $context
     */
    public function __construct(
        Action\Context $context,
        \Webkul\Rmasystem\Helper\Email $emailHelper
    ) {
        $this->_emailHelper = $emailHelper;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_Rmasystem::update');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $post = $this->getRequest()->getPost();
        $statusFlag = false;
        $deliveryFlag = false;
        if ($post["message"] != "") {
            $this->_objectManager->create('Webkul\Rmasystem\Model\Conversation')
                ->setRmaId($post["rma_id"])
                ->setMessage($post["message"])
                ->setCreatedAt(time())
                ->setSender(0)
                ->save();
        }
        $isRmaSaveRequired = false;
        $rma = $this->_objectManager->get('Webkul\Rmasystem\Model\Allrma')->load($post["rma_id"]);
        if (isset($post["admin_delivery_status"]) &&
            $rma->getAdminDeliveryStatus() !=
            $post["admin_delivery_status"]
        ) {
            $rma->setAdminDeliveryStatus($post["admin_delivery_status"]);
            if (isset($post["admin_consignment_no"])) {
                $rma->setAdminConsignmentNo($post["admin_consignment_no"]);
            }
            $isRmaSaveRequired = true;
            $deliveryFlag = true;
        }
        if (isset($post["shipping_label"]) && $rma->getShippingLabel() != $post["shipping_label"]) {
            $rma->setShippingLabel($post["shipping_label"]);
            $isRmaSaveRequired = true;
        }
        if ($rma->getStatus() != $post["status"] && $post["status"] != "") {
            $rma->setStatus($post["status"]);
            $isRmaSaveRequired = true;
            $statusFlag = true;
        }
        if ($isRmaSaveRequired == true) {
            $rma->save();
        }

        if ($statusFlag == true || $deliveryFlag == true) {
            $this->_emailHelper->updateRmaEmail($post, $rma, $statusFlag, $deliveryFlag, 'admin');
        } else {
            $this->_emailHelper->newMessageEmail($post, $rma, "admin");
        }
        $this->messageManager->addSuccess(
            __('RMA Successfully Updated.')
        );
        if (isset($post["back"])) {
            return $resultRedirect->setPath("*/allrma/edit", ["id" => $rma->getId()]);
        } else {
            return $resultRedirect->setPath("*/*/index");
        }
    }
}

<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Newrma;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Itemdetails extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @param Context     $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $orderId = $data['order_id'];
        $orderDetails = [];
        $order = $this->_objectManager->create(
            'Magento\Sales\Model\Order'
        )->load($orderId);
        $allItems = $order->getAllVisibleItems();

        foreach ($allItems as $item) {
            $disable = false;
            $qtyOrder = $item->getQtyOrdered();
            $qtyInvoiced = $item->getQtyInvoiced();
            if ($item->getProduct()->isVirtual() || $item->getParentItem()) {
                continue;
            }
            if (!$item->getProduct()->isVirtual() || $item->getProductType() !== 'downloadable') {
                $returnedQty = 0;
                $itemCollection = $this->_objectManager->create(
                    'Webkul\Rmasystem\Model\Rmaitem'
                )->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $orderId])
                ->addFieldToFilter('item_id', ['eq' => $item->getItemId()]);

                if (count($itemCollection)) {
                    $itemCollection->addFieldToSelect('qty');
                    $returnedQuanties = $itemCollection->getColumnValues('qty');
                    foreach ($returnedQuanties as $value) {
                        $returnedQty+=$value;
                    }
                }

                if ($returnedQty == $item->getQtyOrdered()) {
                    $disable = true;
                }

                $url = $this->_objectManager->create(
                    'Magento\Catalog\Model\ResourceModel\Product\Collection'
                )->addFieldToFilter(
                    'entity_id',
                    $item->getProductId()
                )->getFirstItem()->getProductUrl();
                array_push(
                    $orderDetails,
                    [
                        'url' => $url,
                        'name' => $item->getName(),
                        'sku' => $item->getSku(),
                        'qty' => intval($item->getQtyOrdered()),
                        'itemid' => $item->getItemId(),
                        'product_id' => $item->getProductId(),
                        'price' => $item->getPrice(),
                        'returnedQty' => $returnedQty,
                        'disabled' => $disable
                    ]
                );
            } elseif ($qtyOrder !== $qtyInvoiced) {
                 $returnedQty = 0;
                $itemCollection = $this->_objectManager->create(
                    'Webkul\Rmasystem\Model\Rmaitem'
                )->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $orderId])
                ->addFieldToFilter('item_id', ['eq' => $item->getItemId()]);

                if (count($itemCollection)) {
                    $itemCollection->addFieldToSelect('qty');
                    $returnedQty = $itemCollection->getColumnValues('qty')[0];
                }
                $url = $this->_objectManager->create(
                    'Magento\Catalog\Model\ResourceModel\Product\Collection'
                )->addFieldToFilter(
                    'entity_id',
                    $item->getProductId()
                )->getFirstItem()->getProductUrl();
                array_push(
                    $orderDetails,
                    [
                        'url' => $url,
                        'name' => $item->getName(),
                        'sku' => $item->getSku(),
                        'qty' => intval($item->getQtyOrdered()),
                        'itemid' => $item->getItemId(),
                        'product_id' => $item->getProductId(),
                        'price' => $item->getPrice(),
                        'returnedQty' => $returnedQty
                    ]
                );
            }
        }
        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(json_encode(array_reverse($orderDetails)));
    }
}

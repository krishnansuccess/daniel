<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Newrma;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Orderdetails extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     *
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $orderId=$data['order_id'];
        $orderDetails = [];
        $allItems =$this->_objectManager->get('Magento\Sales\Model\Order')->load($orderId)->getAllVisibleItems();
        foreach ($allItems as $item) {
            $url = $this->_objectManager->create(
                'Magento\Catalog\Model\ResourceModel\Product\Collection'
            )->addFieldToFilter("entity_id", $item->getProductId())->getFirstItem()->getProductUrl();

            $orderQty = $item->getQtyOrdered();
            $shipQty = $item->getQtyShipped();
            if ($orderQty === $shipQty) {
                array_push(
                    $orderDetails,
                    [
                        "url" => $url,
                        "name" => $item->getName(),
                        "sku" => $item->getSku(),
                        "qty" => intval($item->getQtyOrdered()),
                        "itemid" => $item->getItemId(),
                        "product_id"=>$item->getProductId(),
                        "price"=>$item->getPrice()
                    ]
                );
            }
        }
        $this->getResponse()->setHeader("Content-type", "application/json");
        $this->getResponse()->setBody(json_encode(array_reverse($orderDetails)));
    }
}

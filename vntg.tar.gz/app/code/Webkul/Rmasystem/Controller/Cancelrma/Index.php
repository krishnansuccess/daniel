<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Rmasystem
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Rmasystem\Controller\Cancelrma;

use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlFactory;
use Magento\Framework\Filesystem\Io\File;

class Index extends \Magento\Customer\Controller\AbstractAccount
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_emailHelper;

    /**
     * @param Action\Context                    $context
     * @param Session                           $customerSession
     * @param \Webkul\Rmasystem\Helper\Email    $emailHelper
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        StoreManagerInterface $storeManager,
        \Webkul\Rmasystem\Helper\Email $emailHelper
    ) {
        $this->_customerSession = $customerSession;
        $this->storeManager = $storeManager;
        $this->_emailHelper = $emailHelper;
        parent::__construct($context);
    }

    /**
     * Cancel action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $customerId = $this->_objectManager->create('Magento\Customer\Model\Session')->getCustomerId();
        $model = $this->_objectManager->get('Webkul\Rmasystem\Model\Allrma')->load($id);
        if ($model->getCustomerId() == $customerId) {
            $model->setStatus(5)->save();
            $this->_emailHelper->cancelRmaEmail($model);
            $this->messageManager->addSuccess(
                __('RMA with id ').$id.__(' has been cancelled successfully')
            );
            return $resultRedirect->setPath('*/index');
        } else {
            $this->messageManager->addError(
                __('Sorry You Are Not Authorised to cancel this RMA request')
            );
            return $resultRedirect->setPath('*/index');
        }
    }
}

var config = {
    map: {
        '*': {
            newRma:  'Webkul_Rmasystem/js/new-rma',
            rmaList: 'Webkul_Rmasystem/js/rma-list'
        }
    }
};

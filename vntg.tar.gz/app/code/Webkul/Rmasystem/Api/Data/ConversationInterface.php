<?php
 namespace Webkul\Rmasystem\Api\Data;

interface ConversationInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ID                = 'id';
    const RMA_ID            = 'rma_id';
    const MESSAGE           = 'message';
    const CREATED_AT        = 'created_at';
    const SENDER            = 'sender';

    /**
     * Get Id
     * @return int
     */
    public function getId();
    /**
     * get rma id
     * @return int
     */
    public function getRmaId();
    /**
     * get Message
     * @return string
     */
    public function getMessage();
    /**
     * get creation time.
     * string
     */
    public function getCreatedAt();
    /**
     * get Sender
     * @return string
     */
    public function getSender();
    /**
     * set Id
     * @return int
     */
    public function setId($id);
    /**
     * set rma id
     * @return int
     */
    public function setRmaId($rmaId);
    /**
     * set Message
     * @return string
     */
    public function setMessage($message);
    /**
     * set creation time.
     * string
     */
    public function setCreatedAt($createdAt);
    /**
     * set Sender
     * @return string
     */
    public function setSender($sender);
}

function onComplete(jsonData){
    if(jsonData == 'true') {
        var url='http://127.0.0.1/m2_new/daniel/payment/result';
        jQuery.ajax({
            type: "POST",
            url: url,
            data: {'success': jsonData },
        });
    }
    else {
        jQuery('#transaction_error').show();
    }
}
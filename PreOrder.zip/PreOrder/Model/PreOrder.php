<?php

namespace Daiva\PreOrder\Model;

use Magento\Framework\Model\AbstractModel;
use Daiva\PreOrder\Api\Data\PreOrderInterface;

/**
 * Description of PreOrder
 *
 * @author Daiva
 */
class PreOrder extends AbstractModel implements PreOrderInterface
{

    protected function _construct()
    {
        $this->_init('Daiva\PreOrder\Model\ResourceModel\PreOrder');
    }

       /**
     * Get ID
     *
     * @return int|null
     */
    public function getId(){
        return $this->getData(self::ID);
    }
    /**
     * Get firstname
     *
     * @return string
     */
    public function getFirstname(){
        return $this->getData(self::FISRTNAME);
    }
      /**
     * Get lastname
     *
     * @return string
     */
    public function getLastname(){
        return $this->getData(self::LASTNAME);
    }
      /**
     * Get productId
     *
     * @return string
     */
    public function getProductId(){
        return $this->getData(self::PRODUCT_ID);
    }
      /**
     * Get mobile
     *
     * @return string
     */
    public function getMobile(){
        return $this->getData(self::MOBILE);
    }
    
    /**
     * Get location
     *
     * @return string|null
     */
    public function getLocation(){
        return $this->getData(self::LOCATION);
    }

    /**
     * Set ID
     *
     * @param int $id
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setId($id){
    	return $this->setData(self::ID, $id);
    }

    /**
     * Set firstname
     *
     * @param string $firstname
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setFirstname($firstname){
    	return $this->setData(self::FISRTNAME, $firstname);
    }
    
     /**
     * Set lastname
     *
     * @param string $lastname
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setLastname($lastname){
    	return $this->setData(self::LASTNAME, $lastname);
    }
     /**
     * Set productId
     *
     * @param string $productId
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setProductId($productId){
    	return $this->setData(self::PRODUCT_ID, $productId);
    }
     /**
     * Set mobile
     *
     * @param string $mobile
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setMobile($mobile){
    	return $this->setData(self::MOBILE, $mobile);
    }
     /**
     * Set location
     *
     * @param string $location
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setLocation($location){
    	return $this->setData(self::LOCATION, $location);
    }



}

<?php

namespace Daiva\PreOrder\Model;

use Daiva\PreOrder\Api\Data;
use Daiva\PreOrder\Api\PreOrderRepositoryInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Daiva\PreOrder\Model\ResourceModel\PreOrder as ResourcePreOrder;
use Daiva\PreOrder\Model\ResourceModel\PreOrder\CollectionFactory as PreOrderCollectionFactory;


/**
 * Class PreOrderRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class PreOrderRepository implements PreOrderRepositoryInterface
{
    /**
     * @var ResourcePreOrder
     */
    protected $resource;

    /**
     * @var PreOrderFactory
     */
    protected $preOrderFactory;

    /**
     * @var PreOrderCollectionFactory
     */
    protected $preOrderCollectionFactory;

    /**
     * @var Data\PreOrderSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * @var \Daiva\PreOrder\Api\Data\PreOrderInterfaceFactory
     */
    protected $dataPreOrderFactory;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @param ResourcePreOrder $resource
     * @param PreOrderFactory $preOrderFactory
     * @param Data\PreOrderInterfaceFactory $dataPreOrderFactory
     * @param PreOrderCollectionFactory $preOrderCollectionFactory
     * @param Data\PreOrderSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourcePreOrder $resource,
        PreOrderFactory $preOrderFactory,
        Data\PreOrderInterfaceFactory $dataPreOrderFactory,
        PreOrderCollectionFactory $preOrderCollectionFactory,
        Data\PreOrderSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,

        CollectionProcessorInterface $collectionProcessor = null
    ) {
        $this->resource = $resource;
        $this->preOrderFactory = $preOrderFactory;
        $this->preOrderCollectionFactory = $preOrderCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPreOrderFactory = $dataPreOrderFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->collectionProcessor = $collectionProcessor ?: $this->getCollectionProcessor();
    }

    /**
     * Save PreOrder data
     *
     * @param \Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder
     * @return PreOrder
     * @throws CouldNotSaveException
     */
    public function save(\Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder)
    {

        try {
            $this->resource->save($preOrder);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(
                __('Could not save the preOrder: %1', $exception->getMessage()),
                $exception
            );
        }
        return $preOrder;
    }

    /**
     * Load PreOrder data by given PreOrder Identity
     *
     * @param string $preOrderId
     * @return PreOrder
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($preOrderId)
    {
        $preOrder = $this->preOrderFactory->create();
        $preOrder->load($preOrderId);
        if (!$preOrder->getId()) {
            throw new NoSuchEntityException(__('PreOrder with id "%1" does not exist.', $preOrderId));
        }
        return $preOrder;
    }

    /**
     * Load PreOrder data collection by given search criteria
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Daiva\PreOrder\Api\Data\PreOrderSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $criteria)
    {
        /** @var \Daiva\PreOrder\Model\ResourceModel\PreOrder\Collection $collection */



        $collection = $this->preOrderCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        /** @var Data\PreOrderSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * Delete PreOrder
     *
     * @param \Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(\Daiva\PreOrder\Api\Data\PreOrderInterface $preOrder)
    {
        try {
            $this->resource->delete($preOrder);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the preOrder: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * Delete PreOrder by given PreOrder Identity
     *
     * @param string $preOrderId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($preOrderId)
    {
        return $this->delete($this->getById($preOrderId));
    }

    /**
     * Retrieve collection processor
     *
     * @deprecated 101.1.0
     * @return CollectionProcessorInterface
     */
    private function getCollectionProcessor()
    {
        if (!$this->collectionProcessor) {
            $this->collectionProcessor = \Magento\Framework\App\ObjectManager::getInstance()->get(
                'Daiva\PreOrder\Model\Api\SearchCriteria\PreOrderCollectionProcessor'
            );
        }
        return $this->collectionProcessor;
    }
}

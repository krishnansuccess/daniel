<?php

namespace Daiva\PreOrder\Model\ResourceModel\PreOrder;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Description of Collection
 *
 * @author Bd
 */
class Collection extends AbstractCollection
{

    protected function _construct()
    {
        $this->_init('Daiva\PreOrder\Model\PreOrder',
            'Daiva\PreOrder\Model\ResourceModel\PreOrder');
    }
}

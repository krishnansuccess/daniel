<?php

namespace Daiva\PreOrder\Api\Data;

interface PreOrderInterface {
    /*     * #@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */

    const ID = 'id';
    const PRODUCT_ID = 'productId';
    const FISRTNAME = 'firstname';
    const LASTNAME = 'lastname';
    const MOBILE = 'mobile';
    const LOCATION = 'location';

    /*     * #@- */

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get firstname
     *
     * @return string
     */
    public function getFirstname();

    /**
     * Get lastname
     *
     * @return string
     */
    public function getLastname();

    /**
     * Get productId
     *
     * @return string
     */
    public function getProductId();

    /**
     * Get mobile
     *
     * @return string
     */
    public function getMobile();

    /**
     * Get location
     *
     * @return string|null
     */
    public function getLocation();

    /**
     * Set ID
     *
     * @param int $id
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setId($id);

    /**
     * Set firstname
     *
     * @param string $firstname
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setFirstname($firstname);

    /**
     * Set lastname
     *
     * @param string $lastname
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setLastname($lastname);

    /**
     * Set productId
     *
     * @param string $productId
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setProductId($productId);

    /**
     * Set mobile
     *
     * @param string $mobile
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setMobile($mobile);

    /**
     * Set location
     *
     * @param string $location
     * @return \Daiva\PreOrder\Api\Data\PreOrderInterface
     */
    public function setLocation($location);
}

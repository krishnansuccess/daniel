<?php

namespace Daiva\PreOrder\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface {

    /**
     * {@inheritdoc}
     */
    public function install(
    SchemaSetupInterface $setup, ModuleContextInterface $context
    ) {



        $installer = $setup;
        $installer->startSetup();
        /**
         * Create table 'Pre Order Details'
         */
        $tableName = $installer->getTable('daiva_preorder');
        $tableComment = 'Pre Order Details';
        $columns = array(
            'id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Id',
            ),
            'product_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Product Id',
            ),
            'firstname' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'First Name',
            ),
            'lastname' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Last name',
            ),
            'mobile' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Mobile',
            ),
            'location' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 400,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Location',
            ),
            'created_at' => array(
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                'size' => null,
                'options' => array('nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT),
                'comment' => 'Created At',
            ),
        );
        // Table creation
        $table = $installer->getConnection()->newTable($tableName);
        $foreignKeys = array('product_id' => array('ref_table' => 'catalog_product_entity', 'ref_column' => 'entity_id', 'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE));
        // Columns creation
        foreach ($columns as $name => $values) {
            $table->addColumn(
                    $name, $values['type'], $values['size'], $values['options'], $values['comment']
            );
        }
        // Foreign keys creation
        foreach ($foreignKeys as $column => $foreignKey) {
            $table->addForeignKey(
                    $installer->getFkName($tableName, $column, $foreignKey['ref_table'], $foreignKey['ref_column']), $column, $foreignKey['ref_table'], $foreignKey['ref_column'], $foreignKey['on_delete']
            );
        }
        // Table comment
        $table->setComment($tableComment);
        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);
    }

}

<?php

namespace Daiva\PreOrder\Controller\Index;

use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\DataObject;
use Magento\Framework\App\Action\Context;
use Daiva\PreOrder\Model\PreOrderFactory;

class Post extends \Magento\Framework\App\Action\Action {

    protected $preOrderFactory;


    /**
     * @param Context $context
     * @param ConfigInterface $contactsConfig
     */
    public function __construct(
        Context $context,
        PreOrderFactory $preOrderFactory
    ) {
        parent::__construct($context);
        $this->preOrderFactory = $preOrderFactory;
     }
    /**
     * Post user question
     *
     * @return Redirect
     */
    public function execute() {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        if (!$this->getRequest()->isPost()) {
            return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        }
        try {
            $data = $this->validatedParams();
            $preorder=$this->preOrderFactory->create();
            $preorder->setFirstname($data['firstname']);
            $preorder->setLastname($data['lastname']);
            $preorder->setProductId($data['product_id']);
            $preorder->setMobile($data['mobile']);
            $preorder->setLocation($data['location']);
            $preorder->save();
            $this->messageManager->addSuccessMessage(
                    __('Thanks for sumbitting us with your details. We\'ll respond to you very soon.')
            );
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {

            $this->messageManager->addErrorMessage(
                    __('An error occurred while processing your form. Please try again later.')
            );
        }
        return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
    }

    /**
     * @param array $post Post data from contact form
     * @return void
     */
    private function sendEmail($post) {
        $this->mail->send(
                $post['email'], ['data' => new DataObject($post)]
        );
    }

    /**
     * @return array
     * @throws \Exception
     */
    private function validatedParams() {
        $request = $this->getRequest();
        if (trim($request->getParam('firstname')) === '') {
            throw new LocalizedException(__('Firstname is missing'));
        }
        if (trim($request->getParam('lastname')) === '') {
            throw new LocalizedException(__('Lastname is missing'));
        }
        if (trim($request->getParam('mobile')) === '') {
            throw new LocalizedException(__('Mobile is missing'));
        }
        if (trim($request->getParam('location')) === '') {
            throw new LocalizedException(__('Location is missing'));
        }

        return $request->getParams();
    }

}

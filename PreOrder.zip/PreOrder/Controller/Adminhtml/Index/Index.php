<?php

namespace Daiva\PreOrder\Controller\Adminhtml\Index;

use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action\Context;

class Index extends \Magento\Backend\App\Action {

    protected $pageFactory;

    public function __construct(Context $context, PageFactory $pageFactory) {
        $this->pageFactory = $pageFactory;
        return parent::__construct($context);
    }

    public function execute() {

        $page_object = $this->pageFactory->create();
        $page_object->setActiveMenu('Daiva_PreOrder::pre_order');
        $page_object->addBreadcrumb(__('Pre Order'), __('Pre Order'));
        $page_object->getConfig()->getTitle()->prepend(__('Pre Order'));

        return $page_object;
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Daiva_PreOrder::pre_order');
    }

}

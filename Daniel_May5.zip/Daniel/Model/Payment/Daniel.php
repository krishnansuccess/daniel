<?php


namespace Bd\Daniel\Model\Payment;

class Daniel extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = "daniel";
    protected $_isOffline = true;

    public function isAvailable(
        \Magento\Quote\Api\Data\CartInterface $quote = null
    ) {
        return parent::isAvailable($quote);
    }
}

<?php

namespace Bd\RestLogger\Plugin\Magento\Webapi\Controller;

use Magento\Framework\Webapi\Rest\Request as RestRequest;
use Magento\Framework\Webapi\ErrorProcessor;

class Rest {

    protected $request;
    protected $_errorProcessor;

    public function __construct(ErrorProcessor $errorProcessor, RestRequest $request) {
        $this->request = $request;
        $this->_errorProcessor = $errorProcessor;
    }

    public function aroundDispatch(
    \Magento\Webapi\Controller\Rest $subject, \Closure $proceed, $request
    ) {

        $this->logCreate('/var/log/rest_log_file.log', $request->getPathInfo());
        $this->logCreate('/var/log/rest_log_file.log', $this->request->getRequestData());
        $result = $proceed($request);
        if ($result->isException()) {
            foreach ($result->getException() as $exception) {
                $maskedException = $this->_errorProcessor->maskException($exception);
                $messageData = [
                    'message' => $maskedException->getMessage(),
                ];
                if ($maskedException->getErrors()) {
                    $messageData['errors'] = [];
                    foreach ($maskedException->getErrors() as $errorMessage) {
                        $errorData['message'] = $errorMessage->getRawMessage();
                        $errorData['parameters'] = $errorMessage->getParameters();
                        $messageData['errors'][] = $errorData;
                    }
                }
                if ($maskedException->getCode()) {
                    $messageData['code'] = $maskedException->getCode();
                }
                if ($maskedException->getDetails()) {
                    $messageData['parameters'] = $maskedException->getDetails();
                }
            }
            $this->logCreate('/var/log/rest_log_file.log', $messageData);
        }

        return $result;
    }

    protected function logCreate($fileName, $data) {
        $writer = new \Zend\Log\Writer\Stream(BP . "$fileName");
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($data);
    }

}

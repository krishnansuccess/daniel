define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'daniel',
                component: 'Bd_Daniel/js/view/payment/method-renderer/daniel'
            }
        );
        return Component.extend({});
    }
);
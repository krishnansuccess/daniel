var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Bd_Sunbit/js/model/place-order-with-trans-id': true
            }
        }
    },
    paths: {
        "bootstrap.min": "Bd_Sunbit/js/bootstrap.min"
    },
    shim: {
        'bootstrap.min': {
            'deps': ['jquery']
        }
    }
};

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'ko',
    'jquery',
    'underscore',
    'uiComponent',
    'Magento_Checkout/js/action/place-order',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/payment-service',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/checkout-data-resolver',
    'uiRegistry',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Ui/js/model/messages',
    'uiLayout',
    'Magento_Checkout/js/action/redirect-on-success',
    'mage/url'
], function (
        ko,
        $,
        _,
        Component,
        placeOrderAction,
        selectPaymentMethodAction,
        quote,
        customer,
        paymentService,
        checkoutData,
        checkoutDataResolver,
        registry,
        additionalValidators,
        Messages,
        layout,
        redirectOnSuccessAction,
        url
        ) {
    'use strict';

    return Component.extend({
        redirectAfterPlaceOrder: true,
        isPlaceOrderActionAllowed: ko.observable(quote.billingAddress() != null),

        /**
         * After place order callback
         */
        afterPlaceOrder: function () {
            // Override this function and put after place order logic here
        },

        /**
         * Initialize view.
         *
         * @return {exports}
         */
        initialize: function () {
            var billingAddressCode,
                    billingAddressData,
                    defaultAddressData;

            this._super().initChildren();
            window.isSynchronyCompleted = ko.observable(false);
            window.isSynchronyFailed = ko.observable(false);


            window.isSynchronyCompleted.subscribe(function (value) {
                this.isPlaceOrderActionAllowed(value == true);
            }, this);

            quote.billingAddress.subscribe(function (address) {
                this.isPlaceOrderActionAllowed(address !== null);
            }, this);
            checkoutDataResolver.resolveBillingAddress();

            billingAddressCode = 'billingAddress' + this.getCode();
            registry.async('checkoutProvider')(function (checkoutProvider) {
                defaultAddressData = checkoutProvider.get(billingAddressCode);

                if (defaultAddressData === undefined) {
                    // Skip if payment does not have a billing address form
                    return;
                }
                billingAddressData = checkoutData.getBillingAddressFromData();

                if (billingAddressData) {
                    checkoutProvider.set(
                            billingAddressCode,
                            $.extend(true, {}, defaultAddressData, billingAddressData)
                            );
                }
                checkoutProvider.on(billingAddressCode, function (providerBillingAddressData) {
                    checkoutData.setBillingAddressFromData(providerBillingAddressData);
                }, billingAddressCode);
            });

            return this;
        },

        /**
         * Initialize child elements
         *
         * @returns {Component} Chainable.
         */
        initChildren: function () {
            this.messageContainer = new Messages();
            this.createMessagesComponent();

            return this;
        },

        /**
         * Create child message renderer component
         *
         * @returns {Component} Chainable.
         */
        createMessagesComponent: function () {

            var messagesComponent = {
                parent: this.name,
                name: this.name + '.messages',
                displayArea: 'messages',
                component: 'Magento_Ui/js/view/messages',
                config: {
                    messageContainer: this.messageContainer
                }
            };

            layout([messagesComponent]);

            return this;
        },

        /**
         * Place order.
         */
        placeOrder: function (data, event) {
            var self = this;

            if (event) {
                event.preventDefault();
            }

            if (this.validate() && additionalValidators.validate()) {
                this.isPlaceOrderActionAllowed(false);


                if (quote.paymentMethod().method == 'synchrony' && (window.isSynchronyCompleted() == false && window.isSynchronyFailed() == false) || (window.isSynchronyCompleted() == true && window.isSynchronyFailed() == true)) {
                    var JSONObject = {};
                    var address = quote.billingAddress();
                    
                    //var ship_address = quote.shippingAddress();
                    //var country_name = countryData()[countryId].name;

                    var totals = quote.totals();
                    JSONObject.processInd = 3;

                    JSONObject.merchantID = 5348120340302090;

                    JSONObject.clientTransId = Math.floor(Math.random() * 999999) + 1;
                     window.isSynchronyFailed(false);
                    JSONObject.cardNumber = $("#synchrony_cc_number").val();
                    // JSONObject.expMonth ="12" ;
                    // JSONObject.expYear ="49";
                    JSONObject.iniPurAmt = "5";
                    JSONObject.custFirstName = address.firstname;
                    JSONObject.custLastName = address.lastname;
                    JSONObject.custZipCode = address.postcode;
                    JSONObject.custAddress1 = address.street[0];
                    JSONObject.custAddress2 = "";
                    JSONObject.custCity = address.city;
                    JSONObject.custState = address.regionCode;
                    JSONObject.phoneNumber = address.telephone;
                    if (customer.isLoggedIn()) {
                        JSONObject.emailAddress = window.checkoutConfig.customerData.email;
                    } else {
                        JSONObject.emailAddress = quote.guestEmail;
                    }
                    JSONObject.transPromo1 = this.getPromoCode(totals.grand_total);
                    JSONObject.transAmount1 = totals.grand_total;
                    console.log(JSONObject);

                    $.ajax({
                        url: url.build('synchrony/payment/authentication'),
                        type: 'GET',
                        contentType: 'application/json',
                        success: function (res) {
                            JSONObject.tokenId = res.clientToken;
                            window.tokenId = res.clientToken;
                            console.log('fasfasfasdfadsfasdfdsf');
                            console.log(res.clientToken);
                            $('#show_clint_tkn_div').show();
                            $('#show_clint_tkn_input').html('<h5>' + res.clientToken + '</h5>');
                            callCombinedModaldBuyProcess(null, JSONObject);
                            // calldBuyProcess1(null,JSONObject);

                        }
                    });
                } else {

                    this.getPlaceOrderDeferredObject()
                            .fail(
                                    function () {
                                        self.isPlaceOrderActionAllowed(true);
                                    }
                            ).done(
                            function () {
                                self.afterPlaceOrder();

                                if (self.redirectAfterPlaceOrder) {
                                    redirectOnSuccessAction.execute();
                                }
                            }
                    );

                    return true;
                }
            }

            return false;
        },
        
        
        getPromoCode: function(order_amt){
            if(order_amt>0 && order_amt<1499.99)
                return '106';
            if(order_amt>=1500 && order_amt<2999.99)
                return '112';
            if(order_amt>=3000 && order_amt<9999.99)
                return '118';
            if(order_amt>=10000)
                return '260';
        },

        /**
         * @return {*}
         */
        getPlaceOrderDeferredObject: function () {
            return $.when(
                    placeOrderAction(this.getData(), this.messageContainer)
                    );
        },

        /**
         * @return {Boolean}
         */
        selectPaymentMethod: function () {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);

            return true;
        },

        isChecked: ko.computed(function () {
            return quote.paymentMethod() ? quote.paymentMethod().method : null;
        }),

        isRadioButtonVisible: ko.computed(function () {
            return paymentService.getAvailablePaymentMethods().length !== 1;
        }),

        /**
         * Get payment method data
         */
        getData: function () {
            return {
                'method': this.item.method,
                'po_number': null,
                'additional_data': null
            };
        },

        /**
         * Get payment method type.
         */
        getTitle: function () {
		var self=this;
		var payments=[{progressive_gateway:"Progressive Leasing"},{checkmo:"Check / Money order"},{daniel:"Daniel's Credit Card"},	{synchrony:"Synchrony Credit Card"},{paypal_express:"PayPal Express Checkout"},{classyllama_llamacoin:"Credit Card"}]
            var payment=_.find(payments,function(obj){
                return (self.item.method in obj)
            })
           
            return payment[this.item.method];
            //return this.item.title;
        },

        /**
         * Get payment method code.
         */
        getCode: function () {
            return this.item.method;
        },

        /**
         * @return {Boolean}
         */
        validate: function () {
            return true;
        },

        /**
         * @return {String}
         */
        getBillingAddressFormName: function () {
            return 'billing-address-form-' + this.item.method;
        },

        /**
         * Dispose billing address subscriptions
         */
        disposeSubscriptions: function () {
            // dispose all active subscriptions
            var billingAddressCode = 'billingAddress' + this.getCode();

            registry.async('checkoutProvider')(function (checkoutProvider) {
                checkoutProvider.off(billingAddressCode);
            });
        }
    });
});

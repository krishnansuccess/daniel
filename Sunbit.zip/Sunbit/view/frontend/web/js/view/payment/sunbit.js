define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'sunbit',
                component: 'Bd_Sunbit/js/view/payment/method-renderer/sunbit'
            }
        );
        return Component.extend({});
    }
);
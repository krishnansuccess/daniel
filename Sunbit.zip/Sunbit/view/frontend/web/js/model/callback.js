
function handleCompleted(result) {
    var url = window.checkout.baseUrl + '/sunbit/payment/result';
    jQuery.ajax({
        type: "POST",
        url: url,
        data: {xmlData: 1},
        success: function (result) {
            console.log(result);
            window.location = window.checkout.baseUrl + '/checkout/onepage/success';
        }
    });
}
function handleCancelation(result) {
    var message = 'Your Transaction did not completed successfully. Please try again';
    //  var message2 = xmlDoc.getElementsByTagName("message2")[0].childNodes[0].nodeValue;
    /*window.customAlert({
     title: '',
     content: message,
     actions: {
     always: function(){
     window.location.reload();
     }
     }
     });*/
    window.location.reload();
    // jQuery('#transaction_error').show();
    // jQuery('#transaction_error').html('<h1>'+message+'</h1><p>'+message2+'</p>');
}

function handleCompleted(result) {

    var message = 'Your Transaction did not completed successfully. Please try again';
     var baseUrl=BASE_URL?BASE_URL: window.checkout.baseUrl;
    var url = baseUrl + '/sunbit/payment/result';
    jQuery.ajax({
        type: "POST",
        url: url,
        data: {purchaseId: result.purchaseId},
        success: function (result) {
            console.log(result);
            if (result.success)
                window.location = baseUrl + '/checkout/onepage/success';
            else {
                window.customAlert({
                    title: '',
                    content: message,
                    actions: {
                        always: function () {
                            window.location.reload();
                        }
                    }
                });
            }
        }
    });
}
function handleCancelation(result) {
    /*var message = 'Your Transaction did not completed successfully. Please try again';
    //  var message2 = xmlDoc.getElementsByTagName("message2")[0].childNodes[0].nodeValue;
    window.customAlert({
        title: '',
        content: message,
        actions: {
            always: function () {
                window.location.reload();
            }
        }
    });
    //window.location.reload();
    */
    console.log(result);

 var message = 'Your Transaction did not completed successfully. Please try again';
     var baseUrl=BASE_URL?BASE_URL: window.checkout.baseUrl;
    var url = baseUrl + '/sunbit/payment/result';
    jQuery.ajax({
        type: "POST",
        url: url,
        data: {purchaseId: result.purchaseId},
        success: function (result) {
            console.log(result.success);
            if (result.success)
                window.location = baseUrl + '/checkout/onepage/success';
            else {
                window.customAlert({
                    title: '',
                    content: message,
                    actions: {
                        always: function () {
                            window.location.reload();
                        }
                    }
                });
            }
        }
    });
    // jQuery('#transaction_error').show();
    // jQuery('#transaction_error').html('<h1>'+message+'</h1><p>'+message2+'</p>');
}
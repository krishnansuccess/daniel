<?php

namespace Bd\Sunbit\Controller\Payment;

class Result extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $jsonHelper;
    protected $cart;
    protected $orderRepository;
	protected $_checkoutSession;
    protected $magestoreHelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Cart $cart,
		\Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->cart = $cart;
	//$this->magestoreHelper = $helper;
	$this->_checkoutSession = $checkoutSession;
        $this->orderRepository=$orderRepository;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $purchaseId = $this->getRequest()->getParam('purchaseId');
        try{
        $lastorderId = $this->_checkoutSession->getLastOrderId();
        $order = $this->orderRepository->get($lastorderId);
        $result=['success'=>true];
        
        if($this->checkStatus($purchaseId,$order->getIncrementId())){
            $order->setSendEmail(1);
            $this->orderRepository->save($order);
            $this->magestoreHelper->sendNewOrderEmail($order);
            $this->cart->truncate();
            $this->cart->save();
            $result['success']=true;
        }
        $this->getResponse()->representJson(json_encode($result,true));
        }catch(\Exception $e){
            echo $e->getMessage();
            exit;
        }
    }
    
    protected function checkStatus($purchaseId,$orderId){
        
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://api-demo.sunbit.com/epay-service/api/v1/epay?transactionId='.$orderId.'&purchaseId='.$purchaseId);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Sunbit-Key: XjwsWCKgoEWTNHzztgOeyUwq0Ys7jTUc';
        $headers[] = 'Sunbit-Secret: XDVj0aPCcSxEK1LpFcAvkd9RAHlOQ45D';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
       
        if (curl_errno($ch)) {
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
  
           $result = json_decode($result,true);
           
        if($result['status']=='COMPLETED'){
            return true;
        }else{
            return false;
        }
    }
}

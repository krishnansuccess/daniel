<?php

namespace Bd\Sunbit\Controller\Payment;

use Magento\Sales\Model\Order;
use Magento\Framework\Exception\NoSuchEntityException;

class Status extends \Magento\Framework\App\Action\Action {

    protected $resultPageFactory;
    protected $jsonHelper;
    protected $quoteRepository;
    protected $serializer;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory, \Magento\Framework\Json\Helper\Data $jsonHelper, \Magento\Quote\Api\CartRepositoryInterface $quoteRepository, \Magento\Checkout\Model\Cart $cart, \Magento\Customer\Model\AddressFactory $addressFactory, \Magento\Checkout\Model\Session $checkoutSession, \Magento\Sales\Model\OrderRepository $orderRepository, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Customer\Model\Session $customerSession, \Magento\Catalog\Model\Product $product, \Magento\Quote\Model\QuoteFactory $quote, \Magento\Framework\Serialize\Serializer\Json $serializer, \Magento\Catalog\Api\ProductRepositoryInterface $productRepository, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->jsonHelper = $jsonHelper;
        $this->quoteRepository = $quoteRepository;
        $this->cart = $cart;
        $this->_addressFactory = $addressFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        $this->_storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->_product = $product;
        $this->quote = $quote;
      
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(Json::class);

        $this->productRepository = $productRepository;
        $this->customerRepository = $customerRepository;
        parent::__construct($context);
    }

    public function addOrderItem($orderItem, $cart, $qtyFlag = null) {
        /* @var $orderItem \Magento\Sales\Model\Order\Item */
        if ($orderItem->getParentItem() === null) {
            $storeId = $this->_storeManager->getStore()->getId();
            try {
                /**
                 * We need to reload product in this place, because products
                 * with the same id may have different sets of order attributes.
                 */
                $product = $this->productRepository->getById($orderItem->getProductId(), false, $storeId, true);
            } catch (NoSuchEntityException $e) {
                return $cart;
            }
            $info = $orderItem->getProductOptionByCode('info_buyRequest');
            $additionalOptions = $orderItem->getProductOptionByCode('additional_options');
            if($additionalOptions!=null)
                $product->addCustomOption('additional_options', $this->serializer->serialize($additionalOptions));
            $info = new \Magento\Framework\DataObject($info);
            if ($qtyFlag === null) {
                $info->setQty($orderItem->getQtyOrdered());
            } else {
                $info->setQty(1);
            }

            $cart->addProduct($product, $info);
        }
        return $cart;
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        $resultRedirect = $this->resultRedirectFactory->create();
        $lastorderId = $this->_checkoutSession->getLastOrderId();
        $order = $this->orderRepository->get($lastorderId);
        $cart = $this->_objectManager->get(\Magento\Checkout\Model\Cart::class);
        
        $resultItems=[];
        // $formKey = $objectManager->create('\Magento\Framework\Data\Form\FormKey')->getFormKey();
        foreach ($order->getAllItems() as $item) {
            try {
                $this->addOrderItem($item, $cart);
                $resultItems[]=["serialNumber"=> $item->getSku(),"amount"=> floatval($item->getPrice())];
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->_objectManager->get(\Magento\Checkout\Model\Session::class)->getUseNotice(true)) {
                    $this->messageManager->addNoticeMessage($e->getMessage());
                } else {
                    $this->messageManager->addErrorMessage($e->getMessage());
                }
                return $resultRedirect->setPath('*/*/history');
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage(
                        $e, __('We can\'t add this item to your shopping cart right now.')
                );
                return $resultRedirect->setPath('checkout/cart');
            }
        }
        $cart->save();
        $orderState = 'dpaypending';
        $order->setState($orderState)->setStatus('dpaypending');
        $order->setSendEmail(0);
        $order->save();

        $params = $this->getRequest()->getParams();
        try {


            $ch = curl_init();

            $billingAddress = $order->getBillingAddress();


            $payload = '{
    "transactionId": "' . $order->getIncrementId() . '",
    "amount": ' . $order->getGrandTotal() . ',
    "location": "Location1",
    "customerDetails": {
        "firstName": "' . $order->getCustomerFirstname() . '",
        "lastName": "' . $order->getCustomerLastname() . '",
        "email": "' . $order->getCustomerEmail() . '",
        "phone": "' . $billingAddress->getTelephone() . '",
        "addressDetails": {
            "address": "' . trim(implode(PHP_EOL, $billingAddress->getStreet())) . '",
            "city": "' . $billingAddress->getCity() . '",
            "state": "' . $billingAddress->getRegionCode() . '",
            "zipCode": "' . $billingAddress->getPostcode() . '"
        }
    },
    "items": '. json_encode($resultItems,JSON_PRETTY_PRINT).'
}';

            curl_setopt($ch, CURLOPT_URL, 'https://api-demo.sunbit.com/epay-service/api/v1/epay');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"transactionId\": \"completed-gthftredxserrr\",\n    \"amount\": 1008,\n    \"location\": \"Location1\",\n    \"customerDetails\": {\n        \"firstName\": \"John\",\n        \"lastName\": \"Doe\",\n        \"email\": \"john.doe@emailaddress.email\",\n        \"phone\": \"303-988-8945\",\n        \"addressDetails\": {\n            \"address\": \"2491  Tavern Place \",\n            \"city\": \"Lakewood\",\n            \"state\": \"CO\",\n            \"zipCode\": \"80227\"\n        }\n    },\n    \"items\": [\n        {\n            \"serialNumber\": \"1111111\",\n            \"amount\": 166\n        }\n    ]\n}");

            curl_setopt($ch, CURLOPT_POST, 1);

            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Sunbit-Key: XjwsWCKgoEWTNHzztgOeyUwq0Ys7jTUc';
            $headers[] = 'Sunbit-Secret: XDVj0aPCcSxEK1LpFcAvkd9RAHlOQ45D';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
             $this->logCreate('/var/log/daiva_file.log', $payload);
            $result = curl_exec($ch);
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            $this->getResponse()->representJson($result);
            curl_close($ch);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            return $this->jsonResponse($e->getMessage());
        }
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '') {
        return $this->getResponse()->representJson(
                        $this->jsonHelper->jsonEncode($response)
        );
    }
    
    
    public function logCreate($fileName, $data) {
        $writer = new \Zend\Log\Writer\Stream(BP . "$fileName");
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($data);
        $logger->info(' Log'.print_r($data, true));
    }

}

var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Bd_Daniel/js/model/place-order-with-trans-id': true
            }
        }
    },
    paths: {
        "bootstrap.min": "Bd_Daniel/js/bootstrap.min"
    },
    shim: {
        'bootstrap.min': {
            'deps': ['jquery']
        }
    }
};
